SFX FOLDER

Drop replacement sound effects here using these filenames when desired:
shoot.mp3
enemy.mp3
jump.mp3
double.mp3
hit.mp3
kill.mp3
explosion.mp3
cannon.mp3
mortar.mp3
game_start.mp3
boss_death.mp3
hostage.mp3
pickup.mp3
grenade.mp3
knife.mp3
checkpoint.mp3

WAV/OGG can also be used if you update AudioManager or convert/import them in Godot.
The game safely falls back to silence when a file is absent.
