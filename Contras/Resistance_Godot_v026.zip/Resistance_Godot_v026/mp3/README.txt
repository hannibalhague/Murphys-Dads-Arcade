MUSIC FOLDER — numbered tracks

Put your songs here as:
1.mp3
2.mp3
3.mp3
4.mp3
5.mp3 ...

The MUSIC/TRACK button advances to the next numbered track.
When the next numbered file is missing, the button turns music OFF.
Press again from OFF to return to track 1.

Godot may import new MP3 files the first time the project is opened.
