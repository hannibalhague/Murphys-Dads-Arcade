extends Area2D

@export var speed = 980.0
@export var damage = 1.0
@export var team = "player"
@export var terrain_damage = 1.15
var direction = Vector2.RIGHT
var life = 1.5
var projectile_kind = "bullet"
var visual_age = 0.0

func _ready():
    monitoring = true
    collision_layer = 0
    collision_mask = 5 if team == "player" else 3
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _physics_process(delta):
    global_position += direction * speed * delta
    visual_age += delta
    life -= delta
    if projectile_kind == "flame":
        # flame puffs expand and drift slightly upward as the stream travels
        global_position.y -= 9.0 * delta
        scale = Vector2.ONE * (1.0 + min(0.65, visual_age * 1.8))
        queue_redraw()
    if life <= 0.0:
        queue_free()

func _on_body_entered(body):
    if team == "player" and body.is_in_group("player"):
        return
    if team == "enemy" and body.is_in_group("enemy"):
        return
    if team == "player" and body.has_method("take_damage"):
        body.take_damage(damage, global_position)
        queue_free()
        return
    if team == "enemy" and body.has_method("take_damage"):
        body.take_damage(damage, global_position)
        queue_free()
        return
    if body.is_in_group("destructible_terrain") and body.has_method("damage_rifle_impact"):
        if team == "player":
            body.damage_rifle_impact(global_position, terrain_damage, direction)
        queue_free()
        return
    queue_free()

func _draw():
    if projectile_kind == "flame":
        var fade = clamp(life / 0.72,0.0,1.0)
        var flicker = 0.85 + 0.15 * sin(visual_age * 32.0)
        draw_circle(Vector2(-4,1),10.0,Color(1.0,0.16,0.03,0.16*fade))
        draw_circle(Vector2.ZERO,7.5*flicker,Color(1.0,0.34,0.04,0.72*fade))
        draw_circle(Vector2(3,-1),4.8*flicker,Color(1.0,0.72,0.12,0.90*fade))
        draw_circle(Vector2(5,-1),2.2,Color(1.0,0.97,0.58,0.95*fade))
        return
    var c = Color(1.0,0.84,0.24) if team == "player" else Color(1.0,0.20,0.12)
    var glow = Color(c.r,c.g,c.b,0.18)
    var hot = Color(1.0,0.98,0.78) if team == "player" else Color(1.0,0.76,0.60)
    # Long layered tracer + hot core makes every shot readable against busy backgrounds.
    draw_line(-direction * 18.0, direction * 7.0, glow, 8.0)
    draw_line(-direction * 14.0, direction * 6.0, Color(c.r,c.g,c.b,0.48), 4.8)
    draw_line(-direction * 10.0, direction * 5.0, c, 2.6)
    draw_circle(Vector2.ZERO, 4.2, Color(c.r,c.g,c.b,0.26))
    draw_circle(Vector2.ZERO, 2.3, hot)
    draw_circle(direction*4.0,1.25,Color.WHITE)
    var spark_side=Vector2(-direction.y,direction.x)
    draw_line(-direction*5.0+spark_side*3.0,-direction*9.0+spark_side*5.0,Color(c.r,c.g,c.b,0.34),1.2)
