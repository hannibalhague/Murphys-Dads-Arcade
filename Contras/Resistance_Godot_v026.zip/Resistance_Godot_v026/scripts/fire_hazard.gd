extends Area2D

@export var hazard_width := 90.0
var t:=0.0
var damage_wait:=0.0

func _ready():
    collision_layer=0
    collision_mask=2|4
    var shape=RectangleShape2D.new();shape.size=Vector2(hazard_width,30)
    var cs=CollisionShape2D.new();cs.shape=shape;cs.position=Vector2(0,-10);add_child(cs)
    body_stayed_compat()

func body_stayed_compat():
    body_entered.connect(_touch)

func _process(delta):
    t+=delta;damage_wait=max(0.0,damage_wait-delta);queue_redraw()
    if damage_wait<=0.0:
        for body in get_overlapping_bodies():
            _touch(body)

func _touch(body):
    if damage_wait>0.0:return
    if body!=null and body.has_method("take_damage"):
        body.take_damage(1,global_position);damage_wait=0.8

func _draw():
    draw_ellipse_shadow()
    var count=max(3,int(hazard_width/16.0))
    for i in range(count):
        var x=-hazard_width*0.45+float(i)*(hazard_width*0.9/max(1,count-1))
        var h=20.0+8.0*sin(t*6.0+i*1.7)
        var sway=5.0*sin(t*7.0+i)
        draw_colored_polygon(PackedVector2Array([Vector2(x-7,4),Vector2(x+sway,-h),Vector2(x+7,4)]),Color(1.0,0.26,0.04,0.75))
        draw_colored_polygon(PackedVector2Array([Vector2(x-4,4),Vector2(x+sway*0.5,-h*0.65),Vector2(x+4,4)]),Color(1.0,0.76,0.12,0.88))
        draw_circle(Vector2(x+sway*0.3,-h*0.35),3.0,Color(1.0,0.95,0.55,0.85))
        if i % 2 == 0:
            var smoke_y = -h - 10.0 - fmod(t*18.0+i*7.0,22.0)
            draw_circle(Vector2(x+sway*0.5,smoke_y),5.0+i%3,Color(0.16,0.14,0.13,0.18))
            draw_circle(Vector2(x+sway*0.7,-h-5.0),1.5,Color(1.0,0.64,0.18,0.72))

func draw_ellipse_shadow():
    var pts=PackedVector2Array()
    for i in range(20):
        var a=TAU*float(i)/20.0;pts.append(Vector2(cos(a)*hazard_width*0.48,sin(a)*6.0+6.0))
    draw_colored_polygon(pts,Color(0.10,0.03,0.01,0.32))
