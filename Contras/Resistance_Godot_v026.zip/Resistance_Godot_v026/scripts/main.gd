extends Node2D

const InputSetup = preload("res://scripts/input_setup.gd")
const CampaignData = preload("res://scripts/campaign_data.gd")
const TERRAIN_SCENE = preload("res://scenes/DestructibleTerrain.tscn")
const PLAYER_SCENE = preload("res://scenes/Player.tscn")
const ENEMY_SCENE = preload("res://scenes/Enemy.tscn")
const DIGGER_SCENE = preload("res://scenes/DiggerRobot.tscn")
const HOSTAGE_SCENE = preload("res://scenes/Hostage.tscn")
const TREASURE_SCENE = preload("res://scenes/Treasure.tscn")
const LADDER_SCENE = preload("res://scenes/Ladder.tscn")
const SOLID_SCENE = preload("res://scenes/SolidBlock.tscn")
const PROP_SCENE = preload("res://scenes/DestructibleProp.tscn")
const HUD_SCENE = preload("res://scenes/HUD.tscn")
const MOBILE_SCENE = preload("res://scenes/MobileControls.tscn")
const BOSS_SCENE = preload("res://scenes/BossTank.tscn")
const HELI_SCENE = preload("res://scenes/HelicopterExit.tscn")
const HEALTH_SCENE = preload("res://scenes/HealthPickup.tscn")
const SUPPLY_SCENE = preload("res://scenes/SupplyPickup.tscn")
const CHECKPOINT_SCENE = preload("res://scenes/CheckpointFlag.tscn")
const STRUCTURE_SCENE = preload("res://scenes/StructureFacade.tscn")
const HILL_SCENE = preload("res://scenes/HillMound.tscn")
const WATER_SCENE = preload("res://scenes/WaterSurface.tscn")
const FIRE_SCENE = preload("res://scenes/FireHazard.tscn")
const FRONTEND_SCENE = preload("res://scenes/FrontEnd.tscn")

var world_width := 7000.0
var surface_y := 384.0
var terrain
var player
var level: Dictionary
var victory_firework_time := 0.0
var victory_firework_tick := 0.0
var victory_firework_origin := Vector2.ZERO
var digger_timer: Timer
var hill_mounds: Array = []

func _ready():
    InputSetup.ensure_actions()
    GameState.reset()
    level = CampaignData.level(GameState.current_level)
    GameState.fireworks_requested.connect(_start_victory_fireworks)
    _build_level()
    _spawn_level()
    add_child(preload("res://scenes/StageAmbience.tscn").instantiate())
    add_child(HUD_SCENE.instantiate())
    add_child(MOBILE_SCENE.instantiate())
    add_child(FRONTEND_SCENE.instantiate())
    Input.joy_connection_changed.connect(_on_joy_connection_changed)
    queue_redraw()

func _process(delta):
    if victory_firework_time > 0.0:
        victory_firework_time -= delta
        victory_firework_tick -= delta
        if victory_firework_tick <= 0.0:
            victory_firework_tick = 0.22
            _spawn_firework()

func _unhandled_input(event):
    if event.is_action_pressed("restart"):
        GameState.start_new_campaign()
        get_tree().reload_current_scene()

func _draw():
    var sky = level.sky
    # Layered sky bands give every stage depth without expensive full-screen shaders.
    draw_rect(Rect2(0,-800,world_width,1500),sky[0])
    draw_rect(Rect2(0,-80,world_width,230),sky[1].darkened(0.18))
    draw_rect(Rect2(0,150,world_width,280),sky[1].darkened(0.38))
    draw_rect(Rect2(0,300,world_width,130),sky[2].darkened(0.55) if sky.size()>2 else sky[1].darkened(0.48))
    # Celestial disc and haze, positioned differently per mission.
    var sun_x=720.0+float(GameState.current_level%4)*820.0
    var sun_col=Color(1.0,0.78,0.36,0.30) if String(level.theme) not in ["cave","nexus"] else Color(0.66,0.44,1.0,0.20)
    draw_circle(Vector2(sun_x,70),72.0,sun_col)
    draw_circle(Vector2(sun_x,70),47.0,Color(sun_col.r,sun_col.g,sun_col.b,sun_col.a*1.35))
    # Three silhouette depths: distant mountains, middle ridge, near ridge.
    for layer_i in range(3):
        var x := -260.0-float(layer_i)*90.0
        var base_y=352.0+float(layer_i)*12.0
        var step=360.0-float(layer_i)*34.0
        var alpha=0.16+float(layer_i)*0.10
        while x < world_width + 500.0:
            var mh := 62.0+float(layer_i)*22.0+fmod(x*0.13+GameState.current_level*41.0+layer_i*23.0,120.0)
            var mc=sky[0].lightened(0.06+float(layer_i)*0.035)
            mc.a=alpha
            draw_colored_polygon(PackedVector2Array([Vector2(x,base_y),Vector2(x+180,base_y-mh),Vector2(x+410,base_y)]),mc)
            x+=step
    # Sparse clouds/fog streaks.
    for cx in range(180,int(world_width),790):
        var cy=105.0+float((cx*11+GameState.current_level*37)%105)
        var cc=Color(0.90,0.94,0.92,0.08 if String(level.theme) not in ["ice","skyfort"] else 0.15)
        draw_circle(Vector2(cx,cy),26.0,cc);draw_circle(Vector2(cx+28,cy-5),34.0,cc);draw_circle(Vector2(cx+62,cy+2),23.0,cc)
    _draw_theme_details()
    _draw_high_altitude_details()
    _draw_foreground_details()
    # Permanent boss-zone warning marker near the end of the stage.
    draw_rect(Rect2(world_width-900,315,190,42),Color(0.08,0.06,0.04,0.72))
    draw_rect(Rect2(world_width-900,315,190,42),Color(1.0,0.68,0.20,0.70),false,2.0)
    draw_string(ThemeDB.fallback_font,Vector2(world_width-893,341),"BOSS AREA  →",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color(1.0,0.84,0.35,0.92))
    draw_string(ThemeDB.fallback_font,Vector2(50,112),"MISSION %02d — %s" % [GameState.current_level+1,level.name],HORIZONTAL_ALIGNMENT_LEFT,-1,23,Color(0.96,0.94,0.74,0.90))
    draw_string(ThemeDB.fallback_font,Vector2(50,136),"RESCUE • DIG • LOOT • DESTROY %s • TAKE THE HEAD • EXTRACT" % level.boss,HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color(0.88,0.92,0.80,0.78))

func _draw_theme_details():
    var theme = String(level.theme)
    # Layered stage silhouettes and small foreground marks make each campaign area read differently.
    if theme == "jungle":
        for tx in range(90,int(world_width),205):
            var tree_h = 52.0 + float((tx*13)%60)
            draw_rect(Rect2(tx-4,366-tree_h,8,tree_h),Color(0.09,0.16,0.10))
            draw_circle(Vector2(tx,366-tree_h),22.0,Color(0.055,0.20,0.11))
            draw_line(Vector2(tx-20,366-tree_h+10),Vector2(tx+24,366-tree_h-14),Color(0.12,0.28,0.14,0.65),4)
        for tx in range(260,int(world_width),620):
            draw_colored_polygon(PackedVector2Array([Vector2(tx,365),Vector2(tx+48,326),Vector2(tx+104,365)]),Color(0.08,0.18,0.12,0.46))
    elif theme == "desert":
        draw_circle(Vector2(770,92),58,Color(1.0,0.78,0.35,0.78))
        for tx in range(420,int(world_width),670):
            draw_line(Vector2(tx,360),Vector2(tx,312),Color(0.21,0.35,0.18),6)
            draw_line(Vector2(tx,330),Vector2(tx-15,318),Color(0.21,0.35,0.18),5)
        for tx in range(180,int(world_width),830): draw_rect(Rect2(tx,292,130,73),Color(0.28,0.18,0.12,0.24))
    elif theme == "harbor":
        for tx in range(250,int(world_width),570):
            draw_line(Vector2(tx,365),Vector2(tx,245),Color(0.18,0.22,0.23,0.55),5)
            draw_line(Vector2(tx,248),Vector2(tx+74,248),Color(0.21,0.25,0.26,0.55),4)
            draw_rect(Rect2(tx+55,260,96,105),Color(0.16,0.22,0.25,0.30))
    elif theme == "ice":
        for tx in range(340,int(world_width),520):
            draw_colored_polygon(PackedVector2Array([Vector2(tx,365),Vector2(tx+50,270),Vector2(tx+105,365)]),Color(0.66,0.82,0.90,0.42))
            draw_line(Vector2(tx+50,270),Vector2(tx+38,326),Color(0.85,0.96,1.0,0.40),2)
    elif theme in ["cave","nexus"]:
        for tx in range(250,int(world_width),480):
            draw_circle(Vector2(tx,130+(tx%90)),18,Color(0.62,0.28,0.88,0.22))
            draw_line(Vector2(tx,148+(tx%90)),Vector2(tx+35,195+(tx%70)),Color(0.46,0.30,0.65,0.24),3)
    elif theme == "factory":
        for tx in range(300,int(world_width),560):
            draw_rect(Rect2(tx,230,120,135),Color(0.17,0.19,0.19,0.5))
            draw_rect(Rect2(tx+25,188,20,42),Color(0.20,0.22,0.20,0.55))
            draw_line(Vector2(tx+8,245),Vector2(tx+108,245),Color(0.72,0.56,0.20,0.25),4)
    elif theme == "toxic":
        for tx in range(320,int(world_width),520):
            draw_circle(Vector2(tx,330),42,Color(0.42,0.72,0.10,0.12))
            draw_circle(Vector2(tx+30,346),16,Color(0.62,0.90,0.12,0.10))
    elif theme == "skyfort":
        for tx in range(300,int(world_width),650):
            draw_rect(Rect2(tx,245,170,120),Color(0.12,0.19,0.27,0.42))
            draw_line(Vector2(tx+20,265),Vector2(tx+150,265),Color(0.42,0.62,0.76,0.30),3)
    elif theme == "lava":
        for tx in range(280,int(world_width),440):
            draw_circle(Vector2(tx,350),28,Color(1.0,0.20,0.04,0.20))
            draw_line(Vector2(tx,350),Vector2(tx+32,314),Color(1.0,0.36,0.07,0.16),5)

    # Near-ground detail layer: sparse, high-contrast shapes keep the world from reading as one flat strip.
    for fx in range(130,int(world_width),285):
        var jitter=float((fx*17 + GameState.current_level*43)%31)-15.0
        if theme in ["jungle","toxic"]:
            draw_line(Vector2(fx+jitter,384),Vector2(fx+jitter-8,365),level.edge.darkened(0.28),2.0)
            draw_line(Vector2(fx+jitter,374),Vector2(fx+jitter+10,364),level.edge.darkened(0.18),2.0)
        elif theme in ["desert","lava"]:
            draw_circle(Vector2(fx+jitter,379),5.0,level.ground[1].lightened(0.12))
            draw_circle(Vector2(fx+jitter+8,381),3.0,level.ground[1].lightened(0.06))
        elif theme in ["factory","harbor","skyfort"]:
            draw_rect(Rect2(fx+jitter,374,18,4),Color(0.24,0.27,0.27,0.55))
            draw_circle(Vector2(fx+jitter+4,372),2.5,Color(0.70,0.52,0.18,0.45))

func _draw_foreground_details():
    var theme=String(level.theme)
    # Dark near-camera silhouettes improve contrast and make the player/enemies pop.
    for fx in range(75,int(world_width),410):
        var j=float((fx*29+GameState.current_level*17)%53)-26.0
        if theme=="jungle":
            draw_line(Vector2(fx+j,430),Vector2(fx+j+4,369),Color(0.035,0.09,0.055,0.62),7.0)
            draw_circle(Vector2(fx+j-12,372),17.0,Color(0.035,0.11,0.06,0.55));draw_circle(Vector2(fx+j+13,367),20.0,Color(0.035,0.11,0.06,0.55))
        elif theme in ["factory","harbor","skyfort"]:
            draw_rect(Rect2(fx+j,355,8,75),Color(0.05,0.07,0.08,0.50))
            draw_line(Vector2(fx+j+4,365),Vector2(fx+j+48,343),Color(0.10,0.12,0.12,0.45),3.0)
        elif theme in ["desert","lava"]:
            draw_colored_polygon(PackedVector2Array([Vector2(fx+j,430),Vector2(fx+j+17,387),Vector2(fx+j+43,430)]),Color(0.12,0.08,0.055,0.38))
        elif theme in ["cave","nexus","toxic"]:
            draw_circle(Vector2(fx+j,395),11.0,Color(level.edge.r,level.edge.g,level.edge.b,0.18))
            draw_line(Vector2(fx+j,407),Vector2(fx+j+20,430),Color(level.edge.r,level.edge.g,level.edge.b,0.16),4.0)

func _build_level():
    terrain = TERRAIN_SCENE.instantiate()
    terrain.surface_y = int(surface_y)
    add_child(terrain)
    var layout = CampaignData.LAYOUTS[int(level.layout)]
    # Animated water occupies the gaps between land masses instead of empty black holes.
    for gap in layout.w:
        var wa=CampaignData.sx(float(gap[0]));var wb=CampaignData.sx(float(gap[1]))
        var water=WATER_SCENE.instantiate();water.global_position=Vector2((wa+wb)*0.5,surface_y+4);water.water_size=Vector2(max(70.0,wb-wa),520);water.top_color=level.water[0];water.deep_color=level.water[1];add_child(water)
    for seg in layout.g:
        var a = CampaignData.sx(float(seg[0]))
        var b = CampaignData.sx(float(seg[1]))
        var width = b-a
        # Strong edges plus a large Broforce-style destructible center.
        var edge_w = min(105.0,width*0.22)
        _solid(Rect2(a,surface_y,edge_w,448),level.ground[0],level.edge)
        _solid(Rect2(b-edge_w,surface_y,edge_w,448),level.ground[0],level.edge)
        if width > edge_w*2.0+20.0:
            terrain.fill_world_rect(Rect2(a+edge_w,surface_y,width-edge_w*2.0,448),"dirt")
    _solid(Rect2(0,832,world_width,128),Color(0.12,0.14,0.14),Color(0.30,0.31,0.28))
    _solid(Rect2(-48,-100,48,1100),Color(0.12,0.14,0.14),Color(0.28,0.29,0.27))
    _solid(Rect2(world_width,-100,48,1100),Color(0.12,0.14,0.14),Color(0.28,0.29,0.27))

    # Physical rolling terrain: broad mounds sit over the efficient destructible grid so the route is no longer ruler-flat.
    var mound_specs=[Vector3(690,220,44),Vector3(1540,285,62),Vector3(2470,240,52),Vector3(3560,320,72),Vector3(4460,250,48),Vector3(5700,300,68),Vector3(6350,210,42)]
    for spec in mound_specs:
        _hill(Vector2(spec.x,surface_y),Vector2(spec.y,spec.z))

    var ledges = layout.l.duplicate(true)
    for u in CampaignData.UPPER[int(level.layout)]: ledges.append(u)
    for i in range(ledges.size()):
        var q = ledges[i]
        var px = CampaignData.sx(float(q[0]))
        var py = float(q[1])
        var pw = float(q[2])
        _solid(Rect2(px-pw/2.0,py,pw,18),Color(0.24,0.28,0.25),level.edge,true,true)
        if i % 2 == 0 or i >= layout.l.size():
            _ladder(Vector2(px-pw*0.28,(py+surface_y)*0.5),Vector2(34,max(72.0,surface_y-py)))
        if i % 3 == 0:
            _camp_cluster(Vector2(px,py),i)

    # Underground chambers and valuables, matching the HTML game's dig-to-find loop.
    var chambers = [Vector2(1220,560),Vector2(2150,635),Vector2(3820,560),Vector2(4660,640)]
    for i in range(chambers.size()):
        var c = chambers[i]
        terrain.carve_world_rect(Rect2(c.x-210,c.y-65,420,140))
        if i < 2: _hostage(Vector2(c.x,c.y+40))
        _treasure(Vector2(c.x+(-80 if i%2==0 else 90),c.y+36),"chest" if i==3 else ("book" if i%2==0 else "gold"),2500 if i==3 else (1500 if i%2==0 else 600))

    # v013: fewer health pickups, placed at meaningful recovery points instead of every few screens.
    for x in [980,2650,4320,5900]:
        _health(Vector2(float(x),330))

    # Upper-route rewards: ladders and wall-knife climbing should pay off instead of being decoration.
    for i in range(ledges.size()):
        var reward_ledge = ledges[i]
        var reward_x = CampaignData.sx(float(reward_ledge[0]))
        var reward_y = float(reward_ledge[1])
        if i % 2 == 1:
            _treasure(Vector2(reward_x,reward_y-30),"gold" if i%4 else "book",600 if i%4 else 1500)
        # Only one occasional upper-route med kit; most upper paths reward score/loot instead.
        if i == 6:
            _health(Vector2(reward_x+32,reward_y-28))

    # v016 mission set-pieces: more authored cover/vertical choices so stages feel like missions, not test strips.
    for sx in [1450.0, 3320.0, 5150.0]:
        _prop(Vector2(sx,surface_y-28),Vector2(72,56),"crate",2.2,130)
        if int(sx) % 2 == 0:
            _prop(Vector2(sx+62,surface_y-30),Vector2(34,60),"barrel",1.6,140)
    _solid(Rect2(1760,312,210,18),Color(0.22,0.26,0.24),level.edge,true,true)
    _ladder(Vector2(1815,348),Vector2(32,72))
    _treasure(Vector2(1880,282),"gold",750)
    _solid(Rect2(4900,286,250,18),Color(0.22,0.26,0.24),level.edge,true,true)
    _ladder(Vector2(4960,335),Vector2(32,98))
    _treasure(Vector2(5070,256),"book",1750)

    # v017 architecture pass: large, theme-specific structures make each campaign stage feel authored.
    _build_major_structures()
    _build_houses_and_bunkers()
    _build_vertical_sky_routes()
    # Real animated flame hazards make industrial/lava/toxic zones feel alive.
    if String(level.theme) in ["lava","factory","toxic"]:
        for fx in [1320.0,3780.0,5450.0]:
            var fire=FIRE_SCENE.instantiate();fire.global_position=Vector2(fx,_ground_y_at(fx)-4);fire.hazard_width=76.0 if String(level.theme)!="lava" else 112.0;add_child(fire)

    # Boss approach has cover, explosive scenery, a warning gate and a guaranteed resupply route.
    _prop(Vector2(world_width-1080,surface_y-32),Vector2(38,64),"barrel",1.6,140)
    _prop(Vector2(world_width-1015,surface_y-32),Vector2(38,64),"barrel",1.6,140)
    _prop(Vector2(world_width-950,surface_y-38),Vector2(92,76),"wood",2.4,160)
    _prop(Vector2(world_width-720,surface_y-38),Vector2(108,76),"wood",2.6,180)

func _camp_cluster(pos: Vector2, cluster_seed: int):
    var theme=String(level.theme)
    var support_kind="metal" if theme in ["factory","harbor","skyfort","toxic"] else "wood"
    # Two-storey destructible outpost frame with a real roofline and access route.
    _prop(pos+Vector2(-72,-36),Vector2(26,76),support_kind,2.2,100)
    _prop(pos+Vector2(72,-36),Vector2(26,76),support_kind,2.2,100)
    _prop(pos+Vector2(0,-82),Vector2(176,22),support_kind,2.8,140)
    _prop(pos+Vector2(-118,-24),Vector2(58,48),"crate",2.0,110)
    if cluster_seed%2==0:
        _prop(pos+Vector2(112,-31),Vector2(36,62),"barrel",1.6,140)
    else:
        _prop(pos+Vector2(118,-30),Vector2(112,58),"tent",2.2,110)
    if cluster_seed%3==0:
        _ladder(pos+Vector2(42,-44),Vector2(30,82))

func _build_major_structures():
    var theme=String(level.theme)
    var style="jungle_bunker"
    if theme=="desert": style="desert_bunker"
    elif theme=="harbor": style="harbor_warehouse"
    elif theme=="ice": style="ice_bunker"
    elif theme=="factory": style="factory"
    elif theme=="toxic": style="toxic_plant"
    elif theme=="skyfort": style="sky_module"
    elif theme=="lava": style="lava_fort"
    elif theme in ["cave","nexus"]: style="alien"
    # Three large architecture beats per stage, offset so they do not simply repeat.
    _structure(Vector2(1080,surface_y),style,Vector2(270,132))
    _structure(Vector2(3180,surface_y),style,Vector2(300,148))
    _structure(Vector2(5350,surface_y),style,Vector2(320,156))
    # Functional destructible pieces in front of the visual façades.
    for bx in [1080.0,3180.0,5350.0]:
        _prop(Vector2(bx-112,surface_y-38),Vector2(34,76),"concrete" if theme not in ["jungle","desert","lava"] else "wood",3.0,120)
        _prop(Vector2(bx+112,surface_y-38),Vector2(34,76),"concrete" if theme not in ["jungle","desert","lava"] else "wood",3.0,120)
        _prop(Vector2(bx,surface_y-88),Vector2(190,18),"metal" if theme in ["factory","harbor","skyfort","toxic"] else "wood",2.8,150)
        _ladder(Vector2(bx+74,surface_y-44),Vector2(28,88))
    # Watchtower landmark before the boss.
    var tx=world_width-1280.0
    _prop(Vector2(tx-38,surface_y-55),Vector2(18,110),"metal",2.2,100)
    _prop(Vector2(tx+38,surface_y-55),Vector2(18,110),"metal",2.2,100)
    _prop(Vector2(tx,surface_y-112),Vector2(116,20),"metal",2.8,150)
    _prop(Vector2(tx,surface_y-146),Vector2(100,54),"concrete",3.0,180)
    _ladder(Vector2(tx+22,surface_y-56),Vector2(28,112))

    # A large boss compound façade makes the finale look like a real defended installation.
    var fortress_x=world_width-455.0
    _structure(Vector2(fortress_x,surface_y),style,Vector2(430,190))
    _prop(Vector2(fortress_x-190,surface_y-46),Vector2(30,92),"concrete",3.6,160)
    _prop(Vector2(fortress_x+190,surface_y-46),Vector2(30,92),"concrete",3.6,160)
    _prop(Vector2(fortress_x,surface_y-132),Vector2(300,22),"metal",3.2,180)
    _ladder(Vector2(fortress_x-130,surface_y-64),Vector2(30,128))
    _treasure(Vector2(fortress_x-60,surface_y-165),"gold",1000)

func _build_houses_and_bunkers():
    var theme=String(level.theme)
    # Smaller buildings break up the big compounds and create recognizable streets/camps.
    var house_style="field_house"
    if theme in ["factory","harbor","toxic"]: house_style="utility_house"
    elif theme in ["cave","nexus"]: house_style="alien_hut"
    elif theme=="skyfort": house_style="sky_house"
    elif theme in ["desert","lava"]: house_style="desert_house"
    elif theme=="ice": house_style="ice_house"
    for hx in [720.0,2050.0,4200.0]:
        _structure(Vector2(hx,_ground_y_at(hx)),house_style,Vector2(180,108))
        _prop(Vector2(hx-78,surface_y-25),Vector2(46,50),"crate",2.0,90)
    # Distinct command bunkers and spawn tents make enemy camps read as actual bases.
    for bx in [2600.0,4700.0]:
        _structure(Vector2(bx,_ground_y_at(bx)),"command_bunker",Vector2(230,126))
        _prop(Vector2(bx+155,surface_y-33),Vector2(126,66),"spawn_tent",2.4,120)
        _prop(Vector2(bx-145,surface_y-30),Vector2(36,60),"barrel",1.6,140)

func _build_vertical_sky_routes():
    # Three multi-storey towers turn the formerly empty upper screen into a second combat/exploration layer.
    var tower_xs=[1380.0,3560.0,5630.0]
    var deck_ys=[275.0,150.0,25.0,-100.0]
    for tower_i in range(tower_xs.size()):
        var tx=float(tower_xs[tower_i])
        var gy=_ground_y_at(tx)
        _structure(Vector2(tx,gy),"high_tower",Vector2(190,500))
        # ground-to-first-deck ladder and all upper ladder runs
        var lower_y=gy
        for deck_i in range(deck_ys.size()):
            var dy=float(deck_ys[deck_i])
            var deck_w=210.0 if deck_i<3 else 176.0
            _solid(Rect2(tx-deck_w*0.5,dy,deck_w,16),Color(0.18,0.23,0.23),level.edge,true,true)
            var ladder_x=tx+(60.0 if deck_i%2==0 else -60.0)
            _ladder(Vector2(ladder_x,(lower_y+dy)*0.5),Vector2(30,abs(lower_y-dy)+16.0))
            # alternating side catwalks create jumping routes rather than a single straight shaft
            var wing_side=-1.0 if (tower_i+deck_i)%2==0 else 1.0
            var wing_x=tx+wing_side*150.0
            _solid(Rect2(wing_x-65.0,dy+8.0,130.0,14.0),Color(0.20,0.25,0.24),level.edge,true,true)
            if deck_i<3:
                _ladder(Vector2(tx+wing_side*92.0,dy-42.0),Vector2(28,98.0))
            # Upper-level objectives and rewards.
            if deck_i==1:
                _hostage(Vector2(tx-42.0,dy-28.0))
            elif deck_i==3:
                _hostage(Vector2(tx+34.0,dy-28.0))
            if deck_i%2==0:
                _treasure(Vector2(wing_x,dy-24.0),"chest" if deck_i==2 else "gold",1350 if deck_i==2 else 800)
            else:
                _treasure(Vector2(tx+wing_side*44.0,dy-24.0),"book",1700)
            # Dedicated sky guards stay on their intended platform instead of snapping to ground.
            var kinds=["scout","commando","officer","rocketeer","shield","cyborg"]
            var sky_kind=String(kinds[(tower_i*2+deck_i)%kinds.size()])
            var st=_enemy_stats(sky_kind)
            var guard=_enemy(Vector2(tx-wing_side*46.0,dy-30.0),st.x,st.y*0.72,sky_kind,false)
            guard.shot_delay=max(guard.shot_delay,2.25)
            guard.fire_range=min(guard.fire_range,410.0)
            guard.sight_range=min(guard.sight_range,610.0)
            lower_y=dy
        # rooftop radar cache and a short antenna perch
        _solid(Rect2(tx-58.0,-190.0,116.0,14.0),Color(0.16,0.21,0.22),level.edge,true,true)
        _ladder(Vector2(tx,-145.0),Vector2(26,92.0))
        _treasure(Vector2(tx,-216.0),"chest",2600)

func _draw_high_altitude_details():
    var theme=String(level.theme)
    # Distant air traffic / infrastructure gives the newly playable upper region visual context.
    for ax in range(520,int(world_width),1450):
        var y=-250.0-float((ax*13+GameState.current_level*57)%220)
        if theme in ["jungle","desert","harbor","ice"]:
            draw_line(Vector2(ax-34,y),Vector2(ax+38,y),Color(0.10,0.13,0.14,0.34),3.0)
            draw_colored_polygon(PackedVector2Array([Vector2(ax+38,y),Vector2(ax+15,y-8),Vector2(ax+12,y+8)]),Color(0.10,0.13,0.14,0.34))
            draw_line(Vector2(ax-8,y),Vector2(ax-25,y-11),Color(0.10,0.13,0.14,0.30),2.0)
        elif theme in ["factory","toxic","skyfort"]:
            draw_rect(Rect2(ax-24,y-10,48,20),Color(0.14,0.19,0.21,0.30))
            draw_circle(Vector2(ax,y),5.0,Color(0.58,0.82,0.92,0.26))
            draw_line(Vector2(ax-36,y),Vector2(ax-70,y+5),Color(0.18,0.23,0.25,0.24),2.0)
        elif theme in ["cave","nexus"]:
            draw_circle(Vector2(ax,y),18.0,Color(0.62,0.30,1.0,0.12))
            draw_arc(Vector2(ax,y),31.0,0,TAU,22,Color(0.62,0.30,1.0,0.14),2.0)
        elif theme=="lava":
            draw_line(Vector2(ax,y+80),Vector2(ax+24,y-20),Color(0.34,0.10,0.05,0.20),7.0)
            draw_circle(Vector2(ax+24,y-22),10.0,Color(1.0,0.32,0.05,0.12))

func _spawn_level():
    player = PLAYER_SCENE.instantiate()
    player.global_position = Vector2(150,330)
    add_child(player)
    var cam = player.get_node("Camera2D")
    cam.limit_left=0; cam.limit_right=int(world_width); cam.limit_top=-760; cam.limit_bottom=900

    var mix = CampaignData.ENEMY_MIXES[GameState.current_level]
    var xs = [500,930,1320,1760,2220,2700,3180,3660,4140,4620,5100,5580]
    for i in range(xs.size()):
        var kind = String(mix[i % mix.size()])
        var stats = _enemy_stats(kind)
        var ground_enemy = _enemy(Vector2(CampaignData.sx(xs[i]),330),stats.x,stats.y,kind,true)
        if i >= 8:
            ground_enemy.shot_delay=max(ground_enemy.shot_delay,2.05)

    # A few readable elevated guards make vertical routes matter without creating enemy walls.
    var layout = CampaignData.LAYOUTS[int(level.layout)]
    for i in range(min(4,layout.l.size())):
        if i % 2 == 0:
            var q=layout.l[i]
            var elevated_kind=String(mix[(i+3)%mix.size()])
            var elevated_stats=_enemy_stats(elevated_kind)
            var e=_enemy(Vector2(CampaignData.sx(float(q[0])),float(q[1])-30),elevated_stats.x,elevated_stats.y*0.82,elevated_kind,false)
            e.shot_delay=max(e.shot_delay,2.15)
            e.fire_range=min(e.fire_range,420.0)
    # Extra underground guards.
    _enemy(Vector2(1250,630),2,72,"soldier")
    _enemy(Vector2(2170,705),3,74,"raider")
    _enemy(Vector2(3860,630),3,72,"robot")
    _enemy(Vector2(4680,715),4,70,"heavy")
    _enemy(Vector2(3350,655),3,76,"commando")

    _digger(Vector2(2500,720))
    digger_timer=Timer.new(); digger_timer.wait_time=18.0; digger_timer.autostart=true
    digger_timer.timeout.connect(func():
        if not GameState.boss_defeated and get_tree().get_nodes_in_group("digger").size()<3:
            _digger(Vector2(clamp(player.global_position.x+randf_range(-700,700),850.0,5200.0),720)))
    add_child(digger_timer)

    GameState.set_hostage_total(get_tree().get_nodes_in_group("hostage").size())
    # Checkpoints are now visible Canadian flag-raising moments; supply crates are separate rewards.
    _checkpoint(Vector2(world_width*0.50,365))
    _supply(Vector2(world_width*0.50-105,330))
    _checkpoint(Vector2(world_width-860,365))
    _supply(Vector2(world_width-965,330))
    _boss(Vector2(world_width-390,325))
    # Helicopter scene uses world-space altitude internally, so keep its node origin at Y=0.
    _helicopter_exit(Vector2(world_width-180,0))

func _enemy_stats(kind: String) -> Vector2:
    if kind in ["heavy","rich","shield","iceguard"]: return Vector2(5,60)
    if kind in ["robot","ninja","alien","commando","cyborg","rocketeer"]: return Vector2(4,72)
    if kind == "mutant": return Vector2(3,118)
    if kind.begins_with("dog"): return Vector2(2,110 if kind != "dog_attack" else 126)
    if kind in ["flamer","grenadier","suit","officer","medic","diver"]: return Vector2(3,70)
    if kind == "scout": return Vector2(2,108)
    return Vector2(2,76)

func _solid(rect,base,edge,one_way=false,organic_top=false):
    var b=SOLID_SCENE.instantiate()
    b.block_size=rect.size
    b.block_color=base
    b.edge_color=edge
    b.one_way=one_way
    b.organic_top=organic_top
    b.position=rect.position+rect.size*0.5
    add_child(b)
    return b

func _hill(pos:Vector2,size:Vector2):
    var h=HILL_SCENE.instantiate()
    h.global_position=pos
    h.mound_size=size
    h.base_color=level.ground[0]
    h.edge_color=level.edge
    add_child(h)
    hill_mounds.append(h)
    return h

func _ground_y_at(x:float)->float:
    var y=surface_y
    for h in hill_mounds:
        if not is_instance_valid(h):
            continue
        var lx=x-h.global_position.x
        if abs(lx)<=h.mound_size.x*0.5:
            y=min(y,h.global_position.y+h.surface_y_at(lx))
    return y

func _prop(pos,size,kind,hp,score):
    var p=PROP_SCENE.instantiate()
    var pp=Vector2(pos)
    if abs((pp.y+size.y*0.5)-surface_y)<92.0:
        pp.y=_ground_y_at(pp.x)-size.y*0.5
    p.global_position=pp
    p.prop_size=size
    p.prop_kind=kind
    p.max_hp=hp
    p.score_value=score
    add_child(p)
    return p

func _ladder(pos,size):
    var l=LADDER_SCENE.instantiate()
    l.global_position=pos
    l.ladder_size=size
    add_child(l)
    return l

func _enemy(pos,hp,speed,kind="soldier",snap_to_ground=true):
    var e=ENEMY_SCENE.instantiate()
    var ep=Vector2(pos)
    if snap_to_ground and ep.y<390.0:
        ep.y=_ground_y_at(ep.x)-30.0
    e.global_position=ep
    e.max_hp=hp
    e.move_speed=speed
    e.enemy_kind=kind
    add_child(e)
    return e

func _digger(pos):
    var d=DIGGER_SCENE.instantiate()
    d.global_position=pos
    add_child(d)
    return d
func _hostage(pos):
    var h=HOSTAGE_SCENE.instantiate()
    h.global_position=pos
    add_child(h)
    return h
func _treasure(pos,kind,points):
    var t=TREASURE_SCENE.instantiate()
    t.global_position=pos
    t.treasure_kind=kind
    t.score_value=points
    add_child(t)
    return t
func _health(pos):
    var h=HEALTH_SCENE.instantiate()
    var hp=Vector2(pos)
    if hp.y>300.0 and hp.y<390.0:
        hp.y=_ground_y_at(hp.x)-28.0
    h.global_position=hp
    add_child(h)
    return h

func _supply(pos):
    var s=SUPPLY_SCENE.instantiate()
    var sp=Vector2(pos)
    if sp.y>300.0:
        sp.y=_ground_y_at(sp.x)-28.0
    s.global_position=sp
    add_child(s)
    return s

func _checkpoint(pos):
    var c=CHECKPOINT_SCENE.instantiate()
    var cp=Vector2(pos)
    cp.y=_ground_y_at(cp.x)-19.0
    c.global_position=cp
    add_child(c)
    return c

func _structure(pos,kind,size):
    var f=STRUCTURE_SCENE.instantiate()
    f.global_position=pos
    f.structure_kind=kind
    f.facade_size=size
    add_child(f)
    return f
func _boss(pos):
    var b=BOSS_SCENE.instantiate()
    b.global_position=pos
    add_child(b)
    return b
func _helicopter_exit(pos):
    var h=HELI_SCENE.instantiate()
    h.global_position=pos
    add_child(h)
    return h

func _start_victory_fireworks(origin):
    victory_firework_origin=origin; victory_firework_time=12.0; victory_firework_tick=0.02
func _spawn_firework():
    var f=preload("res://scenes/Firework.tscn").instantiate(); f.global_position=victory_firework_origin+Vector2(randf_range(-320,320),randf_range(-250,-70)); f.color_index=randi()%4; add_child(f)

func _on_joy_connection_changed(_device:int,connected:bool):
    if connected:
        GameState.message_requested.emit("GAMEPAD CONNECTED — LEFT STICK/D-PAD MOVE & AIM • A JUMP • X FIRE • B/Y GRENADE")

