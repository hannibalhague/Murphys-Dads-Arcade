extends Area2D

var rescued = false
var pulse = 0.0
var rescue_time = 0.0

func _ready():
    add_to_group("hostage")
    monitoring = true
    collision_layer = 0
    collision_mask = 2
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _process(delta):
    pulse += delta
    if rescued:
        rescue_time -= delta
        position.y -= 7.0 * delta
        if rescue_time <= 0.0:
            queue_free()
    queue_redraw()

func _on_body_entered(body):
    if rescued or not body.is_in_group("player"):
        return
    rescued = true
    rescue_time = 1.05
    monitoring = false
    GameState.rescue_hostage()
    AudioManager.play_sfx("hostage",-5.0)
    var scene = preload("res://scenes/Burst.tscn")
    var b = scene.instantiate()
    b.global_position = global_position
    b.burst_kind = "gold"
    get_tree().current_scene.add_child(b)

func _draw():
    var glow = 0.55 + sin(pulse * 5.0) * 0.18
    draw_circle(Vector2(0,-17), 8.0, Color(0.88,0.73,0.58))
    draw_circle(Vector2(-2,-19),1.2,Color.WHITE);draw_circle(Vector2(2,-19),1.2,Color.WHITE)
    draw_arc(Vector2(0,-20),8.4,PI,TAU,10,Color(0.15,0.11,0.08),2.5)
    draw_rect(Rect2(-8,-9,16,24), Color(0.26,0.42,0.55))
    draw_rect(Rect2(-6,-7,12,4), Color(0.38,0.56,0.67))
    draw_rect(Rect2(-2,-6,4,4), Color(0.85,0.77,0.46))
    if rescued:
        var wave = sin(pulse * 13.0) * 5.0
        draw_line(Vector2(-7,-4),Vector2(-18,-15-wave),Color(0.88,0.73,0.58),4.0)
        draw_line(Vector2(7,-4),Vector2(18,-15+wave),Color(0.88,0.73,0.58),4.0)
        draw_line(Vector2(-5,14),Vector2(-9,25),Color(0.22,0.28,0.34),4.0)
        draw_line(Vector2(5,14),Vector2(9,25),Color(0.22,0.28,0.34),4.0)
        draw_arc(Vector2.ZERO, 23.0, 0, TAU, 24, Color(0.35,1.0,0.55,glow), 2.5)
    else:
        draw_line(Vector2(-12,0),Vector2(12,0),Color(0.72,0.58,0.30),4.0)
        draw_line(Vector2(-10,-5),Vector2(10,7),Color(0.72,0.58,0.30),3.0)
        draw_arc(Vector2.ZERO, 20.0, 0, TAU, 24, Color(1.0,0.88,0.28,glow), 2.0)
