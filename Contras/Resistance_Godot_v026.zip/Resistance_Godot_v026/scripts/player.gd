extends CharacterBody2D

@export var move_speed = 275.0
@export var jump_speed = 510.0
@export var ladder_speed = 175.0
@export var max_health = 5
@export var wall_knife_hold_time = 0.34
@export var wall_knife_slide_speed = 58.0
@export var wall_knife_jump_x = 155.0
@export var wall_knife_jump_y = 455.0
@export var wall_knife_regrab_delay = 0.07
@export var wall_climb_assist_time = 0.34
@export var roll_speed = 430.0
@export var roll_duration = 0.48
@export var roll_cooldown_time = 0.18

var facing = 1
var aim_dir = Vector2.RIGHT
var fire_cooldown = 0.0
var grenade_cooldown = 0.0
var jumps_used = 0
var coyote = 0.0
var on_ladder = null
var crouching = false
var invincible = 0.0
var alive = true
var shot_flip = false
var flip_time = 0.0
var terrain = null
var camera_shake = 0.0

var wall_knife = false
var wall_side = 0
var wall_hold_left = 0.0
var wall_regrab_cooldown = 0.0
var wall_knife_hint_shown = false
var extracting = false
var extraction_target = Vector2.ZERO
var extraction_hold = 0.0
var wall_jump_recent = 0.0
var wall_climb_wall_side = 0
var rolling = false
var roll_time = 0.0
var roll_dir = 1
var roll_cooldown = 0.0
var respawn_position = Vector2.ZERO
var fire_input_armed = true
var melee_cooldown = 0.0
var melee_anim = 0.0
var drop_through_time = 0.0
var melee_side = 1
var executing_commander = false
var execution_target = null
var execution_time = 0.0
var execution_cut_done = false
var holding_boss_head = false
var helicopter_ride = null

@onready var sprite = $Sprite
@onready var collision = $CollisionShape2D
@onready var camera = $Camera2D
@onready var rifle = $Rifle

const STAND_COLLISION_HEIGHT := 46.0
const STAND_COLLISION_RADIUS := 12.0
const STAND_COLLISION_Y := 2.0
const CROUCH_COLLISION_HEIGHT := 28.0
const CROUCH_COLLISION_RADIUS := 11.0
const CROUCH_COLLISION_Y := 11.0

func _ready():
    add_to_group("player")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    terrain = get_tree().get_first_node_in_group("destructible_terrain")
    respawn_position = global_position
    fire_input_armed = not Input.is_action_pressed("fire")
    GameState.set_health(max_health)
    GameState.screen_shake_requested.connect(_on_screen_shake)
    _update_rifle_visual()

func _physics_process(delta):
    if not alive:
        return
    if executing_commander:
        _update_boss_execution(delta)
        return
    if helicopter_ride != null and is_instance_valid(helicopter_ride):
        _update_helicopter_ride(delta)
        return
    if extracting:
        velocity = Vector2.ZERO
        global_position = global_position.move_toward(extraction_target, 190.0 * delta)
        crouching = false
        _set_crouch_collider(false)
        sprite.rotation = 0.0
        sprite.position.y = 0.0
        sprite.frame = 0
        if global_position.distance_to(extraction_target) < 5.0:
            extraction_hold += delta
        _update_camera_shake(delta)
        return
    fire_cooldown = max(0.0, fire_cooldown - delta)
    grenade_cooldown = max(0.0, grenade_cooldown - delta)
    invincible = max(0.0, invincible - delta)
    wall_regrab_cooldown = max(0.0, wall_regrab_cooldown - delta)
    wall_jump_recent = max(0.0, wall_jump_recent - delta)
    roll_cooldown = max(0.0, roll_cooldown - delta)
    melee_cooldown = max(0.0, melee_cooldown - delta)
    melee_anim = max(0.0, melee_anim - delta)
    drop_through_time = max(0.0, drop_through_time - delta)
    coyote = 0.10 if is_on_floor() else max(0.0, coyote - delta)

    var horizontal = Input.get_axis("move_left", "move_right")
    var vertical = Input.get_axis("move_up", "move_down")
    var down = Input.is_action_pressed("move_down")
    var up = Input.is_action_pressed("move_up")
    var jump_pressed = Input.is_action_just_pressed("jump")
    if abs(horizontal) > 0.15:
        facing = 1 if horizontal > 0 else -1
    # One authoritative 8-way aim resolver is used in every movement state.
    # This prevents crouch/ladder/wall/roll states from silently overriding diagonal aim.
    _resolve_aim(horizontal, up, down, is_on_floor())

    var ladder_here = _find_ladder()
    if on_ladder != null and (not is_instance_valid(on_ladder) or not on_ladder.contains_world_point(global_position)):
        on_ladder = null
    if on_ladder == null and ladder_here != null and abs(vertical) > 0.15:
        _release_wall_knife(false)
        on_ladder = ladder_here
        velocity = Vector2.ZERO
        if down:
            global_position.x = move_toward(global_position.x, ladder_here.global_position.x, 18.0)
            global_position.y += 10.0

    var movement_handled = false

    if rolling:
        _release_wall_knife(false)
        on_ladder = null
        crouching = true
        _set_crouch_collider(true)
        roll_time = max(0.0, roll_time - delta)
        velocity.x = float(roll_dir) * roll_speed
        if not is_on_floor():
            velocity.y += 1400.0 * delta
        else:
            velocity.y = min(velocity.y, 0.0)
        move_and_slide()
        if roll_time <= 0.0 or is_on_wall():
            _end_roll()
        movement_handled = true

    elif on_ladder != null:
        _release_wall_knife(false)
        crouching = false
        _set_crouch_collider(false)
        velocity.x = horizontal * move_speed * 0.45
        velocity.y = vertical * ladder_speed
        if jump_pressed:
            on_ladder = null
            velocity.y = -jump_speed * 0.82
            velocity.x = facing * move_speed * 0.6
        move_and_slide()
        movement_handled = true

        _resolve_aim(horizontal, Input.is_action_pressed("move_up"), Input.is_action_pressed("move_down"), false)

    elif wall_knife:
        crouching = false
        _set_crouch_collider(false)
        _resolve_aim(horizontal, up, down, false)

        if jump_pressed:
            var old_wall_side = wall_side
            var launch_side = -old_wall_side
            wall_climb_wall_side = old_wall_side
            wall_jump_recent = wall_climb_assist_time
            _release_wall_knife(true)
            facing = launch_side
            velocity = Vector2(float(launch_side) * wall_knife_jump_x, -wall_knife_jump_y)
            jumps_used = 1
            flip_time = 0.22
            move_and_slide()
            movement_handled = true
        elif not _wall_exists(wall_side):
            _release_wall_knife(false)
        else:
            wall_hold_left = max(0.0, wall_hold_left - delta)
            # A tiny push keeps the body seated against the wall while the knife is embedded.
            velocity.x = float(wall_side) * 22.0
            velocity.y = 0.0 if wall_hold_left > 0.0 else wall_knife_slide_speed
            move_and_slide()
            if is_on_floor() or not _wall_exists(wall_side):
                _release_wall_knife(false)
            movement_handled = true

    # DOWN + JUMP with little/no horizontal input intentionally drops through one-way ledges.
    if not movement_handled and on_ladder == null and is_on_floor() and down and abs(horizontal) < 0.15 and jump_pressed:
        global_position.y += 13.0
        velocity.y = 150.0
        coyote = 0.0
        drop_through_time = 0.22
        move_and_slide()
        movement_handled = true

    if not movement_handled and on_ladder == null and is_on_floor() and down and abs(horizontal) > 0.15 and jump_pressed and roll_cooldown <= 0.0:
        _start_roll(horizontal)
        velocity.x = float(roll_dir) * roll_speed
        velocity.y = 0.0
        move_and_slide()
        movement_handled = true

    if not movement_handled and on_ladder == null:
        var wants_crouch = is_on_floor() and down and abs(horizontal) < 0.15
        # If the player released DOWN under a low ceiling, stay crouched until there is room to stand.
        if crouching and not wants_crouch and not _has_headroom():
            crouching = true
        else:
            crouching = wants_crouch
        _set_crouch_collider(crouching)
        var target_speed = horizontal * move_speed
        if crouching: target_speed = 0.0
        var move_accel = 1700.0 if is_on_floor() else 900.0
        # After a knife jump, pressing back toward the same wall gives stronger air steering.
        # This makes stab -> jump -> re-stab a reliable way to climb a vertical shaft.
        if not is_on_floor() and wall_jump_recent > 0.0 and wall_climb_wall_side != 0 and abs(horizontal) > 0.15 and int(sign(horizontal)) == wall_climb_wall_side:
            move_accel = 2100.0
        velocity.x = move_toward(velocity.x, target_speed, move_accel * delta)
        if not is_on_floor():
            velocity.y += 1400.0 * delta
        else:
            jumps_used = 0
        if jump_pressed:
            if is_on_floor() or coyote > 0.0:
                velocity.y = -jump_speed
                jumps_used = 1
                coyote = 0.0
            elif jumps_used < 2:
                velocity.y = -jump_speed * 0.92
                jumps_used = 2
                flip_time = 0.36
        move_and_slide()

        _resolve_aim(horizontal, up, down, is_on_floor())

        if _can_start_wall_knife(horizontal):
            _start_wall_knife()

    _update_auto_melee()

    var fire_now = Input.is_action_pressed("fire")
    if not fire_now:
        fire_input_armed = true
    if fire_now and fire_input_armed and fire_cooldown <= 0.0:
        _shoot()
    if Input.is_action_just_pressed("grenade") and grenade_cooldown <= 0.0:
        _throw_grenade()

    _update_visual(delta, horizontal)
    _update_camera_shake(delta)

func _start_roll(horizontal):
    rolling = true
    roll_time = roll_duration
    roll_cooldown = roll_cooldown_time
    roll_dir = 1 if horizontal > 0.0 else -1
    facing = roll_dir
    crouching = true
    _set_crouch_collider(true)
    flip_time = 0.0
    sprite.rotation = 0.0

func _end_roll():
    if not rolling:
        return
    rolling = false
    roll_time = 0.0
    roll_cooldown = roll_cooldown_time
    sprite.rotation = 0.0
    if _has_headroom():
        _set_crouch_collider(false)
        crouching = false

func set_checkpoint(pos: Vector2):
    respawn_position = pos

func _resolve_aim(horizontal: float, up: bool, down: bool, grounded: bool):
    # True 8-way aim. Horizontal input chooses the facing half of diagonals.
    # On the ground, DOWN by itself remains the familiar crouch/straight-fire pose.
    if up and abs(horizontal) > 0.15:
        aim_dir = Vector2(facing,-1.0).normalized()
    elif down and abs(horizontal) > 0.15:
        aim_dir = Vector2(facing,1.0).normalized()
    elif up:
        aim_dir = Vector2.UP
    elif down and not grounded:
        aim_dir = Vector2.DOWN
    else:
        aim_dir = Vector2(float(facing),0.0)

func _can_start_wall_knife(horizontal) -> bool:
    if wall_knife or wall_regrab_cooldown > 0.0 or on_ladder != null or is_on_floor():
        return false
    # Re-grabbing is allowed while rising. This is what makes repeated wall-knife climbing possible.
    if not is_on_wall():
        return false
    var normal = get_wall_normal()
    if abs(normal.x) < 0.55:
        return false
    var candidate_side = int(-sign(normal.x))
    if candidate_side == 0 or abs(horizontal) < 0.18:
        return false
    return int(sign(horizontal)) == candidate_side

func _start_wall_knife():
    var normal = get_wall_normal()
    wall_side = int(-sign(normal.x))
    if wall_side == 0:
        return
    wall_knife = true
    wall_hold_left = wall_knife_hold_time
    wall_climb_wall_side = wall_side
    wall_jump_recent = 0.0
    crouching = false
    _set_crouch_collider(false)
    flip_time = 0.0
    sprite.rotation = 0.0
    velocity = Vector2.ZERO
    jumps_used = min(jumps_used, 1)
    if not wall_knife_hint_shown:
        wall_knife_hint_shown = true
        GameState.message_requested.emit("WALL KNIFE — JUMP UP + PRESS BACK INTO WALL TO CLIMB")
    _knife_stab_effect()
    queue_redraw()

func _release_wall_knife(add_cooldown = false):
    if not wall_knife:
        return
    wall_knife = false
    wall_side = 0
    wall_hold_left = 0.0
    if add_cooldown:
        wall_regrab_cooldown = wall_knife_regrab_delay
    queue_redraw()

func _wall_exists(side) -> bool:
    if side == 0:
        return false
    return test_move(global_transform, Vector2(float(side) * 5.0, 0.0))

func _knife_stab_effect():
    var scene = preload("res://scenes/Burst.tscn")
    var b = scene.instantiate()
    b.global_position = global_position + Vector2(float(wall_side) * 15.0, -2.0)
    b.burst_kind = "stone"
    b.scale = Vector2(0.34,0.34)
    get_tree().current_scene.add_child(b)

func _set_crouch_collider(active: bool):
    var shape = collision.shape as CapsuleShape2D
    if shape == null:
        return
    if active:
        shape.radius = CROUCH_COLLISION_RADIUS
        shape.height = CROUCH_COLLISION_HEIGHT
        collision.position.y = CROUCH_COLLISION_Y
    else:
        shape.radius = STAND_COLLISION_RADIUS
        shape.height = STAND_COLLISION_HEIGHT
        collision.position.y = STAND_COLLISION_Y

func _has_headroom() -> bool:
    # Only test the space the standing upper body needs; this avoids the floor itself
    # counting as an obstruction when switching back from crouch.
    var head_shape = RectangleShape2D.new()
    head_shape.size = Vector2(20.0, 17.0)
    var query = PhysicsShapeQueryParameters2D.new()
    query.shape = head_shape
    query.transform = Transform2D(0.0, global_position + Vector2(0, -12.0))
    query.collision_mask = 1
    query.exclude = [get_rid()]
    query.collide_with_bodies = true
    query.collide_with_areas = false
    return get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _find_ladder():
    for ladder in get_tree().get_nodes_in_group("ladder"):
        if not is_instance_valid(ladder):
            continue
        # Check both body center and feet so DOWN can grab a ladder from the platform above it.
        if ladder.contains_world_point(global_position) or ladder.contains_world_point(global_position + Vector2(0,22)) or ladder.contains_world_point(global_position + Vector2(0,34)):
            return ladder
        # Also allow DOWN to catch the top of a ladder from a ledge even if the body center is just above its Area2D.
        if Input.is_action_pressed("move_down") and abs(global_position.x-ladder.global_position.x) < 28.0 and global_position.y <= ladder.global_position.y and global_position.y > ladder.global_position.y-ladder.ladder_size.y*0.62-30.0:
            return ladder
    return null

func _shoot():
    fire_cooldown = 0.105
    AudioManager.play_sfx("shoot",-6.0,randf_range(0.97,1.03))
    shot_flip = not shot_flip
    var spread = 0.035 if shot_flip else -0.035
    var shot_dir = aim_dir.rotated(spread).normalized()
    # Lower the weapon with the crouch so ducking and firing reads correctly.
    var shot_origin = global_position + Vector2(0, 5 if crouching else -5)
    var muzzle = shot_origin + aim_dir * 30.0
    if terrain == null: terrain = get_tree().get_first_node_in_group("destructible_terrain")
    if terrain:
        terrain.damage_segment(shot_origin + aim_dir * 9.0, muzzle, 1.25, aim_dir)
    var bullet_scene = preload("res://scenes/Bullet.tscn")
    var bullet = bullet_scene.instantiate()
    bullet.team = "player"
    bullet.direction = shot_dir
    bullet.global_position = muzzle
    bullet.damage = 1.0
    bullet.terrain_damage = 1.25
    get_tree().current_scene.add_child(bullet)

func _throw_grenade():
    if not GameState.use_grenade():
        return
    grenade_cooldown = 0.45
    AudioManager.play_sfx("grenade",-7.0)
    var scene = preload("res://scenes/Grenade.tscn")
    var g = scene.instantiate()
    g.global_position = global_position + Vector2(facing * 18.0, -12.0)
    g.velocity = Vector2(facing * 390.0, -430.0)
    g.terrain = terrain
    get_tree().current_scene.add_child(g)

func _update_auto_melee(preserve_aim := false):
    if melee_cooldown > 0.0 or rolling or wall_knife or executing_commander:
        return
    var best = null
    # During the victory fly-back, let the hanging player knife enemies that pass close by.
    var best_dist = 62.0 if helicopter_ride != null else 48.0
    for enemy in get_tree().get_nodes_in_group("enemy"):
        if not is_instance_valid(enemy) or enemy.is_in_group("boss") or enemy.is_in_group("boss_commander"):
            continue
        if not enemy.has_method("take_damage"):
            continue
        var dist = global_position.distance_to(enemy.global_position)
        if dist < best_dist:
            var query = PhysicsRayQueryParameters2D.create(global_position,enemy.global_position)
            query.collision_mask = 1
            query.exclude = [get_rid()]
            query.collide_with_areas = false
            if get_world_2d().direct_space_state.intersect_ray(query).is_empty():
                best_dist = dist
                best = enemy
    if best == null:
        return
    melee_side = 1 if best.global_position.x >= global_position.x else -1
    if not preserve_aim:
        facing = melee_side
    melee_cooldown = 0.30 if helicopter_ride != null else 0.34
    melee_anim = 0.22 if helicopter_ride != null else 0.19
    AudioManager.play_sfx("knife", -9.0, randf_range(0.96,1.04))
    best.take_damage(3.0 if helicopter_ride != null else 2.0, global_position)
    var b = preload("res://scenes/Burst.tscn").instantiate()
    b.global_position = global_position + Vector2(float(melee_side) * 22.0,-4.0)
    b.burst_kind = "stone" if best.is_in_group("digger") else "orange"
    b.scale = Vector2(0.30,0.30)
    get_tree().current_scene.add_child(b)

func start_boss_execution(commander):
    if executing_commander or holding_boss_head or commander == null or not is_instance_valid(commander):
        return
    _release_wall_knife(false)
    _end_roll()
    on_ladder = null
    executing_commander = true
    execution_target = commander
    execution_time = 0.0
    execution_cut_done = false
    GameState.victory_invincible = true
    velocity = Vector2.ZERO
    GameState.message_requested.emit("FINISH HIM!")

func _update_boss_execution(delta):
    fire_cooldown = max(0.0, fire_cooldown - delta)
    melee_anim = max(0.0, melee_anim - delta)
    drop_through_time = max(0.0, drop_through_time - delta)
    execution_time += delta
    if execution_target == null or not is_instance_valid(execution_target):
        executing_commander = false
        return
    var dx = execution_target.global_position.x - global_position.x
    facing = 1 if dx >= 0.0 else -1
    aim_dir = Vector2(facing,0)
    if execution_time < 0.24:
        velocity.x = sign(dx) * min(180.0, abs(dx) * 6.0)
        if not is_on_floor():
            velocity.y += 1400.0 * delta
        move_and_slide()
    else:
        velocity = Vector2.ZERO
    if execution_time >= 0.30 and execution_time < 0.62:
        melee_side = facing
        melee_anim = max(melee_anim, 0.12)
    if execution_time >= 0.52 and not execution_cut_done:
        execution_cut_done = true
        holding_boss_head = true
        if execution_target.has_method("behead"):
            execution_target.behead()
        GameState.message_requested.emit("HEAD TAKEN — HOLD IT HIGH!")
    _update_visual(delta,0.0)
    _update_camera_shake(delta)
    if execution_time >= 0.95:
        executing_commander = false
        execution_target = null
        velocity = Vector2.ZERO

func start_helicopter_ride(heli):
    if helicopter_ride != null or heli == null:
        return
    _release_wall_knife(false)
    _end_roll()
    on_ladder = null
    extracting = false
    helicopter_ride = heli
    holding_boss_head = true
    GameState.victory_invincible = true
    collision.set_deferred("disabled", true)
    velocity = Vector2.ZERO
    facing = -1
    aim_dir = Vector2.LEFT
    if heli.has_method("begin_flight_with_player"):
        heli.begin_flight_with_player(self)
    GameState.start_victory_flight()

func _update_helicopter_ride(delta):
    fire_cooldown = max(0.0, fire_cooldown - delta)
    grenade_cooldown = max(0.0, grenade_cooldown - delta)
    melee_cooldown = max(0.0, melee_cooldown - delta)
    melee_anim = max(0.0, melee_anim - delta)
    drop_through_time = max(0.0, drop_through_time - delta)
    if helicopter_ride == null or not is_instance_valid(helicopter_ride):
        helicopter_ride = null
        return
    var horizontal = Input.get_axis("move_left", "move_right")
    var vertical = Input.get_axis("move_up", "move_down")
    if helicopter_ride.has_method("set_vertical_input"):
        helicopter_ride.set_vertical_input(vertical)
    if helicopter_ride.has_method("get_rider_position"):
        global_position = helicopter_ride.get_rider_position()
    if abs(horizontal) > 0.15:
        facing = 1 if horizontal > 0.0 else -1
    else:
        facing = -1
    var up = Input.is_action_pressed("move_up")
    var down = Input.is_action_pressed("move_down")
    _resolve_aim(horizontal, up, down, false)
    var fire_now = Input.is_action_pressed("fire")
    if not fire_now:
        fire_input_armed = true
    if fire_now and fire_input_armed and fire_cooldown <= 0.0:
        _shoot()
    if Input.is_action_just_pressed("grenade") and grenade_cooldown <= 0.0:
        _throw_grenade()
    # Auto-stab nearby enemies during the fly-back without changing the current firing aim.
    _update_auto_melee(true)
    _collect_flyby_treasure()
    crouching = false
    sprite.rotation = 0.0
    sprite.position.y = 0.0
    sprite.frame = 0
    _update_visual(delta,horizontal)
    _update_camera_shake(delta)
    queue_redraw()


func _collect_flyby_treasure():
    if helicopter_ride == null:
        return
    var best = null
    var best_dist := 96.0
    for treasure in get_tree().get_nodes_in_group("treasure"):
        if not is_instance_valid(treasure) or not treasure.has_method("collect_by_flyby"):
            continue
        var d = global_position.distance_to(treasure.global_position)
        if d < best_dist:
            best_dist = d
            best = treasure
    if best != null:
        best.collect_by_flyby()
        GameState.add_score(75)

func start_extraction(target_position: Vector2):
    if extracting:
        return
    _release_wall_knife(false)
    on_ladder = null
    extracting = true
    extraction_target = target_position
    extraction_hold = 0.0
    velocity = Vector2.ZERO
    collision.set_deferred("disabled", true)
    GameState.message_requested.emit("EXTRACTING...")

func update_extraction_target(target_position: Vector2):
    if extracting:
        extraction_target = target_position

func take_damage(amount, hit_position = Vector2.ZERO):
    if GameState.victory_invincible or rolling or invincible > 0.0 or not alive:
        return
    _release_wall_knife(false)
    max_health = max(1, max_health)
    GameState.set_health(GameState.health - int(ceil(amount)))
    AudioManager.play_sfx("hit",-6.0)
    invincible = 0.65
    velocity.y = -220.0
    if hit_position != Vector2.ZERO:
        velocity.x = sign(global_position.x - hit_position.x) * 180.0
    if GameState.health <= 0:
        _die()

func _die():
    _release_wall_knife(false)
    _end_roll()
    alive = false
    sprite.modulate = Color(1.0,0.35,0.35)
    velocity = Vector2.ZERO
    collision.set_deferred("disabled", true)
    await get_tree().create_timer(0.8).timeout
    var result = GameState.lose_life()
    if result == "game_over":
        GameState.message_requested.emit("MISSION FAILED")
        GameState.request_game_over()
        return
    _respawn(result == "continue")

func _respawn(used_continue = false):
    alive = true
    extracting = false
    helicopter_ride = null
    executing_commander = false
    execution_target = null
    holding_boss_head = false
    rolling = false
    global_position = respawn_position
    velocity = Vector2.ZERO
    jumps_used = 0
    on_ladder = null
    crouching = false
    _set_crouch_collider(false)
    collision.set_deferred("disabled", false)
    sprite.modulate = Color.WHITE
    sprite.rotation = 0.0
    sprite.position.y = 0.0
    invincible = 1.35
    fire_input_armed = not Input.is_action_pressed("fire")
    GameState.set_health(max_health)
    if used_continue:
        GameState.message_requested.emit("CONTINUE USED — 5 LIVES RESTORED")
    else:
        GameState.message_requested.emit("LIFE LOST — %d LIVES LEFT" % GameState.lives)

func _update_visual(delta, horizontal):
    sprite.flip_h = facing < 0
    if rolling:
        sprite.frame = 12 + int(float(Time.get_ticks_msec()) / 90.0) % 2
        sprite.position.y = 8.0
        sprite.rotation += float(roll_dir) * TAU * delta / max(0.18, roll_duration)
    elif wall_knife:
        sprite.frame = 0
        sprite.position.y = 0.0
        sprite.rotation = -0.07 * float(wall_side)
    elif crouching:
        sprite.frame = 12 + int(float(Time.get_ticks_msec()) / 180.0) % 2
        sprite.position.y = 9.0
    else:
        sprite.position.y = 0.0
        if abs(horizontal) > 0.1 and is_on_floor():
            sprite.frame = int(float(Time.get_ticks_msec()) / 95.0) % 10
        else:
            sprite.frame = 0
    if not wall_knife and not rolling and flip_time > 0.0:
        flip_time -= delta
        sprite.rotation += float(facing) * TAU * delta / 0.36
        if flip_time <= 0.0: sprite.rotation = 0.0
    elif not wall_knife and not rolling and sprite.rotation != 0.0:
        sprite.rotation = 0.0
    if invincible > 0.0:
        sprite.modulate.a = 0.52 if fmod(invincible,0.12) < 0.06 else 1.0
    else:
        sprite.modulate = Color.WHITE
    _update_rifle_visual()
    queue_redraw()

func _update_rifle_visual():
    if rifle == null:
        return
    # The rifle is a separate sprite so it remains visible in every movement/aim state.
    var dir = aim_dir.normalized() if aim_dir.length() > 0.1 else Vector2(float(facing),0.0)
    var left = dir.x < -0.05
    var visual_angle = atan2(dir.y, max(abs(dir.x),0.05))
    rifle.flip_h = left
    rifle.rotation = visual_angle
    var base_y = 6.0 if crouching else -5.0
    if rolling:
        base_y = 7.0
    elif wall_knife:
        base_y = -4.0
    rifle.position = Vector2((-1.0 if left else 1.0) * 12.0, base_y) + dir * 5.0
    rifle.visible = alive and not executing_commander
    rifle.modulate = Color(1.0,1.0,1.0,0.55 if invincible > 0.0 and fmod(invincible,0.12) < 0.06 else 1.0)

func _draw():
    # Boss head stays raised through the fireworks, the jump to the ladder, and the victory flight.
    if holding_boss_head:
        # Keep the trophy head identical to the ejected commander: orange face + yellow hair.
        var hx = -13.0 * float(facing)
        draw_line(Vector2(hx*0.35,-14),Vector2(hx,-39),Color("e1973f"),4.5)
        draw_circle(Vector2(hx,-49),9.0,Color("ef8b2d"))
        draw_circle(Vector2(hx-3.0,-50.0),1.2,Color.WHITE)
        draw_circle(Vector2(hx+3.0,-50.0),1.2,Color.WHITE)
        draw_circle(Vector2(hx-2.8,-50.0),0.55,Color("4a2a1b"))
        draw_circle(Vector2(hx+3.2,-50.0),0.55,Color("4a2a1b"))
        draw_line(Vector2(hx-3.5,-44),Vector2(hx+3.5,-44),Color("8a381e"),1.7)
        # Bright yellow swept/fringed hair, matching BossCommander.gd.
        draw_colored_polygon(PackedVector2Array([
            Vector2(hx-8.5,-55),Vector2(hx-5.0,-60),Vector2(hx+3.5,-61),
            Vector2(hx+8.5,-56),Vector2(hx+7.0,-52),Vector2(hx-8.0,-52)
        ]),Color("ffe148"))
        draw_rect(Rect2(hx-7.0,-53.5,14.0,2.8),Color("ffe148"))
        # Small severed-neck base so it still reads as the same trophy head while raised.
        draw_circle(Vector2(hx,-40.5),3.4,Color("681018"))

    # Automatic close-range knife slash.
    if melee_anim > 0.0:
        var t = clamp(melee_anim / 0.19,0.0,1.0)
        var s = float(melee_side)
        var hand = Vector2(s*8.0,-1.0)
        var tip = Vector2(s*(28.0 + (1.0-t)*7.0),-13.0 + t*12.0)
        draw_line(hand,tip,Color(0.84,0.90,0.91),4.0)
        draw_line(hand+Vector2(0,2),tip,Color.WHITE,1.0)
        draw_arc(Vector2(s*10,-2),25.0,-1.1 if s>0 else PI+0.1,0.65 if s>0 else PI+1.75,14,Color(1.0,0.86,0.46,0.65),2.0)

    if wall_knife and wall_side != 0:
        var wall_draw_side = float(wall_side)
        var wall_hand = Vector2(wall_draw_side * 5.0, -2.0)
        var guard = Vector2(wall_draw_side * 14.0, -2.0)
        var wall_tip = Vector2(wall_draw_side * 30.0, -4.0)
        draw_line(wall_hand, guard, Color(0.22,0.16,0.10), 5.0)
        draw_circle(guard, 2.8, Color(0.88,0.67,0.24))
        var blade = PackedVector2Array([
            guard + Vector2(0,-2.2),
            wall_tip,
            guard + Vector2(0,2.2)
        ])
        draw_colored_polygon(blade, Color(0.80,0.86,0.88))
        draw_line(guard, wall_tip, Color(1.0,1.0,1.0,0.75), 1.0)
        if wall_hold_left <= 0.0:
            var flick = 2.0 + fmod(float(Time.get_ticks_msec()) / 80.0, 4.0)
            draw_line(wall_tip + Vector2(-wall_draw_side * 2.0,2.0), wall_tip + Vector2(-wall_draw_side * 6.0, flick + 4.0), Color(1.0,0.55,0.12,0.85), 1.4)

    # Small muzzle-direction chevrons make diagonal/vertical aim readable without a giant laser sight.
    if not executing_commander and aim_dir.length() > 0.5 and (abs(aim_dir.y) > 0.20):
        var a0 = Vector2(0,-5) + aim_dir * 31.0
        var side = Vector2(-aim_dir.y,aim_dir.x)
        draw_line(a0, a0 + aim_dir*11.0 + side*3.0, Color(1.0,0.88,0.42,0.50), 1.5)
        draw_line(a0, a0 + aim_dir*11.0 - side*3.0, Color(1.0,0.88,0.42,0.50), 1.5)

func _on_screen_shake(strength):
    camera_shake = max(camera_shake, float(strength))

func _update_camera_shake(delta):
    if camera_shake > 0.05:
        camera.offset = Vector2(randf_range(-camera_shake, camera_shake), randf_range(-camera_shake * 0.65, camera_shake * 0.65))
        camera_shake = move_toward(camera_shake, 0.0, 34.0 * delta)
    else:
        camera_shake = 0.0
        camera.offset = Vector2.ZERO

func _notification(what):
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        fire_input_armed = false
