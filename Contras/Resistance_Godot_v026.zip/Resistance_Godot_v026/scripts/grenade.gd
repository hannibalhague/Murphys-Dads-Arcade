extends CharacterBody2D

@export var fuse = 1.25
@export var blast_radius = 132.0
var terrain = null
var age = 0.0

func _ready():
    collision_layer = 0
    collision_mask = 1
    queue_redraw()

func _physics_process(delta):
    age += delta
    velocity.y += 1200.0 * delta
    var collision = move_and_collide(velocity * delta)
    if collision:
        var n = collision.get_normal()
        velocity = velocity.bounce(n) * 0.48
        if abs(velocity.y) < 55.0: velocity.y = 0.0
    rotation += velocity.x * delta * 0.025
    if age >= fuse:
        explode()

func explode():
    if terrain == null:
        terrain = get_tree().get_first_node_in_group("destructible_terrain")
    if terrain:
        terrain.damage_at_world(global_position, 4.1, 3)
    for enemy in get_tree().get_nodes_in_group("enemy"):
        if is_instance_valid(enemy) and enemy.global_position.distance_to(global_position) <= blast_radius:
            var scale = 1.0 - enemy.global_position.distance_to(global_position) / blast_radius
            enemy.take_damage(2.0 + 3.0 * scale, global_position)
    for prop in get_tree().get_nodes_in_group("damageable_prop"):
        if is_instance_valid(prop) and prop.global_position.distance_to(global_position) <= blast_radius:
            prop.take_damage(4.0, global_position)
    GameState.screen_shake_requested.emit(14.0)
    _spawn_burst("orange",2.25)
    _spawn_burst("smoke",2.70)
    _spawn_burst("dirt",1.55)
    queue_free()

func _spawn_burst(kind, burst_scale):
    var scene = preload("res://scenes/Burst.tscn")
    var b = scene.instantiate()
    b.global_position = global_position
    b.burst_kind = kind
    b.scale = Vector2(burst_scale,burst_scale)
    get_tree().current_scene.add_child(b)

func _draw():
    draw_circle(Vector2.ZERO, 7.0, Color(0.18,0.22,0.18))
    draw_circle(Vector2(-1,-1), 4.0, Color(0.35,0.43,0.31))
    var blink = fmod(age,0.22) < 0.11
    draw_circle(Vector2(5,-7), 2.5, Color(1.0,0.25,0.08) if blink else Color(1.0,0.75,0.18))
