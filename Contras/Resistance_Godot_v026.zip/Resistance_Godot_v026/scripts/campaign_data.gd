extends RefCounted

const BASE_WORLD := 5200.0
const WORLD := 7000.0
const SCALE := WORLD / BASE_WORLD

const LEVELS = [
    {"name":"JUNGLE OUTSKIRTS","boss":"HOT AIR BALLOON","theme":"jungle","sky":[Color("102c43"),Color("8eaa8e"),Color("d5c78f")],"ground":[Color("46543a"),Color("1d2d22")],"edge":Color("9daf70"),"water":[Color("439db0"),Color("123b59")],"layout":0},
    {"name":"DESERT BASE","boss":"MAMMOTH TANK","theme":"desert","sky":[Color("563126"),Color("bc7441"),Color("efc47f")],"ground":[Color("725034"),Color("37291f")],"edge":Color("c79a59"),"water":[Color("5d8290"),Color("29424b")],"layout":1},
    {"name":"NAVAL HARBOR","boss":"IRONCLAD WARSHIP","theme":"harbor","sky":[Color("153b5b"),Color("4f86a1"),Color("c4d8cc")],"ground":[Color("4a5050"),Color("252c30")],"edge":Color("879292"),"water":[Color("277c9d"),Color("0e3c5b")],"layout":2},
    {"name":"ICE BUNKER","boss":"WAR BLIMP","theme":"ice","sky":[Color("17314f"),Color("6589a8"),Color("d7e7ef")],"ground":[Color("60717b"),Color("283741")],"edge":Color("d7eef5"),"water":[Color("5a9ebe"),Color("1e4965")],"layout":3},
    {"name":"ALIEN CAVES","boss":"TITAN BAT","theme":"cave","sky":[Color("120e2b"),Color("34245f"),Color("654a7d")],"ground":[Color("342746"),Color("191423")],"edge":Color("8e6bad"),"water":[Color("5b3d91"),Color("261745")],"layout":1},
    {"name":"ROBOT FACTORY","boss":"AI COLOSSUS","theme":"factory","sky":[Color("171c22"),Color("39434a"),Color("7d765f")],"ground":[Color("444b48"),Color("1f2525")],"edge":Color("9f966f"),"water":[Color("526b66"),Color("263a38")],"layout":2},
    {"name":"TOXIC WASTES","boss":"TOXIC BEHEMOTH","theme":"toxic","sky":[Color("2e173d"),Color("65486d"),Color("8d8b53")],"ground":[Color("4b5133"),Color("242819")],"edge":Color("9fa24c"),"water":[Color("80a22f"),Color("324116")],"layout":0},
    {"name":"SKY FORTRESS","boss":"SIEGE DRONE","theme":"skyfort","sky":[Color("07152d"),Color("193e67"),Color("536b86")],"ground":[Color("384650"),Color("172129")],"edge":Color("8299a2"),"water":[Color("385c7c"),Color("162b43")],"layout":3},
    {"name":"LAVA FORTRESS","boss":"MAGMA BEAST","theme":"lava","sky":[Color("2d0d0a"),Color("7f2b13"),Color("e07126")],"ground":[Color("44302b"),Color("1d1514")],"edge":Color("b85a2e"),"water":[Color("f05a18"),Color("7d190c")],"layout":1},
    {"name":"ALIEN NEXUS","boss":"DREAD WALKER","theme":"nexus","sky":[Color("090b25"),Color("2d2457"),Color("66487a")],"ground":[Color("302b43"),Color("151421")],"edge":Color("8272a5"),"water":[Color("47449a"),Color("1a1d4e")],"layout":2}
]

const LAYOUTS = [
    {"g":[[0,970],[1060,1740],[1825,2520],[2600,3340],[3425,4140],[4220,5200]],"l":[[500,338,190],[1310,310,200],[2110,325,220],[2860,295,190],[3640,322,220],[4480,300,230]],"w":[[970,1060],[1740,1825],[2520,2600],[3340,3425],[4140,4220]]},
    {"g":[[0,820],[900,1570],[1650,2320],[2400,3070],[3150,3810],[3890,4590],[4670,5200]],"l":[[420,315,180],[1120,350,190],[1930,292,230],[2670,340,180],[3370,300,250],[4210,328,220],[4740,282,180]],"w":[[820,900],[1570,1650],[2320,2400],[3070,3150],[3810,3890],[4590,4670]]},
    {"g":[[0,1120],[1200,2040],[2120,2880],[2960,3760],[3840,4520],[4600,5200]],"l":[[620,300,220],[1480,345,210],[2380,306,190],[3220,280,240],[4110,335,230],[4760,300,200]],"w":[[1120,1200],[2040,2120],[2880,2960],[3760,3840],[4520,4600]]},
    {"g":[[0,875],[955,1450],[1530,2220],[2300,2800],[2880,3540],[3620,4300],[4380,5200]],"l":[[360,340,160],[1140,290,200],[1780,335,210],[2480,275,180],[3130,328,220],[3920,292,200],[4670,330,190]],"w":[[875,955],[1450,1530],[2220,2300],[2800,2880],[3540,3620],[4300,4380]]}
]

const UPPER = [
    [[920,238,175],[1670,220,190],[2510,245,170],[3350,212,205],[4240,236,180]],
    [[760,230,180],[1510,210,205],[2420,238,170],[3260,218,200],[4190,235,190]],
    [[980,225,210],[1880,242,180],[2790,214,210],[3690,238,185],[4510,220,200]],
    [[790,238,165],[1570,215,190],[2460,235,180],[3420,210,210],[4300,232,190]]
]

const ENEMY_MIXES = [
    ["scout","dog_guard","soldier","officer","flamer","medic","heavy","dog_attack"],
    ["sandraider","scout","rocketeer","dog_guard","officer","shield","heavy","commando"],
    ["waterraider","diver","dog_water","officer","waterraider","grenadier","rocketeer","commando"],
    ["snowtrooper","dog_snow","iceguard","ninja","scout","heavy","dog_attack","officer"],
    ["alien","mutant","raider","alien","ninja","cyborg","mutant","dog_guard"],
    ["robot","cyborg","shield","robot","commando","officer","dog_attack","rocketeer"],
    ["raider","mutant","medic","cyborg","ninja","flamer","heavy","commando"],
    ["ninja","heavy","officer","commando","drone","cyborg","dog_attack","rocketeer"],
    ["heavy","sandraider","shield","flamer","dog_attack","officer","rocketeer","commando"],
    ["alien","mutant","alien","cyborg","officer","ninja","robot","commando"]
]

const BOSS_HP = {"HOT AIR BALLOON":38.0,"MAMMOTH TANK":50.0,"IRONCLAD WARSHIP":54.0,"WAR BLIMP":46.0,"TITAN BAT":44.0,"AI COLOSSUS":56.0,"TOXIC BEHEMOTH":48.0,"SIEGE DRONE":52.0,"MAGMA BEAST":58.0,"DREAD WALKER":50.0}

static func sx(x: float) -> float:
    return x * SCALE

static func level(index: int) -> Dictionary:
    return LEVELS[clamp(index,0,LEVELS.size()-1)]
