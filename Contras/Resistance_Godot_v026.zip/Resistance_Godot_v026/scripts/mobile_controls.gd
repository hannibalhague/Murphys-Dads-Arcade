extends Control

var move_touch = -1
var move_pos = Vector2.ZERO
var action_touches = {}
var radius = 66.0
var base = Vector2.ZERO

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    visible = DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")
    set_process_input(true)
    set_process(true)
    _release_all_synthetic_actions()
    queue_redraw()

func _process(_delta):
    if not visible:
        return
    var held = {}
    for action in action_touches.values(): held[action] = true
    for action in ["fire","jump","grenade"]:
        if not held.has(action): Input.action_release(action)

func _input(event):
    if not visible: return
    if event is InputEventScreenTouch:
        if event.pressed: _touch_down(event.index,event.position)
        else: _touch_up(event.index)
    elif event is InputEventScreenDrag and event.index == move_touch:
        move_pos = event.position
        _apply_move()
        queue_redraw()

func _touch_down(index,pos):
    var size=get_viewport_rect().size
    base=Vector2(105,size.y-105)
    if pos.x < size.x*0.46 and pos.y > size.y*0.46 and move_touch == -1:
        move_touch=index
        move_pos=pos
        _apply_move()
        queue_redraw()
        return
    var action=_button_at(pos)
    if action!="":
        action_touches[index]=action
        Input.action_press(action)
        queue_redraw()

func _touch_up(index):
    if index==move_touch:
        move_touch=-1
        _release_move()
        queue_redraw()
    if action_touches.has(index):
        Input.action_release(action_touches[index])
        action_touches.erase(index)
        queue_redraw()

func _apply_move():
    var size=get_viewport_rect().size
    base=Vector2(105,size.y-105)
    var v=(move_pos-base)/radius
    if v.length()>1.0: v=v.normalized()
    _set_action_strength("move_left",max(0.0,-v.x))
    _set_action_strength("move_right",max(0.0,v.x))
    _set_action_strength("move_up",max(0.0,-v.y))
    _set_action_strength("move_down",max(0.0,v.y))

func _set_action_strength(action,strength):
    if strength>0.18: Input.action_press(action,strength)
    else: Input.action_release(action)

func _release_move():
    for a in ["move_left","move_right","move_up","move_down"]: Input.action_release(a)

func _button_centers():
    var s=get_viewport_rect().size
    return {
        "fire":Vector2(s.x-82,s.y-116),
        "jump":Vector2(s.x-180,s.y-67),
        "grenade":Vector2(s.x-185,s.y-171)
    }

func _button_at(pos):
    for action in _button_centers().keys():
        if pos.distance_to(_button_centers()[action])<48.0: return action
    return ""

func _draw():
    if not visible:return
    var s=get_viewport_rect().size
    base=Vector2(105,s.y-105)
    var knob=move_pos if move_touch!=-1 else base
    if knob.distance_to(base)>radius: knob=base+(knob-base).normalized()*radius
    draw_circle(base,radius+4,Color(0.02,0.06,0.07,0.34))
    draw_circle(base,radius,Color(0.82,0.92,0.88,0.10))
    draw_circle(base,radius,Color(0.85,0.95,0.90,0.42),false,3.0)
    for a in [0.0,PI*0.5,PI,PI*1.5]:
        var p=base+Vector2(cos(a),sin(a))*48.0
        draw_circle(p,3.0,Color(0.9,0.95,0.9,0.32))
    draw_circle(knob,30,Color(0.07,0.13,0.13,0.72))
    draw_circle(knob,28,Color(0.80,0.91,0.86,0.34))
    draw_circle(knob,28,Color(0.95,0.98,0.95,0.50),false,2.0)
    var centers=_button_centers()
    for action in centers.keys():
        var held=action in action_touches.values()
        var r=47.0 if action=="fire" else 43.0
        draw_circle(centers[action],r+3,Color(0.02,0.04,0.05,0.32))
        draw_circle(centers[action],r,Color(0.76,0.88,0.82,0.30 if held else 0.15))
        draw_circle(centers[action],r,Color(0.94,0.97,0.91,0.50),false,2.5)
        var label="FIRE" if action=="fire" else ("JUMP" if action=="jump" else "GREN")
        draw_string(ThemeDB.fallback_font,centers[action]+Vector2(-22,5),label,HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color(1,1,1,0.92))

func _release_all_synthetic_actions():
    _release_move()
    for a in ["fire","jump","grenade"]:Input.action_release(a)
    action_touches.clear();move_touch=-1

func _exit_tree():_release_all_synthetic_actions()
func _notification(what):
    if what==NOTIFICATION_APPLICATION_FOCUS_OUT:_release_all_synthetic_actions()
