extends Node2D

@export var burst_kind = "orange"
var life = 0.65
var life_max = 0.65
var pieces = []

func _ready():
    if burst_kind == "smoke":
        life = 1.10
        life_max = life
    var rng = RandomNumberGenerator.new()
    rng.seed = int(global_position.x * 19.0 + global_position.y * 31.0) + Time.get_ticks_msec()
    var count = 30 if burst_kind == "orange" else 18
    if burst_kind == "smoke": count = 17
    for i in range(count):
        var a = rng.randf_range(-PI, PI)
        var s = rng.randf_range(45.0, 205.0)
        if burst_kind == "smoke": s = rng.randf_range(20.0, 95.0)
        pieces.append({"p":Vector2.ZERO, "v":Vector2(cos(a),sin(a))*s, "r":rng.randf_range(2.2,5.5)})
    queue_redraw()

func _process(delta):
    life -= delta
    for piece in pieces:
        var v = piece["v"]
        v.y += (85.0 if burst_kind == "smoke" else 310.0) * delta
        if burst_kind == "smoke":
            v *= 0.985
        piece["v"] = v
        piece["p"] = piece["p"] + v * delta
        if burst_kind == "smoke":
            piece["r"] = float(piece["r"]) + 7.0 * delta
    queue_redraw()
    if life <= 0.0:
        queue_free()

func _draw():
    var alpha = clamp(life / life_max, 0.0, 1.0)
    var c = Color(1.0,0.46,0.08,alpha)
    if burst_kind == "wood": c = Color(0.62,0.38,0.16,alpha)
    elif burst_kind == "dirt": c = Color(0.44,0.31,0.18,alpha)
    elif burst_kind == "stone": c = Color(0.58,0.61,0.58,alpha)
    elif burst_kind == "gold": c = Color(1.0,0.84,0.18,alpha)
    elif burst_kind == "cyan": c = Color(0.22,0.92,1.0,alpha)
    elif burst_kind == "health": c = Color(0.38,1.0,0.48,alpha)
    elif burst_kind == "smoke": c = Color(0.27,0.29,0.28,alpha * 0.62)
    for piece in pieces:
        draw_circle(piece["p"], piece["r"], c)
    if burst_kind in ["orange","cyan","gold","health"]:
        var t = 1.0 - alpha
        var ring_color = c
        ring_color.a = alpha * 0.75
        draw_arc(Vector2.ZERO, 12.0 + t * 52.0, 0, TAU, 32, ring_color, 3.0)
        if burst_kind == "orange":
            draw_circle(Vector2.ZERO, max(0.0,18.0*(1.0-t)), Color(1.0,0.85,0.30,alpha*0.55))
