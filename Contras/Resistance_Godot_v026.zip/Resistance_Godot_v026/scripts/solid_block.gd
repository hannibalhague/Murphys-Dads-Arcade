extends StaticBody2D

@export var block_size = Vector2(256, 64)
@export var block_color = Color(0.20, 0.34, 0.20, 1.0)
@export var edge_color = Color(0.46, 0.62, 0.30, 1.0)
@export var one_way := false
@export var organic_top := false

func _ready():
    collision_layer = 1
    collision_mask = 0
    var shape = RectangleShape2D.new()
    shape.size = block_size
    var cs = CollisionShape2D.new()
    cs.shape = shape
    cs.one_way_collision = one_way
    cs.one_way_collision_margin = 8.0
    add_child(cs)
    queue_redraw()

func _draw():
    var r = Rect2(-block_size * 0.5, block_size)
    draw_rect(r, block_color)
    var top_h=min(8.0,r.size.y)
    draw_rect(Rect2(r.position,Vector2(r.size.x,top_h)),edge_color)
    if organic_top:
        var x=r.position.x+4.0
        while x<r.end.x-4.0:
            var top_seed=int(abs(x*17.0+block_size.x*3.0))
            var rad=3.0+float(top_seed%5)
            draw_circle(Vector2(x,r.position.y+2.0+float(top_seed%3)),rad,edge_color.lightened(float(top_seed%3)*0.025))
            x+=7.0+float(top_seed%6)
    var y = r.position.y + 18.0
    while y < r.end.y:
        draw_line(Vector2(r.position.x, y), Vector2(r.end.x, y), block_color.lightened(0.08), 1.0)
        y += 24.0
