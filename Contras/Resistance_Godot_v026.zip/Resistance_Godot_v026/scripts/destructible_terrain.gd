extends StaticBody2D

const TERRAIN_CHUNK_SCRIPT = preload("res://scripts/terrain_chunk.gd")

@export var cell_size = 32
@export var surface_y = 384
@export var visual_chunk_width = 16

var cells = {}
var row_shapes = {}
var chunk_nodes = {}
var pending_collision_rows = {}
var collision_flush_scheduled = false

func _ready():
    collision_layer = 1
    collision_mask = 0
    add_to_group("destructible_terrain")

func fill_world_rect(rect, material_kind = "dirt"):
    var x0 = int(floor(rect.position.x / float(cell_size)))
    var x1 = int(ceil(rect.end.x / float(cell_size))) - 1
    var y0 = int(floor(rect.position.y / float(cell_size)))
    var y1 = int(ceil(rect.end.y / float(cell_size))) - 1
    var touched_rows = {}
    var touched_chunks = {}
    for y in range(y0, y1 + 1):
        touched_rows[y] = true
        for x in range(x0, x1 + 1):
            _add_cell_raw(Vector2i(x,y), material_kind)
            touched_chunks[_chunk_for_x(x)] = true
    _rebuild_rows(touched_rows.keys())
    for chunk_x in touched_chunks.keys():
        _ensure_chunk(int(chunk_x)).queue_redraw()

func add_cell(coord, material_kind = "dirt"):
    if not _add_cell_raw(coord, material_kind):
        return
    _rebuild_row(coord.y)
    _queue_visual_for_coord(coord)

func _add_cell_raw(coord, material_kind = "dirt") -> bool:
    if cells.has(coord):
        return false
    var hp = 2.0
    if material_kind == "rock": hp = 3.4
    elif material_kind == "brick": hp = 2.5
    cells[coord] = {"hp":hp, "max_hp":hp, "material":material_kind}
    _ensure_chunk(_chunk_for_x(coord.x))
    return true

func carve_world_rect(rect):
    var doomed = []
    var touched_rows = {}
    var touched_chunks = {}
    for coord in cells.keys():
        var center = Vector2((coord.x + 0.5) * cell_size, (coord.y + 0.5) * cell_size)
        if rect.has_point(center):
            doomed.append(coord)
            touched_rows[coord.y] = true
            touched_chunks[_chunk_for_x(coord.x)] = true
    for coord in doomed:
        cells.erase(coord)
    _rebuild_rows(touched_rows.keys())
    for chunk_x in touched_chunks.keys():
        _queue_chunk_and_neighbors(int(chunk_x))

func remove_cell(coord):
    if not cells.has(coord):
        return
    cells.erase(coord)
    pending_collision_rows[coord.y] = true
    _schedule_collision_flush()
    _queue_visual_for_coord(coord)

func _schedule_collision_flush():
    if collision_flush_scheduled:
        return
    collision_flush_scheduled = true
    call_deferred("_flush_collision_rows")

func _flush_collision_rows():
    collision_flush_scheduled = false
    var rows = pending_collision_rows.keys()
    pending_collision_rows.clear()
    _rebuild_rows(rows)

func _rebuild_rows(rows):
    for y in rows:
        _rebuild_row(int(y))

func _rebuild_row(y):
    if row_shapes.has(y):
        for cs in row_shapes[y]:
            if is_instance_valid(cs):
                cs.queue_free()
        row_shapes.erase(y)

    var xs = []
    for coord in cells.keys():
        if coord.y == y:
            xs.append(coord.x)
    if xs.is_empty():
        return
    xs.sort()

    var created = []
    var run_start = int(xs[0])
    var run_end = run_start
    for i in range(1, xs.size()):
        var x = int(xs[i])
        if x == run_end + 1:
            run_end = x
        else:
            created.append(_make_run_shape(y, run_start, run_end))
            run_start = x
            run_end = x
    created.append(_make_run_shape(y, run_start, run_end))
    row_shapes[y] = created

func _make_run_shape(y, x0, x1):
    var shape = RectangleShape2D.new()
    shape.size = Vector2(float(x1 - x0 + 1) * cell_size, cell_size)
    var cs = CollisionShape2D.new()
    cs.shape = shape
    cs.position = Vector2((float(x0 + x1 + 1) * 0.5) * cell_size, (float(y) + 0.5) * cell_size)
    add_child(cs)
    return cs

func _chunk_for_x(cell_x):
    return int(floor(float(cell_x) / float(visual_chunk_width)))

func _ensure_chunk(chunk_x):
    if chunk_nodes.has(chunk_x) and is_instance_valid(chunk_nodes[chunk_x]):
        return chunk_nodes[chunk_x]
    var chunk = TERRAIN_CHUNK_SCRIPT.new()
    chunk.name = "TerrainChunk_%d" % chunk_x
    chunk.position = Vector2(chunk_x * visual_chunk_width * cell_size, 0)
    add_child(chunk)
    chunk.setup(self, chunk_x)
    chunk_nodes[chunk_x] = chunk
    return chunk

func _queue_chunk_and_neighbors(chunk_x):
    for cx in [chunk_x - 1, chunk_x, chunk_x + 1]:
        if chunk_nodes.has(cx) and is_instance_valid(chunk_nodes[cx]):
            chunk_nodes[cx].queue_redraw()

func _queue_visual_for_coord(coord):
    _queue_chunk_and_neighbors(_chunk_for_x(coord.x))

func world_to_cell(point):
    var local = to_local(point)
    return Vector2i(int(floor(local.x / float(cell_size))), int(floor(local.y / float(cell_size))))

func has_cell_at_world(point):
    return cells.has(world_to_cell(point))

func damage_cell(coord, amount, hit_position = Vector2.ZERO):
    if not cells.has(coord):
        return false
    var data = cells[coord]
    data["hp"] = float(data["hp"]) - float(amount)
    cells[coord] = data
    if float(data["hp"]) <= 0.0:
        var scene = preload("res://scenes/Burst.tscn")
        var b = scene.instantiate()
        b.global_position = to_global(Vector2((coord.x + 0.5) * cell_size, (coord.y + 0.5) * cell_size))
        b.burst_kind = "stone" if data["material"] in ["rock","brick"] else "dirt"
        get_tree().current_scene.add_child(b)
        remove_cell(coord)
    else:
        _queue_visual_for_coord(coord)
    return true

func damage_at_world(point, amount, radius_cells = 0):
    var center = world_to_cell(point)
    var hit_any = false
    for oy in range(-radius_cells, radius_cells + 1):
        for ox in range(-radius_cells, radius_cells + 1):
            if Vector2(ox,oy).length() > float(radius_cells) + 0.35:
                continue
            if damage_cell(center + Vector2i(ox,oy), amount, point):
                hit_any = true
    return hit_any

func damage_rifle_impact(point, amount, direction):
    var c = world_to_cell(point)
    if not cells.has(c):
        return false
    damage_cell(c, amount, point)
    var side = Vector2i(0, -1)
    if abs(direction.y) > abs(direction.x):
        side = Vector2i(1, 0)
    elif direction.y > 0.15:
        side = Vector2i(0, 1)
    damage_cell(c + side, amount * 0.72, point)
    return true

func damage_segment(from_world, to_world, amount, direction):
    var length = from_world.distance_to(to_world)
    var steps = max(2, int(ceil(length / 6.0)))
    for i in range(steps + 1):
        var p = from_world.lerp(to_world, float(i) / float(steps))
        if has_cell_at_world(p):
            damage_rifle_impact(p, amount, direction)
            return true
    return false

func cell_color(mat):
    if mat == "rock": return Color(0.34,0.36,0.34)
    if mat == "brick": return Color(0.46,0.25,0.17)
    return Color(0.34,0.25,0.15)
