extends Area2D

@export var treasure_kind = "gold"
@export var score_value = 600
var pulse = 0.0
var collected = false

func _ready():
    monitoring = true
    collision_layer = 0
    collision_mask = 2
    body_entered.connect(_on_body_entered)
    add_to_group("treasure")
    queue_redraw()

func _process(delta):
    pulse += delta
    position.y += sin(pulse * 3.2) * 0.025
    queue_redraw()

func _on_body_entered(body):
    if collected or not body.is_in_group("player"):
        return
    collect_now()

func collect_now():
    if collected:
        return
    collected = true
    monitoring = false
    GameState.collect_treasure(treasure_kind, score_value)
    AudioManager.play_sfx("pickup",-8.0,randf_range(0.98,1.04))
    var scene = preload("res://scenes/Burst.tscn")
    var burst = scene.instantiate()
    burst.global_position = global_position
    burst.burst_kind = "gold"
    burst.scale = Vector2(1.25,1.25)
    get_tree().current_scene.add_child(burst)
    queue_free()

func collect_by_flyby():
    collect_now()

func _draw():
    var flash = 0.58 + 0.30 * sin(pulse * 6.0)
    var gold = Color(1.0,0.77,0.10)
    # contact shadow and soft aura
    _draw_ellipse_poly(Vector2(0,14),Vector2(22,5),Color(0,0,0,0.22))
    draw_circle(Vector2.ZERO,21.0,Color(1.0,0.82,0.18,0.05+flash*0.05))
    if treasure_kind == "gold":
        draw_colored_polygon(PackedVector2Array([Vector2(-17,8),Vector2(-11,-8),Vector2(11,-8),Vector2(17,8)]),Color(0.66,0.39,0.04))
        draw_colored_polygon(PackedVector2Array([Vector2(-13,5),Vector2(-8,-5),Vector2(10,-5),Vector2(13,5)]),gold)
        draw_line(Vector2(-7,-3),Vector2(9,-3),Color(1.0,0.96,0.55),2.0)
        draw_line(Vector2(-10,3),Vector2(10,3),Color(0.70,0.40,0.02),1.0)
    elif treasure_kind == "book":
        draw_rect(Rect2(-14,-16,28,32),Color(0.19,0.06,0.08))
        draw_rect(Rect2(-12,-15,24,30),Color(0.48,0.10,0.15))
        draw_rect(Rect2(-9,-12,18,24),Color(0.77,0.57,0.21),false,2.0)
        draw_line(Vector2(0,-14),Vector2(0,14),Color(0.96,0.82,0.37),2.0)
        draw_circle(Vector2(5,-5),3.0,Color(0.97,0.80,0.24))
        draw_line(Vector2(-6,5),Vector2(6,5),Color(0.90,0.71,0.30),1.0)
    else:
        # chest with curved-looking lid, dark outline, brass bands and lock
        draw_rect(Rect2(-20,-8,40,22),Color(0.18,0.10,0.03))
        draw_rect(Rect2(-18,-7,36,20),Color(0.54,0.28,0.06))
        draw_rect(Rect2(-18,-13,36,10),Color(0.74,0.42,0.08))
        draw_arc(Vector2(0,-3),18.0,PI,TAU,18,Color(0.91,0.58,0.12),4.0)
        draw_rect(Rect2(-2,-10,4,23),Color(0.91,0.70,0.20))
        draw_rect(Rect2(-6,0,12,8),Color(0.94,0.73,0.20))
        draw_circle(Vector2(0,4),2.0,Color(0.25,0.15,0.04))
    draw_arc(Vector2.ZERO, 25.0 + sin(pulse*3.8)*2.0, 0, TAU, 28, Color(1.0,0.92,0.36,flash*0.72), 1.6)
    for i in range(4):
        var a = pulse * 1.8 + float(i) * PI * 0.5
        var q=Vector2(cos(a),sin(a))*30.0
        draw_line(q-Vector2(2,0),q+Vector2(2,0),Color(1.0,1.0,0.72,flash),1.2)
        draw_line(q-Vector2(0,2),q+Vector2(0,2),Color(1.0,1.0,0.72,flash),1.2)

func _draw_ellipse_poly(center:Vector2, radius:Vector2, color:Color):
    var pts=PackedVector2Array()
    for i in range(24):
        var a=TAU*float(i)/24.0
        pts.append(center+Vector2(cos(a)*radius.x,sin(a)*radius.y))
    draw_colored_polygon(pts,color)
