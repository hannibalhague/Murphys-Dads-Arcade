extends Area2D

var activated=false
var rise=0.0
var wave_time=0.0
var flash_time=0.0
var sparkle_tick=0.0

func _ready():
    collision_layer=0
    collision_mask=2
    monitoring=true
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _process(delta):
    wave_time+=delta
    sparkle_tick=max(0.0,sparkle_tick-delta)
    if activated:
        rise=move_toward(rise,1.0,delta*0.72)
        flash_time=max(0.0,flash_time-delta)
        if rise<1.0 and sparkle_tick<=0.0:
            sparkle_tick=0.10
            var b=preload("res://scenes/Burst.tscn").instantiate()
            b.global_position=global_position+Vector2(randf_range(-10,10),lerp(14.0,-82.0,rise))
            b.burst_kind="cyan"
            b.scale=Vector2(0.32,0.32)
            get_tree().current_scene.add_child(b)
    queue_redraw()

func _on_body_entered(body):
    if activated or body==null or not body.is_in_group("player"):
        return
    activated=true
    flash_time=1.2
    if body.has_method("set_checkpoint"):
        body.set_checkpoint(global_position+Vector2(-44,-18))
    GameState.add_score(750)
    AudioManager.play_sfx("checkpoint",-4.0)
    GameState.message_requested.emit("CHECKPOINT SECURED  •  CANADIAN FLAG RAISED  •  +750")
    GameState.screen_shake_requested.emit(2.0)

func _draw():
    # Ground base and steel pole.
    draw_circle(Vector2(0,18),20.0,Color(0,0,0,0.18))
    draw_rect(Rect2(-11,12,22,8),Color(0.18,0.20,0.19))
    draw_rect(Rect2(-7,9,14,5),Color(0.39,0.43,0.40))
    draw_line(Vector2(0,10),Vector2(0,-105),Color(0.74,0.79,0.77),4.0)
    draw_line(Vector2(-1,10),Vector2(-1,-105),Color(0.95,0.98,0.95,0.55),1.0)
    draw_circle(Vector2(0,-108),5.0,Color(0.88,0.77,0.30))
    # Rope and cleat.
    draw_line(Vector2(5,-102),Vector2(5,5),Color(0.72,0.65,0.47),1.4)
    draw_line(Vector2(5,2),Vector2(10,-2),Color(0.72,0.65,0.47),1.4)
    draw_line(Vector2(5,2),Vector2(10,6),Color(0.72,0.65,0.47),1.4)
    var flag_y=lerp(8.0,-98.0,rise)
    var wave=sin(wave_time*5.2)*2.4 if activated else 0.0
    # Canadian flag: red-white-red with a stylized maple leaf.
    var left=Vector2(5,flag_y)
    draw_colored_polygon(PackedVector2Array([left, left+Vector2(62,wave), left+Vector2(62,34+wave), left+Vector2(0,34)]),Color(0.96,0.96,0.94))
    draw_colored_polygon(PackedVector2Array([left,left+Vector2(15,wave*.25),left+Vector2(15,34+wave*.25),left+Vector2(0,34)]),Color(0.82,0.05,0.08))
    draw_colored_polygon(PackedVector2Array([left+Vector2(47,wave*.78),left+Vector2(62,wave),left+Vector2(62,34+wave),left+Vector2(47,34+wave*.78)]),Color(0.82,0.05,0.08))
    var c=left+Vector2(31,17+wave*.45)
    var leaf=PackedVector2Array([
        c+Vector2(0,-13),c+Vector2(4,-6),c+Vector2(10,-9),c+Vector2(8,-3),c+Vector2(14,0),c+Vector2(8,3),c+Vector2(10,9),c+Vector2(3,6),c+Vector2(2,14),c+Vector2(-2,14),c+Vector2(-2,6),c+Vector2(-10,9),c+Vector2(-8,3),c+Vector2(-14,0),c+Vector2(-8,-3),c+Vector2(-10,-9),c+Vector2(-4,-6)
    ])
    draw_colored_polygon(leaf,Color(0.82,0.05,0.08))
    if not activated:
        draw_string(ThemeDB.fallback_font,Vector2(-43,-118),"CHECKPOINT",HORIZONTAL_ALIGNMENT_CENTER,86,10,Color(0.95,0.89,0.60,0.82))
    elif flash_time>0.0:
        draw_arc(Vector2.ZERO,30.0+(1.2-flash_time)*32.0,0,TAU,40,Color(1.0,0.92,0.42,flash_time/1.2),2.4)
