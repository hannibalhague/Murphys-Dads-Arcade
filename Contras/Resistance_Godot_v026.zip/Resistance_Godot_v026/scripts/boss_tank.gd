extends CharacterBody2D

const CampaignData = preload("res://scripts/campaign_data.gd")
var boss_name := ""
var max_hp := 40.0
var hp := 40.0
var target
var active := false
var destroyed := false
var t := 0.0
var fire_timer := 1.8
var muzzle_flash := 0.0
var spawn_x := 0.0
var base_y := 0.0
var direction := -1.0
var damage_fx_timer := 0.0
@onready var sprite=$Sprite

func _ready():
    boss_name=String(CampaignData.level(GameState.current_level).boss)
    max_hp=float(CampaignData.BOSS_HP.get(boss_name,42.0))+GameState.current_level*2.0
    hp=max_hp; spawn_x=global_position.x; base_y=global_position.y
    add_to_group("enemy"); add_to_group("boss")
    sprite.visible=(boss_name=="MAMMOTH TANK")
    sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
    GameState.register_boss(max_hp,boss_name)
    queue_redraw()

func _physics_process(delta):
    if destroyed:return
    if target==null or not is_instance_valid(target): target=get_tree().get_first_node_in_group("player")
    if target==null:return
    t+=delta; muzzle_flash=max(0.0,muzzle_flash-delta); damage_fx_timer-=delta
    var off=target.global_position-global_position
    if not active:
        if off.length()<820.0: active=true;GameState.activate_boss()
        else:return
    _move_boss(delta,off)
    _damage_fx()
    fire_timer-=delta
    if fire_timer<=0.0 and off.length()<760.0:
        _fire(off)
        var phase=3 if hp<max_hp*.28 else (2 if hp<max_hp*.58 else 1)
        fire_timer=2.45 if phase==1 else (2.05 if phase==2 else 1.72)
    if sprite.visible:
        sprite.flip_h=off.x<0; sprite.frame=int(t*6.0)%8
    queue_redraw()

func _move_boss(delta,off):
    var air=boss_name in ["HOT AIR BALLOON","WAR BLIMP","SIEGE DRONE","TITAN BAT"]
    if air:
        global_position.y=base_y-145.0+sin(t*(2.2 if boss_name=="SIEGE DRONE" else 1.2))*30.0
        global_position.x+=sin(t*.8)*18.0*delta
    elif boss_name=="IRONCLAD WARSHIP":
        global_position.y=base_y+sin(t*1.9)*6.0; global_position.x+=direction*18.0*delta
    elif boss_name in ["MAGMA BEAST","TOXIC BEHEMOTH","AI COLOSSUS","DREAD WALKER"]:
        global_position.x+=sign(off.x)*18.0*delta
    else:
        global_position.x+=direction*24.0*delta
    if global_position.x<spawn_x-330: direction=1
    if global_position.x>spawn_x+155: direction=-1
    global_position.x=clamp(global_position.x,spawn_x-350,spawn_x+175)

func _damage_fx():
    if hp >= max_hp*0.70 or damage_fx_timer > 0.0:
        return
    damage_fx_timer = 0.45 if hp >= max_hp*0.35 else 0.20
    var q=preload("res://scenes/Burst.tscn").instantiate()
    q.global_position=global_position+Vector2(randf_range(-42,42),randf_range(-45,8))
    q.burst_kind="smoke" if randf()>0.30 else "orange"
    q.scale=Vector2(0.42,0.42) if hp>=max_hp*0.35 else Vector2(0.62,0.62)
    get_tree().current_scene.add_child(q)

func _fire(off):
    var origin=global_position+Vector2(sign(off.x)*48,-20)
    var dir=off.normalized()
    if boss_name in ["HOT AIR BALLOON","WAR BLIMP"]:
        for i in range(2): _spawn(origin+Vector2((i-.5)*20,35),Vector2((i-.5)*.18,1).normalized(),145.0)
    elif boss_name in ["TITAN BAT","TOXIC BEHEMOTH","MAGMA BEAST"]:
        for i in range(3): _spawn(origin,dir.rotated((i-1)*.18),132.0)
    elif boss_name in ["SIEGE DRONE","IRONCLAD WARSHIP"]:
        for i in range(2): _spawn(origin,dir.rotated((i-.5)*.12),152.0)
    else:
        _spawn(origin,dir,128.0)
    muzzle_flash=.15;GameState.screen_shake_requested.emit(2.0)

func _spawn(origin,dir,speed):
    var b=preload("res://scenes/Bullet.tscn").instantiate();b.team="enemy";b.speed=speed;b.damage=1.0;b.direction=dir.normalized();b.global_position=origin;get_tree().current_scene.add_child(b)

func take_damage(amount,hit_position=Vector2.ZERO):
    if destroyed:return
    if not active:active=true;GameState.activate_boss()
    hp=max(0.0,hp-float(amount));GameState.set_boss_hp(hp)
    if hp<=0:_die()

func _die():
    destroyed=true;collision_layer=0;collision_mask=0;GameState.defeat_boss()
    var c=preload("res://scenes/BossCommander.tscn").instantiate();c.global_position=global_position+Vector2(-12,-20);get_tree().current_scene.add_child(c)
    var terrain=get_tree().get_first_node_in_group("destructible_terrain");if terrain:terrain.damage_at_world(global_position,4.5,3)
    for i in range(12):
        var q=preload("res://scenes/Burst.tscn").instantiate();q.global_position=global_position+Vector2(randf_range(-70,70),randf_range(-45,35));q.burst_kind="orange" if i%3 else "smoke";q.scale=Vector2(1.35,1.35);get_tree().current_scene.add_child(q)
    queue_free()

func _draw():
    if destroyed:return
    if sprite.visible:
        draw_rect(Rect2(-58,18,116,16),Color(0.08,0.09,0.08));
        draw_line(Vector2(-52,27),Vector2(52,27),Color(0.30,0.33,0.30),2.0)
        for tx in [-44,-22,0,22,44]: draw_circle(Vector2(tx,27),5.0,Color(0.15,0.17,0.16))
        _draw_military_vehicle_details()
        if muzzle_flash>0:
            var mx=56 if direction>0 else -56
            draw_circle(Vector2(mx,-20),15,Color(1,.38,.06,.25))
            draw_circle(Vector2(mx,-20),9,Color(1,.72,.15,.85))
        return
    var c=CampaignData.level(GameState.current_level).edge
    match boss_name:
        "HOT AIR BALLOON":
            draw_circle(Vector2(0,-25),46,Color(0.72,0.22,0.18));draw_rect(Rect2(-28,18,56,28),c);draw_line(Vector2(-25,10),Vector2(-18,22),Color(0.8,0.75,0.5),3);draw_line(Vector2(25,10),Vector2(18,22),Color(0.8,0.75,0.5),3)
        "WAR BLIMP":
            draw_colored_polygon(PackedVector2Array([Vector2(-75,-18),Vector2(-35,-42),Vector2(55,-38),Vector2(82,-5),Vector2(50,20),Vector2(-55,18)]),Color(0.30,0.36,0.34));draw_rect(Rect2(-20,18,38,22),c)
        "IRONCLAD WARSHIP":
            draw_colored_polygon(PackedVector2Array([Vector2(-85,12),Vector2(80,12),Vector2(58,42),Vector2(-60,42)]),Color(0.22,0.25,0.25));draw_rect(Rect2(-25,-20,50,35),c);draw_line(Vector2(0,-20),Vector2(48,-20),Color(0.12,0.12,0.12),7)
        "TITAN BAT":
            draw_colored_polygon(PackedVector2Array([Vector2(0,-8),Vector2(-85,-42),Vector2(-50,10),Vector2(-92,34),Vector2(-18,28),Vector2(0,45),Vector2(18,28),Vector2(92,34),Vector2(50,10),Vector2(85,-42)]),Color(0.30,0.14,0.38));draw_circle(Vector2(0,2),24,Color(0.45,0.20,0.50))
        "SIEGE DRONE":
            draw_colored_polygon(PackedVector2Array([Vector2(-58,-18),Vector2(0,-38),Vector2(58,-18),Vector2(66,20),Vector2(0,38),Vector2(-66,20)]),Color(0.25,0.33,0.38));draw_circle(Vector2(0,0),14,Color(0.95,0.25,0.15))
        "AI COLOSSUS":
            draw_rect(Rect2(-48,-54,96,86),Color(0.20,0.24,0.25));draw_rect(Rect2(-30,-74,60,28),Color(0.31,0.36,0.36));draw_circle(Vector2(-14,-61),5,Color(0.15,0.95,1.0));draw_circle(Vector2(14,-61),5,Color(1.0,0.22,0.18));draw_line(Vector2(-35,25),Vector2(-64,52),Color(0.25,0.28,0.28),14);draw_line(Vector2(35,25),Vector2(64,52),Color(0.25,0.28,0.28),14);draw_line(Vector2(-48,-25),Vector2(-78,4),Color(0.34,0.39,0.39),12);draw_line(Vector2(48,-25),Vector2(78,4),Color(0.34,0.39,0.39),12)
        "TOXIC BEHEMOTH":
            draw_circle(Vector2(0,-10),52,Color(0.35,0.47,0.16));draw_circle(Vector2(-22,-22),13,Color(0.68,0.88,0.18));draw_circle(Vector2(22,-22),13,Color(0.68,0.88,0.18));draw_circle(Vector2(0,9),18,Color(0.18,0.24,0.10));draw_line(Vector2(-35,28),Vector2(-60,54),Color(0.29,0.37,0.13),15);draw_line(Vector2(35,28),Vector2(60,54),Color(0.29,0.37,0.13),15)
        "MAGMA BEAST":
            draw_circle(Vector2(0,-8),49,Color(0.46,0.12,0.05));draw_colored_polygon(PackedVector2Array([Vector2(-40,-38),Vector2(-18,-72),Vector2(-3,-41),Vector2(16,-76),Vector2(38,-36)]),Color(0.90,0.28,0.05));draw_circle(Vector2(-17,-18),7,Color(1.0,0.78,0.18));draw_circle(Vector2(17,-18),7,Color(1.0,0.78,0.18));draw_line(Vector2(-34,27),Vector2(-62,53),Color(0.38,0.08,0.03),15);draw_line(Vector2(34,27),Vector2(62,53),Color(0.38,0.08,0.03),15)
        "DREAD WALKER":
            draw_rect(Rect2(-46,-50,92,75),Color(0.20,0.16,0.31));draw_colored_polygon(PackedVector2Array([Vector2(-42,-50),Vector2(0,-78),Vector2(42,-50),Vector2(28,-20),Vector2(-28,-20)]),Color(0.35,0.22,0.52));draw_circle(Vector2(0,-47),10,Color(0.74,0.35,1.0));draw_line(Vector2(-28,22),Vector2(-66,55),Color(0.25,0.18,0.38),13);draw_line(Vector2(28,22),Vector2(66,55),Color(0.25,0.18,0.38),13);draw_line(Vector2(-45,-18),Vector2(-75,10),Color(0.32,0.22,0.47),10);draw_line(Vector2(45,-18),Vector2(75,10),Color(0.32,0.22,0.47),10)
        _:
            draw_rect(Rect2(-50,-40,100,75),c.darkened(.35));draw_circle(Vector2(0,-45),28,c);draw_line(Vector2(-30,20),Vector2(-58,42),c,12);draw_line(Vector2(30,20),Vector2(58,42),c,12)
    _draw_military_vehicle_details()
    if muzzle_flash>0:draw_circle(Vector2(50,-10),11,Color(1,.55,.08))

func _draw_military_vehicle_details():
    if boss_name not in ["MAMMOTH TANK","HOT AIR BALLOON","WAR BLIMP","IRONCLAD WARSHIP","SIEGE DRONE","AI COLOSSUS","DREAD WALKER"]:
        return
    var olive=Color(0.24,0.31,0.23,0.88)
    var steel=Color(0.46,0.50,0.45,0.82)
    # Armor seams, rivets, tactical markings and antennae make vehicle bosses read as military hardware.
    if boss_name=="MAMMOTH TANK":
        draw_rect(Rect2(-43,-28,86,34),olive.darkened(0.08),false,3.0)
        draw_line(Vector2(-38,-12),Vector2(38,-12),steel.darkened(0.18),2.0)
        draw_line(Vector2(0,-27),Vector2(0,5),steel.darkened(0.22),1.5)
        draw_line(Vector2(18,-31),Vector2(18,-58),steel,2.0)
        draw_circle(Vector2(18,-61),3.5,Color(0.86,0.18,0.12))
        draw_string(ThemeDB.fallback_font,Vector2(-28,2),"M-77",HORIZONTAL_ALIGNMENT_LEFT,-1,8,Color(0.84,0.82,0.60,0.78))
    elif boss_name in ["WAR BLIMP","HOT AIR BALLOON"]:
        draw_line(Vector2(-50,-8),Vector2(52,-8),steel.darkened(0.15),2.0)
        draw_rect(Rect2(-23,13,46,16),olive)
        draw_line(Vector2(0,13),Vector2(0,-35),steel.darkened(0.20),1.5)
        draw_circle(Vector2(0,20),5.0,Color(0.82,0.76,0.44,0.70))
    elif boss_name=="IRONCLAD WARSHIP":
        for px in [-58.0,-28.0,2.0,32.0,60.0]:
            draw_circle(Vector2(px,18),2.2,steel)
        draw_rect(Rect2(-46,-13,92,8),olive.darkened(0.10))
        draw_line(Vector2(18,-24),Vector2(18,-58),steel,3.0)
        draw_line(Vector2(18,-48),Vector2(45,-42),steel.darkened(0.12),2.0)
    elif boss_name=="SIEGE DRONE":
        draw_rect(Rect2(-42,-9,84,18),olive.darkened(0.12),false,3.0)
        for px in [-36.0,36.0]: draw_circle(Vector2(px,0),5.0,Color(0.72,0.16,0.10,0.55))
        draw_line(Vector2(-50,-15),Vector2(50,-15),steel,2.0)
    else:
        draw_rect(Rect2(-33,-16,66,28),olive.darkened(0.14),false,2.0)
        for px in [-24.0,0.0,24.0]: draw_circle(Vector2(px,-2),2.0,steel)
        draw_line(Vector2(28,-28),Vector2(38,-52),steel,2.0)
