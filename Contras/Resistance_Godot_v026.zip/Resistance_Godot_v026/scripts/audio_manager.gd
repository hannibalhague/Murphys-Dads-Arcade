extends Node

signal music_changed(label)

var music_player: AudioStreamPlayer
var current_track := 1
var music_off := false
const MUSIC_DIR := "res://mp3/"
const SFX_DIR := "res://sfx/"

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    music_player = AudioStreamPlayer.new()
    music_player.bus = "Master"
    music_player.volume_db = -7.5
    add_child(music_player)
    music_player.finished.connect(_on_music_finished)

func start_music():
    if music_off:
        return
    if music_player.playing:
        return
    _load_track(current_track, true, false)

func next_track():
    if music_off:
        music_off = false
        current_track = 1
        _load_track(current_track, true, false)
        return
    var next_num = current_track + 1
    if _track_exists(next_num):
        current_track = next_num
        _load_track(current_track, true, false)
    else:
        stop_music()

func stop_music():
    music_off = true
    music_player.stop()
    music_player.stream = null
    music_changed.emit("MUSIC OFF")

func label() -> String:
    return "MUSIC OFF" if music_off else "TRACK %d  >" % current_track

func _on_music_finished():
    if music_off:
        return
    var next_num = current_track + 1
    if _track_exists(next_num):
        current_track = next_num
        _load_track(current_track, true, false)
    else:
        current_track = 1
        _load_track(current_track, true, false)

func _track_exists(track:int) -> bool:
    return ResourceLoader.exists(MUSIC_DIR + str(track) + ".mp3")

func _load_track(track:int, autoplay:bool, emit_change:bool=true):
    var path = MUSIC_DIR + str(track) + ".mp3"
    if not ResourceLoader.exists(path):
        if track == 1:
            music_off = true
            music_changed.emit("MUSIC OFF")
        return
    var stream = load(path)
    if stream == null:
        return
    music_player.stream = stream
    music_off = false
    if autoplay:
        music_player.play()
    if emit_change:
        music_changed.emit(label())

func play_sfx(sound_name:String, volume_db:float=-7.0, pitch:float=1.0):
    var candidates = [SFX_DIR + sound_name + ".mp3", SFX_DIR + sound_name + ".wav", SFX_DIR + sound_name + ".ogg"]
    var path := ""
    for candidate in candidates:
        if ResourceLoader.exists(candidate):
            path = candidate
            break
    if path == "":
        return
    var stream = load(path)
    if stream == null:
        return
    var p = AudioStreamPlayer.new()
    p.stream = stream
    p.volume_db = volume_db
    p.pitch_scale = pitch
    add_child(p)
    p.finished.connect(p.queue_free)
    p.play()
