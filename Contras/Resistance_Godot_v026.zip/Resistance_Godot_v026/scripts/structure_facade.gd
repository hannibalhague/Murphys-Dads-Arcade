extends Node2D

@export var structure_kind="bunker"
@export var facade_size=Vector2(250,130)
@export var accent=Color(0.55,0.58,0.50)

func _ready():
    z_index=-2
    queue_redraw()

func _draw():
    var w=facade_size.x
    var h=facade_size.y
    var r=Rect2(-w*0.5,-h,w,h)
    draw_rect(Rect2(-w*.46,3,w*.92,9),Color(0,0,0,0.18))
    match structure_kind:
        "jungle_bunker": _draw_bunker(r,Color(0.22,0.28,0.20),Color(0.44,0.49,0.34))
        "desert_bunker": _draw_bunker(r,Color(0.44,0.34,0.23),Color(0.70,0.56,0.34))
        "harbor_warehouse": _draw_warehouse(r,Color(0.24,0.31,0.33),Color(0.48,0.61,0.64))
        "ice_bunker": _draw_bunker(r,Color(0.42,0.52,0.58),Color(0.74,0.87,0.92))
        "factory": _draw_factory(r,Color(0.22,0.25,0.25),Color(0.78,0.57,0.17))
        "toxic_plant": _draw_factory(r,Color(0.29,0.34,0.18),Color(0.61,0.78,0.16))
        "sky_module": _draw_sky_module(r)
        "lava_fort": _draw_bunker(r,Color(0.25,0.17,0.15),Color(0.70,0.28,0.10))
        "alien": _draw_alien(r)
        "field_house": _draw_house(r,Color(0.34,0.31,0.22),Color(0.22,0.16,0.11),Color(0.48,0.62,0.34))
        "desert_house": _draw_house(r,Color(0.52,0.40,0.25),Color(0.30,0.20,0.12),Color(0.78,0.59,0.34))
        "ice_house": _draw_house(r,Color(0.48,0.59,0.64),Color(0.25,0.34,0.40),Color(0.82,0.94,0.98))
        "utility_house": _draw_utility_house(r)
        "sky_house": _draw_sky_house(r)
        "alien_hut": _draw_alien_hut(r)
        "command_bunker": _draw_command_bunker(r)
        "high_tower": _draw_high_tower(r)
        _: _draw_warehouse(r,Color(0.28,0.31,0.30),accent)

func _draw_bunker(r:Rect2,base:Color,edge:Color):
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x+12,r.end.y),Vector2(r.position.x+24,r.position.y+20),Vector2(r.end.x-28,r.position.y+8),Vector2(r.end.x-10,r.end.y)]),base.darkened(0.12))
    draw_rect(Rect2(r.position+Vector2(18,30),Vector2(r.size.x-36,r.size.y-30)),base)
    draw_rect(Rect2(r.position+Vector2(8,18),Vector2(r.size.x-16,20)),edge.darkened(0.18))
    draw_line(Vector2(r.position.x+16,r.position.y+20),Vector2(r.end.x-18,r.position.y+9),edge.lightened(0.12),3)
    # firing slits / doorway
    for x in [-70.0,0.0,70.0]:
        draw_rect(Rect2(Vector2(x-19,r.position.y+54),Vector2(38,9)),Color(0.05,0.07,0.06))
        draw_rect(Rect2(Vector2(x-15,r.position.y+56),Vector2(30,3)),Color(0.42,0.58,0.54,0.34))
    # recessed armored door with frame, hinges, handle and threshold
    draw_rect(Rect2(Vector2(-28,r.end.y-58),Vector2(56,58)),edge.darkened(0.42))
    draw_rect(Rect2(Vector2(-21,r.end.y-52),Vector2(42,52)),Color(0.08,0.10,0.09))
    draw_rect(Rect2(Vector2(-16,r.end.y-47),Vector2(32,47)),base.darkened(0.30))
    draw_line(Vector2(-13,r.end.y-35),Vector2(13,r.end.y-35),base.lightened(0.12),2)
    draw_circle(Vector2(9,r.end.y-22),3.0,Color(0.72,0.65,0.42))
    draw_rect(Rect2(Vector2(-31,r.end.y-4),Vector2(62,4)),Color(0.12,0.12,0.10))
    # sandbags
    for i in range(8):
        var bx=r.position.x+25+float(i)*27
        draw_circle(Vector2(bx,r.end.y-3),14,edge.darkened(0.16))
        draw_line(Vector2(bx-8,r.end.y-7),Vector2(bx+8,r.end.y-7),edge.lightened(0.08),1)

func _draw_warehouse(r:Rect2,base:Color,edge:Color):
    draw_rect(r,base.darkened(0.14))
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x-8,r.position.y+10),Vector2(0,r.position.y-28),Vector2(r.end.x+8,r.position.y+10)]),edge.darkened(0.26))
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x,r.position.y+8),Vector2(0,r.position.y-18),Vector2(r.end.x,r.position.y+8)]),edge)
    # vertical siding
    var x=r.position.x+9
    while x<r.end.x:
        draw_line(Vector2(x,r.position.y+10),Vector2(x,r.end.y),base.lightened(0.10),1)
        x+=17
    # big framed cargo door
    draw_rect(Rect2(Vector2(-54,r.end.y-72),Vector2(108,72)),Color(0.10,0.13,0.14))
    draw_rect(Rect2(Vector2(-47,r.end.y-65),Vector2(94,65)),base.darkened(0.30))
    for y in range(int(r.end.y)-58,int(r.end.y),14): draw_line(Vector2(-45,y),Vector2(45,y),base.lightened(0.13),2)
    # windows and sign
    for wx in [-86.0,86.0]:
        draw_rect(Rect2(Vector2(wx-22,r.position.y+34),Vector2(44,24)),Color(0.09,0.20,0.24))
        draw_line(Vector2(wx,r.position.y+34),Vector2(wx,r.position.y+58),edge.darkened(0.25),2)
    draw_rect(Rect2(Vector2(-42,r.position.y+15),Vector2(84,18)),Color(0.08,0.10,0.10,0.85))
    draw_string(ThemeDB.fallback_font,Vector2(-39,r.position.y+28),"DEPOT",HORIZONTAL_ALIGNMENT_CENTER,78,10,Color(0.85,0.82,0.56))

func _draw_factory(r:Rect2,base:Color,hazard:Color):
    draw_rect(r,base)
    draw_rect(Rect2(r.position+Vector2(8,8),r.size-Vector2(16,8)),base.lightened(0.06))
    # roof vents / stacks
    for sx in [-78.0,-30.0,70.0]:
        draw_rect(Rect2(Vector2(sx-9,r.position.y-36),Vector2(18,38)),base.darkened(0.12))
        draw_rect(Rect2(Vector2(sx-12,r.position.y-40),Vector2(24,7)),Color(0.16,0.18,0.18))
    # pipes
    draw_line(Vector2(r.position.x+20,r.end.y-22),Vector2(r.position.x+20,r.position.y+30),hazard.darkened(0.15),8)
    draw_line(Vector2(r.position.x+20,r.position.y+30),Vector2(r.position.x+68,r.position.y+30),hazard.darkened(0.15),8)
    draw_circle(Vector2(r.position.x+68,r.position.y+30),12,Color(0.12,0.14,0.14))
    draw_circle(Vector2(r.position.x+68,r.position.y+30),7,hazard)
    # industrial doors, lamps, warning band
    draw_rect(Rect2(Vector2(-52,r.end.y-70),Vector2(104,70)),Color(0.08,0.10,0.10))
    for y in range(int(r.end.y)-62,int(r.end.y),16): draw_line(Vector2(-45,y),Vector2(45,y),base.lightened(0.14),2)
    for hx in range(int(r.position.x)+10,int(r.end.x)-12,25): draw_line(Vector2(hx,r.end.y-13),Vector2(hx+13,r.end.y-3),hazard,5)
    for lx in [-92.0,92.0]:
        draw_circle(Vector2(lx,r.position.y+30),7,Color(1.0,0.70,0.18,0.30)); draw_circle(Vector2(lx,r.position.y+30),3.5,Color(1.0,0.82,0.35))

func _draw_sky_module(r:Rect2):
    var base=Color(0.20,0.31,0.38); var edge=Color(0.46,0.66,0.76)
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x+12,r.end.y),Vector2(r.position.x,r.position.y+22),Vector2(r.position.x+28,r.position.y),Vector2(r.end.x-24,r.position.y),Vector2(r.end.x,r.position.y+24),Vector2(r.end.x-8,r.end.y)]),base)
    draw_line(Vector2(r.position.x+24,r.position.y+16),Vector2(r.end.x-24,r.position.y+16),edge,4)
    for wx in [-70.0,0.0,70.0]: draw_circle(Vector2(wx,r.position.y+55),18,Color(0.14,0.38,0.52));draw_circle(Vector2(wx,r.position.y+55),12,Color(0.38,0.72,0.86,0.45))
    draw_rect(Rect2(Vector2(-26,r.end.y-58),Vector2(52,58)),Color(0.10,0.16,0.18))
    for hx in range(int(r.position.x)+14,int(r.end.x)-10,28): draw_circle(Vector2(hx,r.end.y-10),3,edge.darkened(0.3))

func _draw_alien(r:Rect2):
    var base=Color(0.17,0.13,0.27);var glow=Color(0.57,0.32,0.86)
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x+20,r.end.y),Vector2(r.position.x,r.position.y+46),Vector2(r.position.x+52,r.position.y),Vector2(r.end.x-48,r.position.y),Vector2(r.end.x,r.position.y+48),Vector2(r.end.x-16,r.end.y)]),base)
    draw_arc(Vector2(0,r.position.y+58),70,PI,TAU,30,glow,5)
    draw_circle(Vector2(0,r.position.y+58),24,Color(0.22,0.08,0.35));draw_circle(Vector2(0,r.position.y+58),15,Color(0.69,0.35,1.0,0.55))
    for x in [-86.0,-48.0,48.0,86.0]:
        draw_line(Vector2(x,r.position.y+28),Vector2(x*0.72,r.end.y),glow.darkened(0.35),6)
    draw_rect(Rect2(Vector2(-22,r.end.y-52),Vector2(44,52)),Color(0.06,0.04,0.10))
    draw_line(Vector2(0,r.end.y-48),Vector2(0,r.end.y-4),glow,2)

func _draw_house(r:Rect2,wall:Color,roof:Color,trim:Color):
    draw_rect(Rect2(r.position+Vector2(8,28),Vector2(r.size.x-16,r.size.y-28)),wall.darkened(0.12))
    draw_rect(Rect2(r.position+Vector2(13,32),Vector2(r.size.x-26,r.size.y-32)),wall)
    # pitched roof with eaves and layered shingles
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x-8,r.position.y+35),Vector2(0,r.position.y-18),Vector2(r.end.x+8,r.position.y+35)]),roof.darkened(0.18))
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x,r.position.y+31),Vector2(0,r.position.y-10),Vector2(r.end.x,r.position.y+31)]),roof)
    for yy in [r.position.y+7,r.position.y+17,r.position.y+27]: draw_line(Vector2(r.position.x+18,yy),Vector2(r.end.x-18,yy),roof.lightened(0.10),1.3)
    # windows with frames/crossbars
    for wx in [-48.0,48.0]:
        draw_rect(Rect2(Vector2(wx-18,r.position.y+48),Vector2(36,30)),trim.darkened(0.34))
        draw_rect(Rect2(Vector2(wx-14,r.position.y+52),Vector2(28,22)),Color(0.16,0.30,0.34,0.78))
        draw_line(Vector2(wx,r.position.y+52),Vector2(wx,r.position.y+74),trim,1.5);draw_line(Vector2(wx-14,r.position.y+63),Vector2(wx+14,r.position.y+63),trim,1.5)
    # accurate framed door, steps and porch light
    draw_rect(Rect2(Vector2(-25,r.end.y-61),Vector2(50,61)),trim.darkened(0.35))
    draw_rect(Rect2(Vector2(-19,r.end.y-55),Vector2(38,55)),roof.darkened(0.20))
    draw_rect(Rect2(Vector2(-12,r.end.y-47),Vector2(24,14)),wall.darkened(0.28))
    draw_circle(Vector2(10,r.end.y-27),2.5,Color(0.86,0.70,0.36))
    draw_rect(Rect2(Vector2(-31,r.end.y-4),Vector2(62,4)),trim.darkened(0.32))
    draw_circle(Vector2(-31,r.end.y-68),5,Color(1.0,0.82,0.42,0.28));draw_circle(Vector2(-31,r.end.y-68),2.5,Color(1.0,0.83,0.48))

func _draw_utility_house(r:Rect2):
    var wall=Color(0.27,0.31,0.31);var trim=Color(0.55,0.60,0.56)
    draw_rect(r,wall.darkened(0.16));draw_rect(Rect2(r.position+Vector2(7,8),r.size-Vector2(14,8)),wall)
    draw_rect(Rect2(r.position+Vector2(-5,-8),Vector2(r.size.x+10,16)),trim.darkened(0.25))
    for x in range(int(r.position.x)+10,int(r.end.x)-8,18): draw_line(Vector2(x,r.position.y+10),Vector2(x,r.end.y),wall.lightened(0.08),1)
    draw_rect(Rect2(Vector2(-25,r.end.y-62),Vector2(50,62)),Color(0.09,0.11,0.11));draw_rect(Rect2(Vector2(-19,r.end.y-56),Vector2(38,56)),wall.darkened(0.30))
    for wy in [-54.0,54.0]: draw_rect(Rect2(Vector2(wy-19,r.position.y+34),Vector2(38,24)),Color(0.10,0.23,0.27));draw_line(Vector2(wy,r.position.y+34),Vector2(wy,r.position.y+58),trim,1.5)
    draw_rect(Rect2(Vector2(r.end.x-34,r.position.y-28),Vector2(18,30)),wall.darkened(0.2));draw_rect(Rect2(Vector2(r.end.x-38,r.position.y-31),Vector2(26,5)),trim)

func _draw_sky_house(r:Rect2):
    _draw_utility_house(r)
    draw_line(Vector2(r.position.x+14,r.position.y+18),Vector2(r.end.x-14,r.position.y+18),Color(0.35,0.70,0.88),3)
    draw_circle(Vector2(0,r.position.y+48),16,Color(0.16,0.42,0.58));draw_circle(Vector2(0,r.position.y+48),10,Color(0.52,0.82,0.94,0.42))

func _draw_alien_hut(r:Rect2):
    var glow=Color(0.62,0.33,0.94);var body=Color(0.18,0.13,0.28)
    draw_colored_polygon(PackedVector2Array([Vector2(r.position.x+6,r.end.y),Vector2(r.position.x+26,r.position.y+28),Vector2(0,r.position.y-16),Vector2(r.end.x-26,r.position.y+28),Vector2(r.end.x-6,r.end.y)]),body)
    draw_arc(Vector2(0,r.position.y+37),r.size.x*0.32,PI,TAU,28,glow,4)
    draw_rect(Rect2(Vector2(-19,r.end.y-49),Vector2(38,49)),Color(0.05,0.03,0.09));draw_line(Vector2(0,r.end.y-44),Vector2(0,r.end.y-5),glow,2)
    for wx in [-46.0,46.0]: draw_circle(Vector2(wx,r.position.y+47),11,Color(0.50,0.23,0.80,0.32))

func _draw_command_bunker(r:Rect2):
    var base=Color(0.25,0.29,0.25);var edge=Color(0.49,0.55,0.42)
    _draw_bunker(r,base,edge)
    draw_rect(Rect2(Vector2(-58,r.position.y-18),Vector2(116,22)),Color(0.10,0.12,0.10))
    draw_string(ThemeDB.fallback_font,Vector2(-52,r.position.y-3),"COMMAND",HORIZONTAL_ALIGNMENT_CENTER,104,10,Color(0.90,0.82,0.48))
    draw_line(Vector2(r.end.x-38,r.position.y+12),Vector2(r.end.x-38,r.position.y-48),Color(0.23,0.24,0.20),3)
    draw_colored_polygon(PackedVector2Array([Vector2(r.end.x-38,r.position.y-48),Vector2(r.end.x-4,r.position.y-40),Vector2(r.end.x-38,r.position.y-31)]),Color(0.74,0.12,0.12))

func _draw_high_tower(r:Rect2):
    var steel=Color(0.22,0.27,0.28)
    var edge=Color(0.55,0.62,0.58)
    var dark=Color(0.08,0.11,0.12)
    # Deep vertical shadow gives the tower mass even though the climbable decks are separate physics nodes.
    draw_rect(Rect2(Vector2(r.position.x+26,r.position.y+18),Vector2(r.size.x-52,r.size.y-18)),Color(0.03,0.05,0.06,0.38))
    # Four main steel uprights.
    for sx in [r.position.x+28.0,r.position.x+48.0,r.end.x-48.0,r.end.x-28.0]:
        draw_line(Vector2(sx,r.end.y),Vector2(sx,r.position.y+22),steel,7.0)
        draw_line(Vector2(sx+2,r.end.y),Vector2(sx+2,r.position.y+22),edge.darkened(0.28),1.4)
    # Lattice cross bracing all the way up.
    var yy=r.end.y-26.0
    var flip=false
    while yy>r.position.y+42.0:
        var y2=max(r.position.y+42.0,yy-54.0)
        if flip:
            draw_line(Vector2(r.position.x+31,yy),Vector2(r.end.x-31,y2),steel.lightened(0.06),4.0)
            draw_line(Vector2(r.end.x-31,yy),Vector2(r.position.x+31,y2),steel.darkened(0.08),3.0)
        else:
            draw_line(Vector2(r.end.x-31,yy),Vector2(r.position.x+31,y2),steel.lightened(0.06),4.0)
            draw_line(Vector2(r.position.x+31,yy),Vector2(r.end.x-31,y2),steel.darkened(0.08),3.0)
        flip=not flip
        yy-=56.0
    # Repeating decks, rails and lamps.
    for deck_y in [r.end.y-105.0,r.end.y-230.0,r.end.y-355.0]:
        if deck_y<r.position.y+26.0:
            continue
        draw_rect(Rect2(Vector2(r.position.x+12,deck_y),Vector2(r.size.x-24,13)),dark)
        draw_rect(Rect2(Vector2(r.position.x+18,deck_y+2),Vector2(r.size.x-36,7)),edge.darkened(0.25))
        draw_line(Vector2(r.position.x+20,deck_y-18),Vector2(r.end.x-20,deck_y-18),edge.darkened(0.15),2.0)
        for rx in range(int(r.position.x)+22,int(r.end.x)-20,22):
            draw_line(Vector2(rx,deck_y-18),Vector2(rx,deck_y),steel,1.5)
        draw_circle(Vector2(r.end.x-28,deck_y-26),4.0,Color(1.0,0.72,0.22,0.28))
        draw_circle(Vector2(r.end.x-28,deck_y-26),2.1,Color(1.0,0.84,0.32))
    # Armored command cabin at the top.
    draw_rect(Rect2(Vector2(-54,r.position.y+38),Vector2(108,58)),steel.darkened(0.08))
    draw_rect(Rect2(Vector2(-46,r.position.y+46),Vector2(92,42)),steel.lightened(0.05))
    for wx in [-28.0,0.0,28.0]:
        draw_rect(Rect2(Vector2(wx-10,r.position.y+54),Vector2(20,15)),Color(0.10,0.30,0.38))
        draw_rect(Rect2(Vector2(wx-8,r.position.y+56),Vector2(16,11)),Color(0.36,0.67,0.75,0.28))
    # Antenna mast, beacon and side radar dish.
    draw_line(Vector2(0,r.position.y+38),Vector2(0,r.position.y-46),edge,5.0)
    draw_line(Vector2(-18,r.position.y-18),Vector2(18,r.position.y-18),edge.darkened(0.1),2.0)
    draw_circle(Vector2(0,r.position.y-49),6.0,Color(0.85,0.12,0.10,0.35))
    draw_circle(Vector2(0,r.position.y-49),3.0,Color(1.0,0.24,0.14))
    draw_arc(Vector2(r.end.x-24,r.position.y+102),22.0,PI*0.72,PI*1.30,18,edge,4.0)
    draw_line(Vector2(r.end.x-24,r.position.y+102),Vector2(r.end.x-8,r.position.y+120),edge,3.0)
