extends Node2D

@export var water_size := Vector2(180,180)
@export var top_color := Color(0.20,0.58,0.72,0.88)
@export var deep_color := Color(0.05,0.20,0.32,0.94)
var t := 0.0

func _ready():
    z_index = 1

func _process(delta):
    t += delta
    queue_redraw()

func _draw():
    var r=Rect2(-water_size.x*0.5,0,water_size.x,water_size.y)
    draw_rect(r,deep_color)
    draw_rect(Rect2(r.position,Vector2(r.size.x,22)),top_color.darkened(0.05))
    # Bright broken shoreline foam makes water read as a moving surface instead of a flat rectangle.
    var foam_x = -water_size.x * 0.5
    var foam_i := 0
    while foam_x < water_size.x * 0.5:
        var foam_y = 4.0 + sin(t*3.1 + foam_i*0.8) * 2.2
        draw_arc(Vector2(foam_x+10.0,foam_y),10.0,PI,TAU,10,Color(0.78,0.94,1.0,0.48),2.0)
        foam_x += 22.0
        foam_i += 1
    for row in range(5):
        var yy=8.0+row*19.0
        var x=-water_size.x*0.5-10.0
        while x<water_size.x*0.5+10.0:
            var wave=sin(t*2.2+x*0.035+row*0.8)*3.5
            var c=top_color.lightened(0.16+row*0.025)
            c.a=0.62-row*0.08
            draw_line(Vector2(x,yy+wave),Vector2(x+25,yy-wave*0.45),c,2.0 if row<2 else 1.0)
            x+=30.0
    for i in range(10):
        var bx=-water_size.x*0.45+fmod(float(i)*47.0+t*13.0,water_size.x*0.9)
        var by=44.0+fmod(float(i)*31.0+t*9.0,water_size.y-52.0)
        draw_circle(Vector2(bx,by),1.5,Color(0.70,0.90,0.96,0.18))
    # Long soft reflections add depth without extra nodes or textures.
    for i in range(4):
        var rx=-water_size.x*0.38+fmod(t*(8.0+i*2.0)+i*67.0,water_size.x*0.76)
        var ry=30.0+i*24.0+sin(t*1.7+i)*3.0
        draw_line(Vector2(rx-18,ry),Vector2(rx+18,ry),Color(0.82,0.96,1.0,0.12),2.0)
