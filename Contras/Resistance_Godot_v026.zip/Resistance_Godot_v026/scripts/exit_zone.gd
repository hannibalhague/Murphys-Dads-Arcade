extends Area2D

@export var zone_size = Vector2(90, 120)
var pulse = 0.0
var cleared = false

func _ready():
    collision_layer = 0
    collision_mask = 2
    monitoring = true
    var shape = RectangleShape2D.new()
    shape.size = zone_size
    var cs = CollisionShape2D.new()
    cs.shape = shape
    add_child(cs)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _process(delta):
    pulse += delta
    queue_redraw()

func _on_body_entered(body):
    if not body.is_in_group("player"):
        return
    if GameState.hostages_rescued < GameState.hostages_total:
        var left = GameState.hostages_total - GameState.hostages_rescued
        GameState.message_requested.emit("RESCUE %d MORE HOSTAGE%s" % [left, "" if left == 1 else "S"])
        return
    if cleared:
        return
    cleared = true
    GameState.clear_mission()
    _celebrate()

func _celebrate():
    var scene = preload("res://scenes/Burst.tscn")
    for i in range(6):
        var b = scene.instantiate()
        b.global_position = global_position + Vector2(randf_range(-55,55), randf_range(-80,20))
        b.burst_kind = "gold" if i % 2 == 0 else "cyan"
        b.scale = Vector2(1.2,1.2)
        get_tree().current_scene.add_child(b)

func _draw():
    var glow = 0.55 + 0.35 * sin(pulse * 4.0)
    draw_line(Vector2(-28,58),Vector2(-28,-58),Color(0.72,0.78,0.72),5.0)
    draw_colored_polygon(PackedVector2Array([Vector2(-25,-55),Vector2(27,-43),Vector2(-25,-25)]),Color(0.88,0.23,0.16))
    draw_circle(Vector2(0,42),34.0,Color(0.24,0.95,0.60,0.12 + glow*0.08))
    draw_arc(Vector2(0,42),32.0 + sin(pulse*3.0)*3.0,0,TAU,32,Color(0.42,1.0,0.72,glow),3.0)
    var label = "EXTRACT" if not cleared else "CLEAR"
    draw_string(ThemeDB.fallback_font,Vector2(-34,82),label,HORIZONTAL_ALIGNMENT_CENTER,68,13,Color(0.80,1.0,0.86))
