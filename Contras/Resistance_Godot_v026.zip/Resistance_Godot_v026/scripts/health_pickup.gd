extends Area2D

@export var heal_amount = 1
@export var score_value = 150
var pulse = 0.0
var collected = false
var base_y = 0.0

func _ready():
    collision_layer = 0
    collision_mask = 2
    monitoring = true
    body_entered.connect(_on_body_entered)
    base_y = position.y
    queue_redraw()

func _process(delta):
    pulse += delta
    position.y = base_y + sin(pulse * 2.6) * 1.8
    queue_redraw()

func _on_body_entered(body):
    if collected or not body.is_in_group("player"):
        return
    if GameState.health >= GameState.max_health:
        GameState.message_requested.emit("HEALTH FULL")
        return
    collected = true
    monitoring = false
    GameState.heal(heal_amount)
    GameState.add_score(score_value)
    GameState.message_requested.emit("FIELD MED KIT  +%d HP  +%d" % [heal_amount, score_value])
    var b = preload("res://scenes/Burst.tscn").instantiate()
    b.global_position = global_position
    b.burst_kind = "health"
    b.scale = Vector2(0.9,0.9)
    get_tree().current_scene.add_child(b)
    queue_free()

func _draw():
    var glow = 0.45 + 0.25 * sin(pulse * 4.5)
    # soft grounding shadow
    _draw_ellipse_poly(Vector2(0,14),Vector2(20,5),Color(0,0,0,0.24))
    # outer glow rings
    draw_arc(Vector2.ZERO,22.0 + sin(pulse*3.6)*1.8,0,TAU,28,Color(0.35,1.0,0.48,glow),2.0)
    draw_arc(Vector2.ZERO,27.0 + sin(pulse*3.1)*1.4,0,TAU,28,Color(0.40,0.95,0.55,glow*0.38),1.0)
    # military pouch/case body with rounded-looking layered rectangles
    draw_rect(Rect2(-17,-13,34,26),Color(0.12,0.22,0.13))
    draw_rect(Rect2(-15,-11,30,22),Color(0.27,0.43,0.25))
    draw_rect(Rect2(-15,-11,30,5),Color(0.39,0.55,0.34))
    draw_rect(Rect2(-15,7,30,4),Color(0.15,0.27,0.15))
    # side reinforcements and top handle
    draw_rect(Rect2(-17,-9,3,17),Color(0.10,0.18,0.11))
    draw_rect(Rect2(14,-9,3,17),Color(0.10,0.18,0.11))
    draw_line(Vector2(-7,-13),Vector2(-7,-18),Color(0.19,0.30,0.18),3.0)
    draw_line(Vector2(7,-13),Vector2(7,-18),Color(0.19,0.30,0.18),3.0)
    draw_line(Vector2(-7,-18),Vector2(7,-18),Color(0.31,0.44,0.28),3.0)
    # cream medical patch and cross
    draw_rect(Rect2(-9,-8,18,16),Color(0.88,0.88,0.72))
    draw_rect(Rect2(-3,-6,6,12),Color(0.79,0.16,0.13))
    draw_rect(Rect2(-6,-3,12,6),Color(0.79,0.16,0.13))
    # clasp and stitching
    draw_rect(Rect2(-3,8,6,4),Color(0.74,0.66,0.38))
    draw_line(Vector2(-12,-8),Vector2(-12,7),Color(0.58,0.68,0.47,0.65),1.0)
    draw_line(Vector2(12,-8),Vector2(12,7),Color(0.58,0.68,0.47,0.65),1.0)
    # tiny alternating sparkles, visible but less arcade-neon than before
    for i in range(3):
        var a=pulse*1.8+float(i)*TAU/3.0
        var q=Vector2(cos(a),sin(a))*31.0
        draw_circle(q,1.7,Color(0.80,1.0,0.74,0.45+glow*0.35))

func _draw_ellipse_poly(center:Vector2, radius:Vector2, color:Color):
    var pts=PackedVector2Array()
    for i in range(24):
        var a=TAU*float(i)/24.0
        pts.append(center+Vector2(cos(a)*radius.x,sin(a)*radius.y))
    draw_colored_polygon(pts,color)
