extends CanvasLayer

var panel: ColorRect
var title_label: Label
var sub_label: Label
var info_label: Label
var prompt_label: Label
var mode := "none"
var pulse := 0.0

func _ready():
    layer = 100
    process_mode = Node.PROCESS_MODE_ALWAYS
    _build()
    GameState.game_over_requested.connect(show_game_over)
    if GameState.current_level == 0 and GameState.score == 0 and GameState.lives == 5:
        call_deferred("show_title")
    else:
        visible = false

func _build():
    panel = ColorRect.new()
    panel.color = Color(0.018,0.035,0.045,0.965)
    panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(panel)

    var border = ColorRect.new()
    border.color = Color(0.50,0.52,0.34,0.34)
    border.position = Vector2(135,70)
    border.size = Vector2(690,400)
    panel.add_child(border)
    var inner = ColorRect.new()
    inner.color = Color(0.025,0.055,0.055,0.96)
    inner.position = Vector2(4,4)
    inner.size = Vector2(682,392)
    border.add_child(inner)

    title_label = Label.new()
    title_label.position = Vector2(170,132)
    title_label.size = Vector2(620,90)
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size",42)
    title_label.add_theme_color_override("font_color",Color(0.93,0.83,0.45))
    panel.add_child(title_label)

    sub_label = Label.new()
    sub_label.position = Vector2(170,220)
    sub_label.size = Vector2(620,50)
    sub_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub_label.add_theme_font_size_override("font_size",20)
    sub_label.add_theme_color_override("font_color",Color(0.62,0.70,0.48))
    panel.add_child(sub_label)

    info_label = Label.new()
    info_label.position = Vector2(190,282)
    info_label.size = Vector2(580,105)
    info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    info_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    info_label.add_theme_font_size_override("font_size",14)
    info_label.add_theme_color_override("font_color",Color(0.88,0.90,0.82))
    panel.add_child(info_label)

    prompt_label = Label.new()
    prompt_label.position = Vector2(150,425)
    prompt_label.size = Vector2(660,35)
    prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prompt_label.add_theme_font_size_override("font_size",17)
    prompt_label.add_theme_color_override("font_color",Color(1.0,0.92,0.65))
    panel.add_child(prompt_label)

    var music_button=Button.new()
    music_button.position=Vector2(680,86);music_button.size=Vector2(110,30);music_button.text=AudioManager.label();music_button.add_theme_font_size_override("font_size",10);panel.add_child(music_button)
    music_button.pressed.connect(func(): AudioManager.next_track();music_button.text=AudioManager.label())
    AudioManager.music_changed.connect(func(label): music_button.text=label)
    var select_button=Button.new()
    select_button.position=Vector2(555,86);select_button.size=Vector2(120,30);select_button.text="GAME SELECT";select_button.add_theme_font_size_override("font_size",10);panel.add_child(select_button)
    select_button.pressed.connect(_game_select)

func _process(delta):
    if not visible:
        return
    pulse += delta
    prompt_label.modulate.a = 0.62 + 0.38 * (0.5 + 0.5 * sin(pulse * 4.0))

func show_title():
    mode = "title"
    visible = true
    title_label.text = "MISSION: OFF WITH HIS HEAD!"
    sub_label.text = "OPERATION: OFF WITH HIS HEAD!"
    info_label.text = "MISSION ORDER 001 // DEPLOY IMMEDIATELY\n\nRESCUE • DIG • LOOT • DESTROY THE BOSS • TAKE THE HEAD • EXTRACT"
    prompt_label.text = "PRESS ANY KEY / BUTTON / TAP TO DEPLOY"
    get_tree().paused = true

func show_game_over():
    mode = "game_over"
    visible = true
    title_label.text = "MISSION FAILED"
    sub_label.text = "GAME OVER"
    info_label.text = "FINAL SCORE %06d   •   HEADS %d   •   CONTINUES LEFT %d\n\nHIGH SCORES\nYOUR CAMPAIGN HAS ENDED" % [GameState.score,GameState.held_heads,GameState.continues]
    prompt_label.text = "PRESS ANY KEY / BUTTON / TAP TO RESTART"
    get_tree().paused = true

func _unhandled_input(event):
    if not visible:
        return
    var activate = false
    if event is InputEventKey and event.pressed and not event.echo:
        activate = true
    elif event is InputEventJoypadButton and event.pressed:
        activate = true
    elif event is InputEventMouseButton and event.pressed:
        activate = true
    elif event is InputEventScreenTouch and event.pressed:
        activate = true
    if not activate:
        return
    get_viewport().set_input_as_handled()
    if mode == "title":
        visible = false
        mode = "none"
        get_tree().paused = false
        AudioManager.start_music()
        AudioManager.play_sfx("game_start",-4.0)
        GameState.message_requested.emit("DEPLOYED — %s" % preload("res://scripts/campaign_data.gd").level(GameState.current_level).name)
    elif mode == "game_over":
        get_tree().paused = false
        GameState.start_new_campaign()
        get_tree().reload_current_scene()

func _game_select():
    get_tree().paused=false
    if OS.has_feature("web"):
        JavaScriptBridge.eval("window.location.href='../index.html';")
    else:
        get_tree().quit()
