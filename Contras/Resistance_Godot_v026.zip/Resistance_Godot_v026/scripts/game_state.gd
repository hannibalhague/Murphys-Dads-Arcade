extends Node

signal stats_changed
signal message_requested(text)
signal screen_shake_requested(strength)
signal fireworks_requested(origin)
signal game_over_requested

var current_level := 0
var score := 0
var health := 5
var max_health := 5
var lives := 5
var continues := 1
var grenades := 4
var hostages_total := 0
var hostages_rescued := 0
var chests := 0
var books := 0
var gold := 0
var held_heads := 0
var mission_cleared := false
var campaign_complete := false
var boss_name := ""
var boss_max_hp := 0.0
var boss_hp := 0.0
var boss_active := false
var boss_defeated := false
var extraction_ready := false
var victory_invincible := false
var commander_spawned := false
var commander_executed := false
var victory_flight := false
var celebration_active := false

func request_game_over():
    game_over_requested.emit()

func reset():
    # Called by Main on launch. Preserve an active campaign when reloading between stages.
    if not has_meta("campaign_started"):
        start_new_campaign()
    else:
        reset_level_state()

func start_new_campaign():
    set_meta("campaign_started",true)
    current_level = 0
    score = 0
    health = max_health
    lives = 5
    continues = 1
    grenades = 4
    chests = 0
    books = 0
    gold = 0
    held_heads = 0
    campaign_complete = false
    reset_level_state()

func reset_level_state():
    health = max_health
    grenades = max(grenades,4)
    hostages_total = 0
    hostages_rescued = 0
    mission_cleared = false
    boss_name = ""
    boss_max_hp = 0.0
    boss_hp = 0.0
    boss_active = false
    boss_defeated = false
    extraction_ready = false
    victory_invincible = false
    commander_spawned = false
    commander_executed = false
    victory_flight = false
    celebration_active = false
    stats_changed.emit()

func add_score(amount):
    score += int(amount)
    stats_changed.emit()

func set_health(value):
    health = clamp(int(value),0,max_health)
    stats_changed.emit()

func heal(amount):
    health = min(max_health,health+max(0,int(amount)))
    stats_changed.emit()

func add_grenades(amount):
    grenades = min(9,grenades+max(0,int(amount)))
    stats_changed.emit()

func lose_life() -> String:
    lives = max(0,lives-1)
    health = max_health
    if lives > 0:
        stats_changed.emit(); return "respawn"
    if continues > 0:
        continues -= 1
        lives = 5
        stats_changed.emit(); return "continue"
    stats_changed.emit(); return "game_over"

func set_hostage_total(value):
    hostages_total = max(0,int(value)); stats_changed.emit()

func rescue_hostage():
    hostages_rescued = min(hostages_total,hostages_rescued+1)
    add_score(1000)
    message_requested.emit("HOSTAGE RESCUED  +1000")

func use_grenade():
    if grenades <= 0: return false
    grenades -= 1; stats_changed.emit(); return true

func collect_treasure(kind,points):
    match String(kind):
        "chest": chests += 1
        "book": books += 1
        "gold": gold += 1
    add_score(points)
    var title = "TREASURE CHEST" if kind == "chest" else ("PRECIOUS BOOK" if kind == "book" else "GOLD BAR")
    message_requested.emit(title+"  +"+str(points))

func register_boss(max_value,boss_label="BOSS"):
    boss_name = str(boss_label)
    boss_max_hp = max(1.0,float(max_value)); boss_hp = boss_max_hp
    boss_active = false; boss_defeated = false; extraction_ready = false
    victory_invincible = false; commander_spawned = false; commander_executed = false
    victory_flight = false; celebration_active = false
    stats_changed.emit()

func activate_boss():
    if boss_defeated or boss_active: return
    boss_active = true
    message_requested.emit(boss_name+" — DESTROY IT!")
    screen_shake_requested.emit(4.5); stats_changed.emit()

func set_boss_hp(value):
    boss_hp = clamp(float(value),0.0,boss_max_hp); stats_changed.emit()

func defeat_boss():
    if boss_defeated: return
    boss_hp = 0.0; boss_active = false; boss_defeated = true; victory_invincible = true
    add_score(5000+current_level*500)
    message_requested.emit(boss_name+" DESTROYED — BOSS MAN BAILING OUT!")
    screen_shake_requested.emit(12.0); stats_changed.emit()

func mark_commander_spawned():
    commander_spawned = true; victory_invincible = true
    message_requested.emit("BOSS MAN IS RUNNING — TAKE HIS HEAD!"); stats_changed.emit()

func execute_commander(origin=Vector2.ZERO):
    if commander_executed: return
    commander_executed = true; victory_invincible = true; held_heads += 1
    add_score(2500); message_requested.emit("HEAD TAKEN  +2500")
    screen_shake_requested.emit(6.0); fireworks_requested.emit(origin)
    extraction_ready = true; stats_changed.emit()

func start_victory_flight():
    if victory_flight: return
    victory_flight = true; celebration_active = true; victory_invincible = true
    message_requested.emit("VICTORY FLIGHT — UP/DOWN FLY • FIRE STILL WORKS • ROTOR CHOPS!")
    stats_changed.emit()

func clear_mission():
    if mission_cleared: return
    mission_cleared = true
    add_score(5000)
    if current_level < 9:
        current_level += 1
        message_requested.emit("STAGE CLEARED — NEXT MISSION!")
        get_tree().create_timer(1.2).timeout.connect(func(): get_tree().reload_current_scene())
    else:
        campaign_complete = true
        message_requested.emit("ALL 10 MISSIONS CLEARED!")
        stats_changed.emit()
