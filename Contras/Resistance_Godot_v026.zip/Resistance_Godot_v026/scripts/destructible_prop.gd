extends StaticBody2D

@export var prop_size = Vector2(64, 64)
@export var max_hp = 4.0
@export var prop_kind = "wood"
@export var score_value = 60
var hp = 4.0
var destroyed = false

func _ready():
    hp = max_hp
    collision_layer = 1
    collision_mask = 0
    add_to_group("damageable_prop")
    var shape = RectangleShape2D.new()
    shape.size = prop_size
    var cs = CollisionShape2D.new()
    cs.shape = shape
    add_child(cs)
    queue_redraw()

func take_damage(amount, hit_position = Vector2.ZERO):
    if destroyed:
        return
    hp -= float(amount)
    queue_redraw()
    if hp <= 0.0:
        destroyed = true
        GameState.add_score(score_value)
        if prop_kind == "barrel":
            _explode_barrel()
        else:
            _burst()
        queue_free()

func _explode_barrel():
    AudioManager.play_sfx("explosion",-3.0,randf_range(0.94,1.02))
    GameState.screen_shake_requested.emit(9.0)
    var terrain = get_tree().get_first_node_in_group("destructible_terrain")
    if terrain:
        terrain.damage_at_world(global_position, 3.2, 2)
    for enemy in get_tree().get_nodes_in_group("enemy"):
        if is_instance_valid(enemy) and enemy.global_position.distance_to(global_position) <= 112.0 and enemy.has_method("take_damage"):
            enemy.take_damage(4.0, global_position)
    for prop in get_tree().get_nodes_in_group("damageable_prop"):
        if prop != self and is_instance_valid(prop) and prop.global_position.distance_to(global_position) <= 96.0 and prop.has_method("take_damage"):
            prop.take_damage(4.0, global_position)
    _spawn_burst("orange", 1.55)
    _spawn_burst("orange", 0.90)
    _spawn_burst("smoke", 2.15)
    _spawn_burst("smoke", 1.35)

func _burst():
    var kind = "wood" if prop_kind in ["wood", "crate", "tent"] else "stone"
    _spawn_burst(kind, 1.0)

func _spawn_burst(kind, burst_scale):
    var scene = preload("res://scenes/Burst.tscn")
    var b = scene.instantiate()
    b.global_position = global_position
    b.burst_kind = kind
    b.scale = Vector2(burst_scale, burst_scale)
    get_tree().current_scene.add_child(b)

func _draw():
    var r = Rect2(-prop_size * 0.5, prop_size)
    var base = Color(0.42, 0.28, 0.16)
    if prop_kind == "concrete": base = Color(0.38, 0.42, 0.40)
    elif prop_kind == "metal": base = Color(0.30, 0.37, 0.40)
    elif prop_kind in ["tent","spawn_tent"]: base = Color(0.28, 0.38, 0.20)
    elif prop_kind == "crate": base = Color(0.49, 0.31, 0.13)
    elif prop_kind == "barrel": base = Color(0.42,0.19,0.12)

    draw_rect(Rect2(r.position+Vector2(4,prop_size.y-3),Vector2(prop_size.x-8,6)),Color(0,0,0,0.18))
    if prop_kind == "barrel":
        draw_rect(Rect2(-prop_size.x*0.34,-prop_size.y*0.5,prop_size.x*0.68,prop_size.y),base.darkened(0.18))
        draw_rect(Rect2(-prop_size.x*0.30,-prop_size.y*0.48,prop_size.x*0.60,prop_size.y*0.96),base)
        draw_rect(Rect2(-prop_size.x*0.28,-prop_size.y*0.44,prop_size.x*0.12,prop_size.y*0.88),base.lightened(0.16))
        draw_rect(Rect2(-prop_size.x*0.36,-prop_size.y*0.35,prop_size.x*0.72,7),Color(0.14,0.16,0.15))
        draw_rect(Rect2(-prop_size.x*0.36,prop_size.y*0.23,prop_size.x*0.72,7),Color(0.14,0.16,0.15))
        draw_arc(Vector2(0,-prop_size.y*0.47),prop_size.x*0.30,PI,TAU,18,base.lightened(0.18),3.0)
        draw_arc(Vector2(0,prop_size.y*0.47),prop_size.x*0.30,0,PI,18,base.darkened(0.28),3.0)
        draw_circle(Vector2(0,-3),8.0,Color(0.96,0.70,0.16))
        draw_colored_polygon(PackedVector2Array([Vector2(-3,-10),Vector2(3,-5),Vector2(0,-1),Vector2(5,4),Vector2(-4,2),Vector2(-1,-3),Vector2(-5,-6)]),Color(0.23,0.07,0.04))
    elif prop_kind in ["tent","spawn_tent"]:
        draw_colored_polygon(PackedVector2Array([Vector2(r.position.x,r.end.y),Vector2(0,r.position.y-5),Vector2(r.end.x,r.end.y)]),base.darkened(0.10))
        draw_colored_polygon(PackedVector2Array([Vector2(r.position.x+5,r.end.y-3),Vector2(0,r.position.y),Vector2(0,r.end.y-3)]),base.lightened(0.08))
        draw_colored_polygon(PackedVector2Array([Vector2(0,r.position.y),Vector2(r.end.x-5,r.end.y-3),Vector2(0,r.end.y-3)]),base)
        draw_line(Vector2(0,r.position.y-5),Vector2(0,r.end.y),Color(0.12,0.15,0.10),2.0)
        draw_rect(Rect2(-8,r.end.y-24,16,24),Color(0.10,0.13,0.09))
        draw_line(Vector2(r.position.x,r.end.y),Vector2(r.position.x-8,r.end.y+8),Color(0.34,0.28,0.17),2.0)
        draw_line(Vector2(r.end.x,r.end.y),Vector2(r.end.x+8,r.end.y+8),Color(0.34,0.28,0.17),2.0)
        if prop_kind=="spawn_tent":
            draw_rect(Rect2(-31,r.position.y+18,62,16),Color(0.08,0.10,0.07,0.78))
            draw_string(ThemeDB.fallback_font,Vector2(-28,r.position.y+30),"SPAWN",HORIZONTAL_ALIGNMENT_CENTER,56,9,Color(0.90,0.82,0.54))
            draw_circle(Vector2(-39,r.end.y-8),5,Color(0.18,0.20,0.15));draw_circle(Vector2(39,r.end.y-8),5,Color(0.18,0.20,0.15))
    else:
        draw_rect(r, base.darkened(0.14))
        draw_rect(Rect2(r.position+Vector2(3,3),r.size-Vector2(6,6)),base)
        draw_line(r.position+Vector2(4,4),Vector2(r.end.x-4,r.position.y+4),base.lightened(0.25),2.0)
        if prop_kind in ["wood", "crate"]:
            draw_rect(Rect2(r.position.x+5,r.position.y+5,6,r.size.y-10),base.darkened(0.25))
            draw_rect(Rect2(r.end.x-11,r.position.y+5,6,r.size.y-10),base.darkened(0.25))
            draw_line(r.position+Vector2(7,7), r.end-Vector2(7,7), base.darkened(0.30), 3.0)
            draw_line(Vector2(r.end.x-7,r.position.y+7), Vector2(r.position.x+7,r.end.y-7), base.darkened(0.30), 3.0)
            draw_circle(Vector2(r.position.x+8,r.position.y+8),1.8,Color(0.72,0.65,0.44))
            draw_circle(Vector2(r.end.x-8,r.end.y-8),1.8,Color(0.72,0.65,0.44))
        else:
            var x = r.position.x + 16.0
            while x < r.end.x:
                draw_line(Vector2(x, r.position.y+3), Vector2(x, r.end.y-3), base.darkened(0.16), 1.0)
                x += 20.0
            draw_line(Vector2(r.position.x+3,0),Vector2(r.end.x-3,0),base.lightened(0.12),1.0)
            if prop_kind in ["metal","concrete"]:
                for hx in range(int(r.position.x)+5,int(r.end.x)-8,18):
                    draw_line(Vector2(hx,r.end.y-10),Vector2(hx+9,r.end.y-3),Color(0.88,0.62,0.16,0.42),3.0)

    if hp < max_hp:
        var cracks = int(clamp((max_hp - hp) * 2.0, 1.0, 7.0))
        for i in range(cracks):
            var px = -prop_size.x * 0.25 + float(i % 4) * 13.0
            var py = -prop_size.y * 0.2 + float(i / 4) * 18.0
            draw_line(Vector2(px, py), Vector2(px + 8.0, py + 10.0), Color(0.08,0.08,0.07), 2.0)
            draw_line(Vector2(px+8,py+10),Vector2(px+3,py+16),Color(0.08,0.08,0.07),1.2)
