extends Node2D

const CampaignData=preload("res://scripts/campaign_data.gd")
var particles:Array=[]
var spawn_timer:=0.0
var player
var theme:="jungle"

func _ready():
    theme=String(CampaignData.level(GameState.current_level).theme)
    z_index=8

func _process(delta):
    if player==null or not is_instance_valid(player):
        player=get_tree().get_first_node_in_group("player")
    if player==null:return
    spawn_timer-=delta
    if spawn_timer<=0.0:
        spawn_timer=0.09 if theme in ["ice","lava","factory","toxic"] else 0.16
        _spawn_particle()
    for p in particles:
        p["x"]+=float(p["vx"])*delta
        p["y"]+=float(p["vy"])*delta
        p["life"]-=delta
    particles=particles.filter(func(q): return float(q["life"])>0.0)
    queue_redraw()

func _spawn_particle():
    if particles.size()>72:particles.pop_front()
    var p={"x":player.global_position.x+randf_range(-580,580),"y":randf_range(-120,430),"vx":0.0,"vy":0.0,"life":randf_range(1.2,3.4),"max":3.4,"size":randf_range(1.5,4.5)}
    match theme:
        "jungle": p["vx"]=randf_range(-8,18);p["vy"]=randf_range(18,42);p["size"]=randf_range(2,5)
        "desert": p["vx"]=randf_range(65,130);p["vy"]=randf_range(-8,8);p["size"]=randf_range(1,3)
        "harbor": p["vx"]=randf_range(-15,15);p["vy"]=randf_range(-35,-12);p["size"]=randf_range(2,5);p["y"]=randf_range(330,410)
        "ice": p["vx"]=randf_range(-24,18);p["vy"]=randf_range(22,54);p["size"]=randf_range(1.5,3.5)
        "factory": p["vx"]=randf_range(-28,28);p["vy"]=randf_range(30,85);p["size"]=randf_range(1,3);p["y"]=randf_range(170,360)
        "toxic": p["vx"]=randf_range(-12,12);p["vy"]=randf_range(-42,-18);p["size"]=randf_range(3,7);p["y"]=randf_range(330,430)
        "skyfort": p["vx"]=randf_range(90,155);p["vy"]=randf_range(-10,10);p["size"]=randf_range(1,3)
        "lava": p["vx"]=randf_range(-20,20);p["vy"]=randf_range(-70,-24);p["size"]=randf_range(2,5);p["y"]=randf_range(330,430)
        "cave", "nexus": p["vx"]=randf_range(-12,12);p["vy"]=randf_range(-18,18);p["size"]=randf_range(2,5)
        _: p["vx"]=randf_range(-10,10);p["vy"]=randf_range(15,30)
    particles.append(p)

func _draw():
    for p in particles:
        var a=clamp(float(p["life"])/max(0.1,float(p["max"])),0.0,1.0)
        var pos=Vector2(float(p["x"]),float(p["y"]))
        var size=float(p["size"])
        match theme:
            "ice": draw_circle(pos,size,Color(0.92,0.98,1.0,0.34*a))
            "lava": draw_circle(pos,size,Color(1.0,0.35,0.08,0.42*a))
            "factory": draw_line(pos,pos+Vector2(float(p["vx"])*0.05,float(p["vy"])*0.05),Color(1.0,0.72,0.22,0.48*a),1.5)
            "toxic": draw_circle(pos,size*1.7,Color(0.55,0.90,0.12,0.12*a))
            "desert": draw_line(pos,pos+Vector2(14,0),Color(0.86,0.68,0.40,0.18*a),1.0)
            "harbor": draw_circle(pos,size,Color(0.68,0.88,0.95,0.18*a))
            "cave", "nexus": draw_circle(pos,size,Color(0.70,0.38,1.0,0.22*a))
            "jungle": draw_line(pos,pos+Vector2(3,8),Color(0.47,0.62,0.25,0.18*a),1.3)
            "skyfort": draw_line(pos,pos+Vector2(18,0),Color(0.78,0.88,0.96,0.15*a),1.0)
            _: draw_circle(pos,size,Color(1,1,1,0.12*a))
