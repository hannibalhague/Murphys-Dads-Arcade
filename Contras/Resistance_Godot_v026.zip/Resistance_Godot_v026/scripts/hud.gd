extends CanvasLayer
const CampaignData=preload("res://scripts/campaign_data.gd")
var score_label;var stats_label;var status_label;var message_label;var boss_back;var boss_fill;var boss_text;var progress_back;var progress_fill;var progress_dot;var message_time=0.0
func _ready():
    layer=20
    var bar=ColorRect.new();bar.color=Color(0.018,0.028,0.032,.92);bar.position=Vector2(8,8);bar.size=Vector2(944,60);add_child(bar)
    score_label=Label.new();score_label.position=Vector2(20,14);score_label.add_theme_font_size_override("font_size",19);score_label.add_theme_color_override("font_color",Color(1,.86,.35));add_child(score_label)
    stats_label=Label.new();stats_label.position=Vector2(20,38);stats_label.add_theme_font_size_override("font_size",12);stats_label.add_theme_color_override("font_color",Color(0.86,0.91,0.82));add_child(stats_label)
    status_label=Label.new();status_label.position=Vector2(565,14);status_label.size=Vector2(370,46);status_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT;status_label.add_theme_font_size_override("font_size",12);status_label.add_theme_color_override("font_color",Color(0.76,0.91,0.96));add_child(status_label)
    boss_back=ColorRect.new();boss_back.position=Vector2(245,73);boss_back.size=Vector2(470,22);boss_back.color=Color(.05,.04,.04,.9);add_child(boss_back)
    boss_fill=ColorRect.new();boss_fill.position=Vector2(249,77);boss_fill.size=Vector2(462,14);boss_fill.color=Color(.88,.24,.13,.95);add_child(boss_fill)
    boss_text=Label.new();boss_text.position=Vector2(245,72);boss_text.size=Vector2(470,24);boss_text.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;boss_text.add_theme_font_size_override("font_size",12);boss_text.add_theme_color_override("font_color",Color(1,.9,.62));add_child(boss_text)
    progress_back=ColorRect.new();progress_back.position=Vector2(330,99);progress_back.size=Vector2(300,5);progress_back.color=Color(0.08,0.12,0.13,0.75);add_child(progress_back)
    progress_fill=ColorRect.new();progress_fill.position=Vector2(332,100);progress_fill.size=Vector2(0,3);progress_fill.color=Color(0.92,0.72,0.20,0.88);add_child(progress_fill)
    progress_dot=ColorRect.new();progress_dot.position=Vector2(330,97);progress_dot.size=Vector2(5,9);progress_dot.color=Color(1.0,0.90,0.45,0.95);add_child(progress_dot)
    for mx in [330.0,480.0,600.0,625.0]:
        var mark=ColorRect.new();mark.position=Vector2(mx,97);mark.size=Vector2(2,9);mark.color=Color(0.72,0.80,0.76,0.45);add_child(mark)
    var progress_text=Label.new();progress_text.position=Vector2(329,105);progress_text.size=Vector2(305,14);progress_text.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;progress_text.add_theme_font_size_override("font_size",8);progress_text.add_theme_color_override("font_color",Color(0.72,0.80,0.77,0.72));progress_text.text="START        🇨🇦 FLAG             BOSS   EXTRACT";add_child(progress_text)
    var help=Label.new();help.position=Vector2(12,507);help.size=Vector2(936,28);help.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;help.add_theme_font_size_override("font_size",10);help.add_theme_color_override("font_color",Color(0.82,0.87,0.82,0.82));help.text="KEYBOARD: WASD/ARROWS MOVE+AIM • SPACE JUMP • SHIFT FIRE • G GRENADE    GAMEPAD: STICK/D-PAD • A JUMP • X FIRE • B/Y GRENADE    TOUCH: JOYSTICK + BUTTONS";add_child(help)
    var track_button=Button.new();track_button.position=Vector2(770,72);track_button.size=Vector2(88,28);track_button.text=AudioManager.label();track_button.add_theme_font_size_override("font_size",10);track_button.tooltip_text="Switch numbered music tracks";add_child(track_button)
    track_button.pressed.connect(func(): AudioManager.next_track(); track_button.text=AudioManager.label())
    AudioManager.music_changed.connect(func(label): track_button.text=label)
    var select_button=Button.new();select_button.position=Vector2(862,72);select_button.size=Vector2(90,28);select_button.text="GAME SELECT";select_button.add_theme_font_size_override("font_size",9);select_button.tooltip_text="Return to the game select screen";add_child(select_button)
    select_button.pressed.connect(_game_select)
    message_label=Label.new();message_label.position=Vector2(160,104);message_label.size=Vector2(640,44);message_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;message_label.add_theme_font_size_override("font_size",21);message_label.add_theme_color_override("font_color",Color(1,.84,.2));add_child(message_label)
    GameState.stats_changed.connect(_update);GameState.message_requested.connect(_show_message);_update()
func _process(delta):
    if message_time>0:message_time-=delta;message_label.modulate.a=clamp(message_time*1.7,0,1);if message_time<=0:message_label.text=""
    var p=get_tree().get_first_node_in_group("player")
    if p!=null and is_instance_valid(p):
        var ratio=clamp(p.global_position.x/7000.0,0.0,1.0)
        progress_fill.size.x=296.0*ratio
        progress_dot.position.x=330.0+296.0*ratio
func _update():
    var lv=CampaignData.level(GameState.current_level)
    score_label.text="SCORE  %07d"%GameState.score
    stats_label.text="HP %d/5   LIVES %d   CONT %d   GREN %d   HOST %d/%d   HEAD %d   CHEST %d   BOOK %d   GOLD %d"%[GameState.health,GameState.lives,GameState.continues,GameState.grenades,GameState.hostages_rescued,GameState.hostages_total,GameState.held_heads,GameState.chests,GameState.books,GameState.gold]
    var show=GameState.boss_active and not GameState.boss_defeated and GameState.boss_max_hp>0
    boss_back.visible=show;boss_fill.visible=show;boss_text.visible=show
    if show:
        var ratio=clamp(GameState.boss_hp/GameState.boss_max_hp,0,1);boss_fill.size.x=462*ratio;boss_text.text="%s   %d%%"%[GameState.boss_name,int(round(ratio*100))]
    if GameState.campaign_complete:status_label.text="ALL 10 MISSIONS CLEARED!"
    elif GameState.victory_flight:status_label.text="STAGE %d  %s\nUP/DOWN FLY • FIRE • ROTOR CHOPS"%[GameState.current_level+1,lv.name]
    elif GameState.commander_executed:status_label.text="HEAD HELD HIGH\nFIREWORKS — JUMP ON THE LONG LADDER"
    elif GameState.boss_defeated:status_label.text="UNKILLABLE\nRUN TO THE BLUE-SUIT BOSS MAN"
    else:status_label.text="STAGE %d/10  %s\nBOSS: %s"%[GameState.current_level+1,lv.name,lv.boss]
func _show_message(text):message_label.text=String(text);message_label.modulate.a=1;message_time=2.25

func _game_select():
    get_tree().paused=false
    if OS.has_feature("web"):
        JavaScriptBridge.eval("window.location.href='../index.html';")
    else:
        get_tree().quit()
