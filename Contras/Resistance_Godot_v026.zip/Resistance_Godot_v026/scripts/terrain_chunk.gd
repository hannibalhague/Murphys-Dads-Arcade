extends Node2D

var terrain = null
var chunk_x = 0

func setup(owner_terrain, owner_chunk_x):
    terrain = owner_terrain
    chunk_x = int(owner_chunk_x)
    queue_redraw()

func _draw():
    if terrain == null:
        return
    var start_x = chunk_x * terrain.visual_chunk_width
    var end_x = start_x + terrain.visual_chunk_width - 1
    for coord in terrain.cells.keys():
        if coord.x < start_x or coord.x > end_x:
            continue
        var data = terrain.cells[coord]
        var p = Vector2((coord.x - start_x) * terrain.cell_size, coord.y * terrain.cell_size)
        var mat = String(data["material"])
        var c = terrain.cell_color(mat)
        var cell_seed = abs(coord.x * 92821 + coord.y * 68917)
        var tint = float(cell_seed % 7) * 0.012
        c = c.lightened(tint)
        # Overlap cells slightly and avoid outlining every tile so terrain reads as one mass, not graph paper.
        draw_rect(Rect2(p,Vector2(terrain.cell_size+1,terrain.cell_size+1)), c)

        if not terrain.cells.has(coord + Vector2i(0,-1)):
            var top_color = Color(0.28,0.46,0.22) if coord.y * terrain.cell_size == terrain.surface_y else c.lightened(0.24)
            draw_rect(Rect2(p + Vector2(0,1),Vector2(terrain.cell_size+1,6)),top_color)
            # Irregular turf/rock bumps soften the square top silhouette.
            for bx in [4.0,11.0,19.0,27.0]:
                var rr=2.0+float((cell_seed+int(bx))%4)
                draw_circle(p+Vector2(bx,2.0+float((cell_seed+int(bx*3))%3)),rr,top_color.lightened(0.04))
        if not terrain.cells.has(coord + Vector2i(-1,0)):
            draw_line(p + Vector2(2,4),p + Vector2(2,terrain.cell_size-3),c.lightened(0.18),2.0)
        if not terrain.cells.has(coord + Vector2i(1,0)):
            draw_line(p + Vector2(terrain.cell_size-2,4),p + Vector2(terrain.cell_size-2,terrain.cell_size-3),c.darkened(0.18),2.0)
        if not terrain.cells.has(coord + Vector2i(0,1)):
            draw_line(p + Vector2(4,terrain.cell_size-2),p + Vector2(terrain.cell_size-4,terrain.cell_size-2),c.darkened(0.22),2.0)

        if mat == "dirt" and cell_seed % 3 == 0:
            draw_circle(p + Vector2(9 + cell_seed % 11,19 + cell_seed % 6),2.0,c.lightened(0.13))
            if cell_seed % 3 == 0:
                draw_circle(p + Vector2(23 - cell_seed % 7,8 + cell_seed % 9),1.4,c.darkened(0.22))
            if cell_seed % 5 == 0:
                draw_line(p + Vector2(5,11),p + Vector2(11,8),c.lightened(0.18),1.0)
        elif mat == "rock":
            draw_line(p + Vector2(6,22),p + Vector2(15,17),c.darkened(0.18),1.0)
        elif mat == "brick":
            draw_line(p + Vector2(2,16),p + Vector2(terrain.cell_size-2,16),c.darkened(0.18),1.0)
            draw_line(p + Vector2(16,2),p + Vector2(16,16),c.darkened(0.18),1.0)

        var hp_ratio = float(data["hp"]) / float(data["max_hp"])
        if hp_ratio < 0.95:
            draw_line(p + Vector2(7,8), p + Vector2(18,18), Color(0.10,0.08,0.06), 2.0)
            if hp_ratio < 0.55:
                draw_line(p + Vector2(18,18), p + Vector2(26,9), Color(0.10,0.08,0.06), 2.0)
                draw_line(p + Vector2(18,18), p + Vector2(14,27), Color(0.10,0.08,0.06), 2.0)
