extends Area2D

@export var ladder_size = Vector2(36, 180)

func _ready():
    collision_layer = 0
    collision_mask = 0
    add_to_group("ladder")
    var shape = RectangleShape2D.new()
    shape.size = ladder_size
    var cs = CollisionShape2D.new()
    cs.shape = shape
    add_child(cs)
    queue_redraw()

func contains_world_point(point):
    var local = to_local(point)
    return Rect2(-ladder_size * 0.5, ladder_size).grow(10.0).has_point(local)

func _draw():
    var top = -ladder_size.y * 0.5
    var bottom = ladder_size.y * 0.5
    draw_line(Vector2(-12,top), Vector2(-12,bottom), Color(0.48,0.39,0.24), 5.0)
    draw_line(Vector2(12,top), Vector2(12,bottom), Color(0.48,0.39,0.24), 5.0)
    var y = top + 10.0
    while y < bottom:
        draw_line(Vector2(-12,y), Vector2(12,y), Color(0.72,0.60,0.34), 4.0)
        y += 18.0
