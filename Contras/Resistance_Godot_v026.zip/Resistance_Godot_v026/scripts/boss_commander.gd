extends CharacterBody2D

@export var jump_speed=430.0
@export var run_speed=92.0
var player
var age=0.0
var landed=false
var headless=false
var execution_started=false
@onready var sprite=$Sprite
@onready var collision=$CollisionShape2D

func _ready():
    add_to_group("boss_commander")
    collision_layer=3;collision_mask=1
    sprite.visible=false
    velocity=Vector2(-110.0,-jump_speed)
    GameState.mark_commander_spawned()
    queue_redraw()

func _physics_process(delta):
    age+=delta
    if headless:
        velocity.x=move_toward(velocity.x,0.0,400.0*delta)
        velocity.y+=1400.0*delta
        move_and_slide();queue_redraw();return
    if player==null or not is_instance_valid(player):player=get_tree().get_first_node_in_group("player")
    if not is_on_floor():velocity.y+=1400.0*delta
    else:
        landed=true;velocity.y=0.0
        if not execution_started:
            velocity.x=-run_speed if age<1.55 else move_toward(velocity.x,0.0,700.0*delta)
    move_and_slide()
    if player!=null and landed and not execution_started and age>.55 and player.global_position.distance_to(global_position)<62.0:
        execution_started=true;velocity=Vector2.ZERO
        if player.has_method("start_boss_execution"):player.start_boss_execution(self)
    queue_redraw()

func behead():
    if headless:return
    headless=true;execution_started=true;collision_layer=0;velocity=Vector2(45,-130)
    GameState.execute_commander(global_position+Vector2(0,-28))
    var b=preload("res://scenes/Burst.tscn").instantiate();b.global_position=global_position+Vector2(0,-27);b.burst_kind="orange";b.scale=Vector2(.65,.65);get_tree().current_scene.add_child(b)
    queue_redraw()

func _draw():
    # Exact HTML victory target look: blue business suit, orange skin, yellow hair.
    if headless:
        draw_rect(Rect2(-14,-18,28,31),Color("2b68d6"))
        draw_rect(Rect2(-7,-16,14,20),Color("f2efe9"))
        draw_rect(Rect2(-2,-13,4,17),Color("cc272d"))
        draw_rect(Rect2(-12,13,8,21),Color("173063"));draw_rect(Rect2(4,13,8,21),Color("173063"))
        draw_circle(Vector2(0,-20),8,Color("681018"));return
    draw_rect(Rect2(-14,-17,28,32),Color("2b68d6"))
    draw_rect(Rect2(-7,-15,14,22),Color("f2efe9"))
    draw_colored_polygon(PackedVector2Array([Vector2(0,-13),Vector2(-4,1),Vector2(0,12),Vector2(4,1)]),Color("cc272d"))
    draw_rect(Rect2(-12,15,8,20),Color("173063"));draw_rect(Rect2(4,15,8,20),Color("173063"))
    draw_line(Vector2(-12,-10),Vector2(-21,5),Color("2b68d6"),7);draw_line(Vector2(12,-10),Vector2(21,7),Color("2b68d6"),7)
    draw_circle(Vector2(-22,7),4,Color("e1973f"));draw_circle(Vector2(22,9),4,Color("e1973f"))
    draw_rect(Rect2(-4,-27,8,8),Color("e0852d"))
    draw_circle(Vector2(0,-38),13,Color("ef8b2d"))
    draw_colored_polygon(PackedVector2Array([Vector2(-12,-44),Vector2(-7,-51),Vector2(5,-52),Vector2(12,-45),Vector2(10,-39),Vector2(-11,-39)]),Color("ffe148"))
    draw_rect(Rect2(-9,-40,18,3),Color("ffe148"))
    draw_rect(Rect2(-6,-40,3,2),Color.WHITE);draw_rect(Rect2(3,-40,3,2),Color.WHITE)
    draw_circle(Vector2(-4.5,-39.5),0.7,Color("4a2a1b"));draw_circle(Vector2(4.5,-39.5),0.7,Color("4a2a1b"))
    draw_line(Vector2(-4,-32),Vector2(4,-32),Color("8a381e"),1.5)
