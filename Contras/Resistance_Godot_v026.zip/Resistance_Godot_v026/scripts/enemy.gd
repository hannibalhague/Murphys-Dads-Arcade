extends CharacterBody2D

@export var enemy_kind = "soldier"
@export var max_hp = 3.0
@export var move_speed = 92.0
@export var fire_range = 455.0
@export var sight_range = 680.0
@export var shot_delay = 1.90
@export var bullet_speed = 390.0
@export var reaction_time = 0.50
@export var patrol_radius = 105.0
@export var score_value = 250
@export var active_distance = 1450.0

var hp = 3.0
var target = null
var fire_timer = 1.0
var contact_timer = 0.0
var spawn_x = 0.0
var patrol_dir = 1.0
var target_seen_time = 0.0
var muzzle_flash = 0.0
var celebrate_time = 0.0
var celebrate_jump_wait = 0.0
var base_modulate = Color.WHITE
var damage_bar_time := 0.0
var alert_flash := 0.0
var special_move_timer := 0.0
var support_timer := 2.5
var gait_time := 0.0
var recoil_time := 0.0

@onready var sprite = $Sprite

func _ready():
    hp = max_hp
    spawn_x = global_position.x
    add_to_group("enemy")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    _apply_enemy_kind()

func _apply_enemy_kind():
    sprite.modulate = Color.WHITE
    match enemy_kind:
        "scout":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.72,0.88,0.62)
            move_speed = max(move_speed,108.0); sight_range=760.0; reaction_time=0.32; shot_delay=max(shot_delay,1.75); score_value=max(score_value,290)
        "officer":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.48,0.62,0.82)
            sight_range=820.0; fire_range=520.0; reaction_time=0.38; shot_delay=max(shot_delay,2.05); score_value=max(score_value,360)
        "commando":
            sprite.texture = load("res://art/raider.png")
            sprite.modulate = Color(0.42,0.62,0.46)
            move_speed=max(move_speed,102.0); sight_range=760.0; reaction_time=0.30; shot_delay=max(shot_delay,1.95); score_value=max(score_value,390)
        "rocketeer":
            sprite.texture = load("res://art/heavy.png")
            sprite.modulate = Color(0.72,0.54,0.32)
            fire_range=590.0; bullet_speed=315.0; shot_delay=max(shot_delay,2.75); score_value=max(score_value,430)
        "shield":
            sprite.texture = load("res://art/heavy.png")
            sprite.modulate = Color(0.46,0.54,0.58)
            move_speed=min(move_speed,58.0); shot_delay=max(shot_delay,2.35); score_value=max(score_value,420)
        "medic":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.86,0.88,0.78)
            move_speed=max(move_speed,82.0); shot_delay=max(shot_delay,2.25); score_value=max(score_value,330)
        "diver":
            sprite.texture = load("res://art/raider.png")
            sprite.modulate = Color(0.35,0.66,0.78)
            move_speed=max(move_speed,86.0); reaction_time=0.42; score_value=max(score_value,340)
        "iceguard":
            sprite.texture = load("res://art/heavy.png")
            sprite.modulate = Color(0.72,0.88,0.98)
            shot_delay=max(shot_delay,2.30); score_value=max(score_value,400)
        "mutant":
            sprite.texture = load("res://art/alien.png")
            sprite.modulate = Color(0.72,1.0,0.42)
            fire_range=0.0; sight_range=610.0; move_speed=max(move_speed,118.0); score_value=max(score_value,350)
        "cyborg":
            sprite.texture = load("res://art/robot.png")
            sprite.modulate = Color(0.64,0.82,0.90)
            shot_delay=max(shot_delay,2.10); reaction_time=0.36; score_value=max(score_value,440)
        "heavy":
            sprite.texture = load("res://art/heavy.png")
            shot_delay = max(shot_delay, 2.15)
            score_value = max(score_value, 350)
        "raider", "sandraider", "waterraider":
            sprite.texture = load("res://art/raider.png")
            score_value = max(score_value, 300)
            if enemy_kind == "sandraider": sprite.modulate = Color(1.0,0.82,0.58)
            elif enemy_kind == "waterraider": sprite.modulate = Color(0.58,0.86,1.0)
        "robot", "drone":
            sprite.texture = load("res://art/robot.png")
            shot_delay = max(shot_delay, 2.05)
            score_value = max(score_value, 375)
            if enemy_kind == "drone": sprite.modulate = Color(0.72,0.88,1.0)
        "alien":
            sprite.texture = load("res://art/alien.png")
            sprite.modulate = Color(0.82,1.0,0.74)
            score_value = max(score_value, 340)
        "dog_guard", "dog_snow", "dog_water", "dog_attack":
            sprite.texture = load("res://art/dog.png")
            fire_range = 0.0
            sight_range = 520.0
            move_speed = max(move_speed,96.0)
            score_value = max(score_value,220)
            if enemy_kind == "dog_snow": sprite.modulate = Color(0.82,0.92,1.0)
            elif enemy_kind == "dog_water": sprite.modulate = Color(0.60,0.78,0.88)
            elif enemy_kind == "dog_attack":
                sprite.modulate = Color(0.78,0.55,0.35)
                move_speed = max(move_speed,126.0)
                sight_range = 610.0
                score_value = max(score_value,280)
        "snowtrooper":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.76,0.88,1.0)
        "ninja":
            sprite.texture = load("res://art/raider.png")
            sprite.modulate = Color(0.38,0.42,0.48)
            move_speed = max(move_speed,88.0)
        "suit":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.64,0.72,0.92)
        "rich":
            sprite.texture = load("res://art/soldier.png")
            sprite.modulate = Color(0.92,0.76,0.42)
        "flamer":
            sprite.texture = load("res://art/heavy.png")
            sprite.modulate = Color(1.0,0.62,0.35)
            shot_delay = max(shot_delay,2.20)
        "grenadier":
            sprite.texture = load("res://art/heavy.png")
            sprite.modulate = Color(0.62,0.78,0.52)
            shot_delay = max(shot_delay,2.25)
        _:
            sprite.texture = load("res://art/soldier.png")
    base_modulate = sprite.modulate

func _physics_process(delta):
    if target == null or not is_instance_valid(target):
        target = get_tree().get_first_node_in_group("player")
    if target == null:
        return

    if GameState.celebration_active:
        _celebrate(delta)
        return

    var delta_pos = target.global_position - global_position
    var dist = delta_pos.length()
    var dx = delta_pos.x

    # Far enemies sleep instead of doing raycasts/AI every physics frame.
    # If one is still airborne, let it finish falling before sleeping.
    if dist > active_distance:
        velocity.x = 0.0
        muzzle_flash = 0.0
        if not is_on_floor():
            velocity.y += 1400.0 * delta
            move_and_slide()
        return

    fire_timer -= delta
    contact_timer = max(0.0, contact_timer - delta)
    muzzle_flash = max(0.0, muzzle_flash - delta)
    damage_bar_time = max(0.0, damage_bar_time - delta)
    alert_flash = max(0.0, alert_flash - delta)
    special_move_timer = max(0.0, special_move_timer - delta)
    support_timer = max(0.0, support_timer - delta)
    recoil_time = max(0.0, recoil_time - delta)
    gait_time += delta * (2.0 + abs(velocity.x) * 0.025)
    if not is_on_floor():
        velocity.y += 1400.0 * delta
    var can_see = dist < sight_range and abs(delta_pos.y) < 250.0 and _has_line_of_sight()

    if can_see:
        if target_seen_time <= 0.02:
            alert_flash = 0.7
        target_seen_time += delta
        if abs(dx) > 155.0:
            velocity.x = move_toward(velocity.x, sign(dx) * move_speed, 800.0 * delta)
        else:
            velocity.x = move_toward(velocity.x, 0.0, 950.0 * delta)
    elif dist < 900.0:
        # The enemy heard/saw something nearby and investigates, but cannot fire through terrain or buildings.
        target_seen_time = max(0.0, target_seen_time - delta * 2.5)
        velocity.x = move_toward(velocity.x, sign(dx) * move_speed * 0.55, 650.0 * delta)
    else:
        target_seen_time = 0.0
        if global_position.x > spawn_x + patrol_radius:
            patrol_dir = -1.0
        elif global_position.x < spawn_x - patrol_radius:
            patrol_dir = 1.0
        velocity.x = move_toward(velocity.x, patrol_dir * move_speed * 0.35, 500.0 * delta)

    # Dogs now commit to a readable leap when they get close instead of only sliding into contact.
    if enemy_kind.begins_with("dog") and can_see and is_on_floor() and dist < 155.0 and abs(delta_pos.y) < 62.0 and special_move_timer <= 0.0:
        velocity.x = sign(dx) * move_speed * (1.75 if enemy_kind == "dog_attack" else 1.55)
        velocity.y = -245.0 if enemy_kind == "dog_attack" else -215.0
        special_move_timer = 1.15
        alert_flash = max(alert_flash,0.22)

    # Medics periodically restore a little health to one nearby non-boss ally.
    if enemy_kind == "medic" and support_timer <= 0.0:
        _medic_support()
        support_timer = 4.5

    move_and_slide()

    if can_see and dist < fire_range and fire_timer <= 0.0 and target_seen_time >= reaction_time:
        # Standard enemies fire at standing chest height rather than tracking the crouched hitbox.
        # This makes an intentional duck genuinely let a normal rifle round pass overhead.
        var muzzle_point = global_position + Vector2(0, -5)
        var chest_point = target.global_position + Vector2(0, -8)
        _shoot((chest_point - muzzle_point).normalized())
        fire_timer = shot_delay + randf_range(-0.05, 0.35)

    if dist < 34.0 and contact_timer <= 0.0 and target.has_method("take_damage"):
        target.take_damage(1, global_position)
        contact_timer = 1.15

    sprite.flip_h = dx < 0.0
    var moving = abs(velocity.x) > 10.0
    var frame_rate = 80.0 if enemy_kind.begins_with("dog") else (105.0 if moving else 180.0)
    sprite.frame = int(float(Time.get_ticks_msec()) / frame_rate) % 8
    # Small body motion makes enemies feel planted and alive instead of sliding rigidly.
    var run_bob = sin(gait_time * 2.0) * (2.5 if moving else 0.55)
    var lean = clamp(velocity.x / max(move_speed,1.0),-1.0,1.0) * 0.055
    if enemy_kind.begins_with("dog"):
        run_bob *= 0.55
        lean *= 1.6
    if not is_on_floor():
        lean += clamp(velocity.y / 900.0,-0.10,0.12)
    if recoil_time > 0.0:
        lean -= (-1.0 if sprite.flip_h else 1.0) * 0.055
    sprite.position.y = run_bob
    sprite.rotation = lean
    queue_redraw()


func _celebrate(delta):
    celebrate_time += delta
    celebrate_jump_wait -= delta
    muzzle_flash = 0.0
    velocity.x = move_toward(velocity.x,0.0,1100.0*delta)
    if not is_on_floor():
        velocity.y += 1400.0*delta
    elif celebrate_jump_wait <= 0.0:
        celebrate_jump_wait = 0.65 + randf_range(0.0,1.0)
        velocity.y = -175.0 - randf_range(0.0,85.0)
    move_and_slide()
    sprite.frame = int(celebrate_time * 9.0 + global_position.x * 0.013) % 8
    sprite.rotation = sin(celebrate_time*7.5 + global_position.x*0.02) * 0.10
    queue_redraw()

func _has_line_of_sight():
    var from = global_position + Vector2(0, -8)
    var to = target.global_position + Vector2(0, -8)
    var query = PhysicsRayQueryParameters2D.create(from, to)
    query.collision_mask = 1
    query.exclude = [get_rid()]
    query.collide_with_areas = false
    var hit = get_world_2d().direct_space_state.intersect_ray(query)
    return hit.is_empty()

func _shoot(dir):
    dir = dir.rotated(randf_range(-0.025, 0.025)).normalized()
    var scene = preload("res://scenes/Bullet.tscn")
    if enemy_kind == "flamer":
        AudioManager.play_sfx("enemy",-8.0,randf_range(0.90,0.98))
        # A visible short-range stream instead of a normal rifle tracer.
        for i in range(5):
            var flame_projectile = scene.instantiate()
            var flame_dir = dir.rotated(randf_range(-0.11,0.11)).normalized()
            flame_projectile.team = "enemy"
            flame_projectile.projectile_kind = "flame"
            flame_projectile.speed = 185.0 + float(i) * 18.0
            flame_projectile.damage = 1.0
            flame_projectile.direction = flame_dir
            flame_projectile.life = 0.52 + float(i) * 0.045
            flame_projectile.global_position = global_position + dir * (22.0 + float(i)*5.0) + Vector2(0,-5)
            get_tree().current_scene.add_child(flame_projectile)
        muzzle_flash = 0.16
        recoil_time = 0.18
        return
    AudioManager.play_sfx("enemy",-12.0,randf_range(0.94,1.05))
    var rifle_projectile = scene.instantiate()
    rifle_projectile.team = "enemy"
    rifle_projectile.speed = bullet_speed
    rifle_projectile.damage = 1.0
    rifle_projectile.direction = dir
    rifle_projectile.global_position = global_position + dir * 24.0 + Vector2(0,-5)
    get_tree().current_scene.add_child(rifle_projectile)
    muzzle_flash = 0.075
    recoil_time = 0.10

func take_damage(amount, hit_position = Vector2.ZERO):
    var applied_amount = float(amount)
    if enemy_kind == "shield" and hit_position != Vector2.ZERO:
        var facing_side = -1.0 if sprite.flip_h else 1.0
        var source_side = sign(hit_position.x - global_position.x)
        if source_side == facing_side:
            applied_amount *= 0.35
            alert_flash = max(alert_flash,0.18)
            AudioManager.play_sfx("shield",-12.0,randf_range(0.96,1.04))
    hp -= applied_amount
    damage_bar_time = 1.15
    sprite.modulate = Color(1.0,0.55,0.55)
    get_tree().create_timer(0.08).timeout.connect(_clear_hit)
    if hp <= 0.0:
        GameState.add_score(score_value)
        AudioManager.play_sfx("kill",-9.0,randf_range(0.95,1.05))
        GameState.screen_shake_requested.emit(2.5)
        var scene = preload("res://scenes/Burst.tscn")
        var b = scene.instantiate()
        b.global_position = global_position
        b.burst_kind = "orange" if enemy_kind != "robot" else "cyan"
        get_tree().current_scene.add_child(b)
        queue_free()

func _medic_support():
    var best_ally = null
    var most_missing := 0.0
    for ally in get_tree().get_nodes_in_group("enemy"):
        if ally == self or not is_instance_valid(ally) or ally.is_in_group("boss") or ally.is_in_group("boss_commander"):
            continue
        var d = global_position.distance_to(ally.global_position)
        var missing = float(ally.max_hp) - float(ally.hp)
        if d <= 165.0 and missing > most_missing + 0.01:
            most_missing = missing
            best_ally = ally
    if best_ally == null:
        return
    best_ally.hp = min(float(best_ally.max_hp), float(best_ally.hp) + 0.75)
    if "damage_bar_time" in best_ally:
        best_ally.damage_bar_time = max(float(best_ally.damage_bar_time),0.8)
    var fx = preload("res://scenes/Burst.tscn").instantiate()
    fx.global_position = best_ally.global_position + Vector2(0,-16)
    fx.burst_kind = "cyan"
    fx.scale = Vector2(0.28,0.28)
    get_tree().current_scene.add_child(fx)
    AudioManager.play_sfx("medic",-12.0,1.0)

func _clear_hit():
    if is_instance_valid(sprite):
        sprite.modulate = base_modulate

func _draw():
    # subtle contact shadow helps characters sit in the world rather than float over it
    _draw_ellipse_poly(Vector2(0,24),Vector2(15 if not enemy_kind.begins_with("dog") else 20,4),Color(0,0,0,0.20))
    if not GameState.celebration_active:
        var gear_side=-1.0 if sprite.flip_h else 1.0
        if enemy_kind == "heavy":
            draw_rect(Rect2(gear_side*11-5,-18,10,11),Color(0.18,0.20,0.18,0.9))
        elif enemy_kind in ["flamer","grenadier"]:
            draw_circle(Vector2(-gear_side*9,-7),6.0,Color(0.24,0.28,0.19,0.88))
        elif enemy_kind == "ninja":
            draw_line(Vector2(-12,-22),Vector2(12,-22),Color(0.08,0.08,0.09,0.85),3.0)
    # Procedural secondary motion adds flexible limbs/gear over the sprite so movement is not a rigid flipbook.
    if not GameState.celebration_active:
        var motion_side=-1.0 if sprite.flip_h else 1.0
        var stride=sin(gait_time*2.0) * clamp(abs(velocity.x)/max(move_speed,1.0),0.0,1.0)
        if enemy_kind.begins_with("dog"):
            draw_line(Vector2(-13,7),Vector2(-17+stride*5.0,20),Color(0.18,0.13,0.09,0.70),3.0)
            draw_line(Vector2(11,7),Vector2(15-stride*5.0,20),Color(0.18,0.13,0.09,0.70),3.0)
            draw_line(Vector2(-17,-8),Vector2(-25,-14-stride*3.0),Color(0.25,0.17,0.11,0.75),3.0)
        elif enemy_kind not in ["robot","drone","cyborg","mutant"]:
            draw_line(Vector2(-7,9),Vector2(-8+stride*4.0,23),Color(0.12,0.14,0.13,0.62),3.0)
            draw_line(Vector2(7,9),Vector2(8-stride*4.0,23),Color(0.12,0.14,0.13,0.62),3.0)
            draw_line(Vector2(-motion_side*8,-12),Vector2(-motion_side*13,-1+stride*3.0),Color(0.44,0.31,0.22,0.58),3.0)
        # Helmet rim, shoulder pad and chest strap add depth at small sprite scale.
        if not enemy_kind.begins_with("dog") and enemy_kind not in ["mutant","alien"]:
            draw_arc(Vector2(0,-21),8.5,PI,TAU,12,Color(0.10,0.13,0.12,0.56),2.0)
            draw_line(Vector2(-8,-10),Vector2(8,5),Color(0.08,0.10,0.09,0.32),2.0)
            draw_circle(Vector2(motion_side*10,-8),3.0,Color(0.16,0.20,0.18,0.52))
    # v019 role silhouettes: readable equipment rather than palette-only variants.
    var side=-1.0 if sprite.flip_h else 1.0
    if enemy_kind == "officer":
        draw_rect(Rect2(-10,-27,20,4),Color(0.12,0.16,0.24,0.95)); draw_rect(Rect2(-7,-32,14,6),Color(0.18,0.24,0.38,0.95)); draw_circle(Vector2(side*8,-10),2.2,Color(0.95,0.75,0.25))
    elif enemy_kind == "scout":
        draw_line(Vector2(-side*5,-19),Vector2(-side*11,7),Color(0.16,0.22,0.14),4.0); draw_circle(Vector2(side*7,-21),3.0,Color(0.42,0.70,0.38))
    elif enemy_kind == "commando":
        draw_rect(Rect2(-12,-20,24,6),Color(0.08,0.11,0.09,0.85)); draw_circle(Vector2(side*10,-4),4.0,Color(0.18,0.24,0.18))
    elif enemy_kind == "rocketeer":
        draw_rect(Rect2(-side*16,-15,10,30),Color(0.18,0.20,0.18)); draw_rect(Rect2(side*3,-17,side*26,7) if side>0 else Rect2(side*29,-17,26,7),Color(0.24,0.25,0.20))
    elif enemy_kind == "shield":
        var sx=side*14.0; draw_rect(Rect2(sx-7,-17,14,31),Color(0.20,0.30,0.34,0.94)); draw_rect(Rect2(sx-5,-14,10,25),Color(0.38,0.48,0.52,0.70),false,2.0)
    elif enemy_kind == "medic":
        draw_rect(Rect2(-7,-16,14,14),Color(0.92,0.92,0.82)); draw_rect(Rect2(-2,-14,4,10),Color(0.78,0.12,0.12)); draw_rect(Rect2(-5,-11,10,4),Color(0.78,0.12,0.12))
    elif enemy_kind == "diver":
        draw_circle(Vector2(0,-20),8.0,Color(0.12,0.26,0.32,0.85)); draw_rect(Rect2(-7,-22,14,5),Color(0.40,0.82,0.90,0.50)); draw_circle(Vector2(-side*10,-4),5.0,Color(0.16,0.28,0.30))
    elif enemy_kind == "iceguard":
        draw_rect(Rect2(-12,-28,24,5),Color(0.84,0.94,1.0,0.85)); draw_circle(Vector2(-side*10,-5),5.0,Color(0.66,0.82,0.92))
    elif enemy_kind == "cyborg":
        draw_circle(Vector2(side*6,-21),2.5,Color(1.0,0.22,0.12)); draw_line(Vector2(-side*9,-15),Vector2(-side*12,9),Color(0.42,0.62,0.66),3.0)
    elif enemy_kind == "mutant":
        draw_line(Vector2(-8,-17),Vector2(-18,-7),Color(0.55,0.88,0.28),5.0); draw_line(Vector2(8,-17),Vector2(18,-7),Color(0.55,0.88,0.28),5.0)
    elif enemy_kind.begins_with("dog"):
        # Harness, collar and teeth make dogs read as attack animals at game scale.
        draw_line(Vector2(-12,-5),Vector2(10,-5),Color(0.13,0.10,0.08),4.0); draw_circle(Vector2(side*17,-9),2.4,Color(0.96,0.96,0.82)); draw_line(Vector2(side*16,-5),Vector2(side*20,-2),Color(0.96,0.96,0.82),1.5)
    # Visible weapons/arms keep enemies readable even when the base sprite pose is subtle.
    if not enemy_kind.begins_with("dog") and enemy_kind not in ["mutant","robot","drone","cyborg"]:
        var gun_y = -8.0
        var gun_len = 25.0 if enemy_kind not in ["heavy","flamer","rocketeer"] else 31.0
        draw_line(Vector2(side*4,gun_y),Vector2(side*(4+gun_len),gun_y-1),Color(0.10,0.12,0.11),4.0)
        draw_line(Vector2(side*6,gun_y+2),Vector2(side*15,gun_y+6),Color(0.70,0.52,0.34),3.0)
        if enemy_kind == "flamer":
            draw_circle(Vector2(-side*10,-8),7.0,Color(0.28,0.31,0.22))
            draw_circle(Vector2(-side*10,-8),4.6,Color(0.43,0.48,0.30))
            draw_line(Vector2(side*18,-9),Vector2(side*33,-9),Color(0.30,0.32,0.25),8.0)
    if alert_flash > 0.0 and not GameState.celebration_active:
        var pulse=1.0+0.08*sin(Time.get_ticks_msec()*0.02)
        draw_colored_polygon(PackedVector2Array([Vector2(-4,-39)*pulse,Vector2(4,-39)*pulse,Vector2(2,-29)*pulse,Vector2(-2,-29)*pulse]),Color(1.0,0.78,0.18,0.88))
        draw_circle(Vector2(0,-25),1.8,Color(1.0,0.78,0.18,0.88))
    if damage_bar_time > 0.0 and hp > 0.0 and hp < max_hp:
        var w=28.0
        draw_rect(Rect2(-w*0.5,-35,w,4),Color(0.02,0.03,0.03,0.72))
        draw_rect(Rect2(-w*0.5+1,-34,(w-2)*clamp(hp/max_hp,0.0,1.0),2),Color(0.92,0.22,0.15,0.92))
    if GameState.celebration_active:
        # Raised-arm cheer marks make the flyback celebration readable even with small sprites.
        var cheer_pulse = 2.0 + 2.0 * sin(celebrate_time * 8.0 + global_position.x * 0.02)
        draw_line(Vector2(-9,-13),Vector2(-17,-28-cheer_pulse),Color(0.95,0.83,0.48),3.0)
        draw_line(Vector2(9,-13),Vector2(17,-28-cheer_pulse),Color(0.95,0.83,0.48),3.0)
        draw_line(Vector2(-23,-31),Vector2(-29,-38),Color(1.0,0.86,0.25,0.85),2.0)
        draw_line(Vector2(23,-31),Vector2(29,-38),Color(1.0,0.86,0.25,0.85),2.0)
        return
    if muzzle_flash > 0.0:
        var muzzle_side = -1.0 if sprite.flip_h else 1.0
        var muzzle_pos = Vector2(muzzle_side * (30.0 if enemy_kind == "flamer" else 24.0), -7.0)
        if enemy_kind == "flamer":
            draw_circle(muzzle_pos,11.0,Color(1.0,0.22,0.03,0.34))
            draw_circle(muzzle_pos+Vector2(muzzle_side*5,0),7.0,Color(1.0,0.52,0.06,0.82))
            draw_circle(muzzle_pos+Vector2(muzzle_side*9,0),3.8,Color(1.0,0.96,0.55,0.96))
        else:
            draw_circle(muzzle_pos, 7.0, Color(1.0,0.72,0.18,0.90))
            draw_circle(muzzle_pos + Vector2(muzzle_side * 5.0,0), 3.5, Color(1.0,0.95,0.60,0.95))

func _draw_ellipse_poly(center:Vector2, radius:Vector2, color:Color):
    var pts=PackedVector2Array()
    for i in range(20):
        var a=TAU*float(i)/20.0
        pts.append(center+Vector2(cos(a)*radius.x,sin(a)*radius.y))
    draw_colored_polygon(pts,color)
