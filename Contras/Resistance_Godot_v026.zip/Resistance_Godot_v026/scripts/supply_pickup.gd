extends Area2D

var pulse = 0.0
var collected = false
var base_y = 0.0

func _ready():
    collision_layer = 0
    collision_mask = 2
    monitoring = true
    body_entered.connect(_on_body_entered)
    base_y=position.y
    queue_redraw()

func _process(delta):
    pulse += delta
    position.y=base_y+sin(pulse*2.1)*1.2
    queue_redraw()

func _on_body_entered(body):
    if collected or not body.is_in_group("player"):
        return
    collected = true
    monitoring = false
    GameState.heal(2)
    GameState.add_grenades(2)
    GameState.add_score(500)
    GameState.message_requested.emit("FIELD SUPPLY  +2 HP  +2 GRENADES  +500")
    var b = preload("res://scenes/Burst.tscn").instantiate()
    b.global_position = global_position
    b.burst_kind = "cyan"
    get_tree().current_scene.add_child(b)
    queue_free()

func _draw():
    var glow=0.42+0.20*sin(pulse*4.0)
    draw_rect(Rect2(-22,14,44,5),Color(0,0,0,0.20))
    draw_arc(Vector2.ZERO,29.0+sin(pulse*3.1)*2.0,0,TAU,30,Color(0.55,0.96,0.48,glow),2.0)
    # heavy army crate
    draw_rect(Rect2(-22,-16,44,32),Color(0.12,0.20,0.12))
    draw_rect(Rect2(-20,-14,40,28),Color(0.25,0.36,0.20))
    draw_rect(Rect2(-20,-14,40,6),Color(0.37,0.49,0.28))
    draw_rect(Rect2(-20,9,40,5),Color(0.12,0.20,0.12))
    draw_rect(Rect2(-22,-16,5,32),Color(0.10,0.16,0.10))
    draw_rect(Rect2(17,-16,5,32),Color(0.10,0.16,0.10))
    # lid seam / hardware
    draw_line(Vector2(-18,-5),Vector2(18,-5),Color(0.08,0.13,0.08),2.0)
    draw_rect(Rect2(-5,-9,10,7),Color(0.69,0.63,0.37))
    draw_rect(Rect2(-3,-7,6,3),Color(0.22,0.22,0.16))
    # stencil
    draw_rect(Rect2(-8,0,16,10),Color(0.84,0.83,0.64))
    draw_rect(Rect2(-2,1,4,8),Color(0.70,0.14,0.12))
    draw_rect(Rect2(-6,3,12,4),Color(0.70,0.14,0.12))
    draw_string(ThemeDB.fallback_font,Vector2(-17,27),"SUPPLY",HORIZONTAL_ALIGNMENT_CENTER,34,8,Color(0.85,0.90,0.69,0.85))
