extends StaticBody2D

@export var mound_size=Vector2(260,64)
@export var base_color=Color(0.30,0.30,0.20)
@export var edge_color=Color(0.45,0.55,0.28)

func _ready():
    collision_layer=1
    collision_mask=0
    var poly=ConvexPolygonShape2D.new()
    poly.points=PackedVector2Array([Vector2(-mound_size.x*0.5,0),Vector2(-mound_size.x*0.34,-mound_size.y*0.62),Vector2(-mound_size.x*0.10,-mound_size.y*0.92),Vector2(mound_size.x*0.16,-mound_size.y),Vector2(mound_size.x*0.38,-mound_size.y*0.54),Vector2(mound_size.x*0.5,0),Vector2(mound_size.x*0.5,24),Vector2(-mound_size.x*0.5,24)])
    var cs=CollisionShape2D.new();cs.shape=poly;add_child(cs)
    queue_redraw()

func surface_y_at(local_x:float)->float:
    var x=clamp(local_x,-mound_size.x*0.5,mound_size.x*0.5)
    var pts=[Vector2(-mound_size.x*0.5,0),Vector2(-mound_size.x*0.34,-mound_size.y*0.62),Vector2(-mound_size.x*0.10,-mound_size.y*0.92),Vector2(mound_size.x*0.16,-mound_size.y),Vector2(mound_size.x*0.38,-mound_size.y*0.54),Vector2(mound_size.x*0.5,0)]
    for i in range(pts.size()-1):
        if x>=pts[i].x and x<=pts[i+1].x:
            var t=(x-pts[i].x)/max(1.0,pts[i+1].x-pts[i].x)
            return lerp(pts[i].y,pts[i+1].y,t)
    return 0.0

func _draw():
    var pts=PackedVector2Array([Vector2(-mound_size.x*0.5,0),Vector2(-mound_size.x*0.34,-mound_size.y*0.62),Vector2(-mound_size.x*0.10,-mound_size.y*0.92),Vector2(mound_size.x*0.16,-mound_size.y),Vector2(mound_size.x*0.38,-mound_size.y*0.54),Vector2(mound_size.x*0.5,0),Vector2(mound_size.x*0.5,24),Vector2(-mound_size.x*0.5,24)])
    draw_colored_polygon(pts,base_color)
    var top=PackedVector2Array([pts[0],pts[1],pts[2],pts[3],pts[4],pts[5]])
    for i in range(top.size()-1): draw_line(top[i],top[i+1],edge_color,7.0,true)
    for i in range(12):
        var x=-mound_size.x*0.44+float(i)*mound_size.x/12.0
        var y=surface_y_at(x)+10+float((i*19)%16)
        draw_circle(Vector2(x,y),2.0+float(i%3),base_color.lightened(0.12 if i%2==0 else 0.04))
