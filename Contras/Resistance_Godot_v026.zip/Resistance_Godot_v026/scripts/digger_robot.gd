extends CharacterBody2D

@export var max_hp = 5.0
@export var move_speed = 82.0
@export var active_distance = 1500.0
var hp = 5.0
var target = null
var terrain = null
var drill_timer = 0.0
var contact_timer = 0.0

@onready var sprite = $Sprite

func _ready():
    hp = max_hp
    add_to_group("enemy")
    add_to_group("digger")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    terrain = get_tree().get_first_node_in_group("destructible_terrain")

func _physics_process(delta):
    if GameState.celebration_active:
        velocity.x = move_toward(velocity.x,0.0,900.0*delta)
        if not is_on_floor(): velocity.y += 1400.0*delta
        elif int(Time.get_ticks_msec()/700 + int(global_position.x)) % 3 == 0: velocity.y = -155.0
        move_and_slide()
        rotation = sin(float(Time.get_ticks_msec())*0.008 + global_position.x*0.02)*0.08
        queue_redraw()
        return
    if target == null or not is_instance_valid(target):
        target = get_tree().get_first_node_in_group("player")
    if target == null: return
    var to_target = target.global_position - global_position
    if to_target.length() > active_distance:
        velocity.x = 0.0
        if not is_on_floor():
            velocity.y += 1300.0 * delta
            move_and_slide()
        return
    drill_timer -= delta
    contact_timer = max(0.0, contact_timer - delta)
    var drill_dir = to_target.normalized()
    if abs(drill_dir.x) < 0.35:
        drill_dir.x = 0.35 * sign(to_target.x if to_target.x != 0 else 1.0)
        drill_dir = drill_dir.normalized()
    var drill_point = global_position + drill_dir * 28.0
    if terrain and terrain.has_cell_at_world(drill_point):
        velocity.x = move_toward(velocity.x, 0.0, 900.0 * delta)
        if drill_timer <= 0.0:
            terrain.damage_at_world(drill_point, 1.35, 1)
            drill_timer = 0.20
    else:
        velocity.x = move_toward(velocity.x, sign(to_target.x) * move_speed, 700.0 * delta)
    if not is_on_floor(): velocity.y += 1300.0 * delta
    if to_target.y < -42.0 and is_on_floor() and abs(to_target.x) < 220.0:
        velocity.y = -310.0
    move_and_slide()
    if to_target.length() < 34.0 and contact_timer <= 0.0 and target.has_method("take_damage"):
        target.take_damage(1, global_position)
        contact_timer = 0.75
    sprite.flip_h = to_target.x < 0.0
    sprite.frame = int(float(Time.get_ticks_msec()) / 90.0) % 8

func take_damage(amount, hit_position = Vector2.ZERO):
    hp -= float(amount)
    if hp <= 0.0:
        GameState.add_score(500)
        var scene = preload("res://scenes/Burst.tscn")
        var b = scene.instantiate()
        b.global_position = global_position
        b.burst_kind = "cyan"
        get_tree().current_scene.add_child(b)
        queue_free()
