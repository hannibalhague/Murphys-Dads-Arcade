extends Area2D

@export var flight_speed=245.0
@export var vertical_speed=255.0
@export var min_world_y=55.0
@export var max_world_y=178.0
@export var hover_clearance=248.0
@export var rotor_ground_clearance=58.0
var rotor_time=0.0
var helicopter_y=-170.0
var helicopter_x=0.0
var hover_y=125.0
var flight_started=false
var rider
var vertical_input=0.0
var ladder_shape:CollisionShape2D
var blade_timer=0.0
var terrain_blade_timer=0.0
var flight_complete=false
var ladder_bottom_y=310.0
var last_ground_y=384.0
var smoothed_ground_y=384.0
var target_heli_y=125.0
var flight_pitch=-0.10
var exhaust_time=0.0
const LADDER_TOP_Y=34.0
const MIN_LADDER_LENGTH=175.0
const MAX_LADDER_LENGTH=330.0

func _ready():
    collision_layer=0
    collision_mask=2
    monitoring=true
    ladder_shape=CollisionShape2D.new()
    var shape=RectangleShape2D.new()
    shape.size=Vector2(48,MAX_LADDER_LENGTH)
    ladder_shape.shape=shape
    ladder_shape.disabled=true
    add_child(ladder_shape)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _process(delta):
    rotor_time+=delta
    exhaust_time+=delta
    blade_timer=max(0.0,blade_timer-delta)
    terrain_blade_timer=max(0.0,terrain_blade_timer-delta)
    if not GameState.commander_executed and not flight_started:
        ladder_shape.set_deferred("disabled",true)
        queue_redraw()
        return

    if not flight_started:
        helicopter_x=sin(rotor_time*.78)*64.0
        var heli_world_x=global_position.x+helicopter_x
        last_ground_y=_ground_y_at(heli_world_x)
        smoothed_ground_y=lerp(smoothed_ground_y,last_ground_y,1.0-exp(-delta*5.0))
        hover_y=clamp(smoothed_ground_y-hover_clearance,82.0,145.0)
        helicopter_y=lerp(helicopter_y,hover_y,1.0-exp(-delta*2.6))
        flight_pitch=lerp(flight_pitch,-0.10,1.0-exp(-delta*4.0))
        rotation=flight_pitch
        ladder_bottom_y=_desired_ladder_bottom(smoothed_ground_y)
        _update_ladder(true)
        _manual_grab_check()
    else:
        # Smooth victory-flight controls: input moves an altitude target; the aircraft eases toward it.
        global_position.x-=flight_speed*delta
        helicopter_x=lerp(helicopter_x,0.0,1.0-exp(-delta*3.6))
        var flight_world_x=global_position.x+helicopter_x
        last_ground_y=_ground_y_at(flight_world_x)
        smoothed_ground_y=lerp(smoothed_ground_y,last_ground_y,1.0-exp(-delta*4.4))
        # Victory flight is SKY-ONLY. UP/DOWN changes altitude inside a fixed sky band;
        # terrain never pulls the helicopter downward and DOWN can never bury it in hills.
        target_heli_y+=vertical_input*vertical_speed*delta
        target_heli_y=clamp(target_heli_y,min_world_y,max_world_y)
        helicopter_y=lerp(helicopter_y,target_heli_y,1.0-exp(-delta*4.6))
        flight_pitch=lerp(flight_pitch,-0.12-vertical_input*.07,1.0-exp(-delta*4.5))
        rotation=flight_pitch
        ladder_bottom_y=_desired_flight_ladder_bottom(smoothed_ground_y)
        _update_ladder(false)
        _chop_with_rotor()
        if global_position.x<=220.0 and not flight_complete:
            flight_complete=true
            flight_speed=0.0
            GameState.clear_mission()
    queue_redraw()

func _ground_y_at(world_x:float)->float:
    var space=get_world_2d().direct_space_state
    var query=PhysicsRayQueryParameters2D.create(Vector2(world_x,-650),Vector2(world_x,900),1)
    query.collide_with_areas=false
    query.collide_with_bodies=true
    var hit=space.intersect_ray(query)
    if not hit.is_empty():
        return float(hit.position.y)
    var terrain=get_tree().get_first_node_in_group("destructible_terrain")
    if terrain!=null:
        var fallback_y=terrain.get("surface_y")
        if fallback_y!=null:
            return float(fallback_y)
    return 384.0

func _desired_ladder_bottom(ground_y:float)->float:
    var world_heli_y=global_position.y+helicopter_y
    var desired_world_bottom=ground_y-8.0
    var local_bottom=desired_world_bottom-world_heli_y
    return clamp(local_bottom,LADDER_TOP_Y+MIN_LADDER_LENGTH,LADDER_TOP_Y+MAX_LADDER_LENGTH)

func _desired_flight_ladder_bottom(ground_y:float)->float:
    var world_heli_y=global_position.y+helicopter_y
    var safe_world_bottom=ground_y-24.0
    var local_bottom=safe_world_bottom-world_heli_y
    return clamp(local_bottom,LADDER_TOP_Y+105.0,LADDER_TOP_Y+185.0)

func _update_ladder(active):
    var top=LADDER_TOP_Y
    var bottom=max(top+40.0,ladder_bottom_y)
    var shape=ladder_shape.shape as RectangleShape2D
    shape.size=Vector2(48,bottom-top)
    ladder_shape.position=Vector2(helicopter_x,(helicopter_y+top+helicopter_y+bottom)*0.5)
    ladder_shape.set_deferred("disabled",not active)

func _manual_grab_check():
    if not GameState.extraction_ready:return
    var p=get_tree().get_first_node_in_group("player")
    if p==null:return
    var h=global_position+Vector2(helicopter_x,helicopter_y)
    var top=h.y+LADDER_TOP_Y
    var bottom=h.y+ladder_bottom_y
    if abs(p.global_position.x-h.x)<42 and p.global_position.y>top-18 and p.global_position.y<bottom+26:
        _try_grab(p)

func _on_body_entered(body):
    _try_grab(body)

func _try_grab(body):
    if flight_started or not GameState.extraction_ready or body==null or not body.is_in_group("player"):return
    if body is CharacterBody2D and body.is_on_floor():return
    if body.has_method("start_helicopter_ride"):
        body.start_helicopter_ride(self)

func begin_flight_with_player(player):
    if flight_started:return
    flight_started=true
    rider=player
    target_heli_y=helicopter_y
    smoothed_ground_y=last_ground_y
    ladder_shape.set_deferred("disabled",true)
    GameState.start_victory_flight()
    GameState.screen_shake_requested.emit(3.0)

func set_vertical_input(value):
    vertical_input=clamp(float(value),-1.0,1.0)

func get_rider_position():
    var h=global_position+Vector2(helicopter_x,helicopter_y)
    # Keep the rider on a short victory ladder in the sky; never stretch him into terrain.
    return h+Vector2(4,132.0).rotated(rotation)

func _chop_with_rotor():
    if blade_timer>0:return
    blade_timer=.075
    var rotor=global_position+Vector2(helicopter_x,helicopter_y)+Vector2(8,-49).rotated(rotation)
    for enemy in get_tree().get_nodes_in_group("enemy"):
        if is_instance_valid(enemy) and not enemy.is_in_group("boss_commander") and enemy.has_method("take_damage") and enemy.global_position.distance_to(rotor)<104:
            enemy.take_damage(999,rotor)
            GameState.add_score(150)
    for prop in get_tree().get_nodes_in_group("damageable_prop"):
        if is_instance_valid(prop) and prop.has_method("take_damage") and prop.global_position.distance_to(rotor)<110:
            prop.take_damage(999,rotor)
    if terrain_blade_timer<=0:
        terrain_blade_timer=.12
        var terrain=get_tree().get_first_node_in_group("destructible_terrain")
        if terrain and terrain.has_method("damage_at_world"):
            terrain.damage_at_world(rotor,4.0,3)

func _draw():
    if not GameState.commander_executed and not flight_started:return
    var h=Vector2(helicopter_x,helicopter_y)
    var rotor_blur=48.0+38.0*abs(sin(rotor_time*18.0))

    # Soft moving shadow / rotor wash.
    draw_circle(h+Vector2(4,52),58.0,Color(0,0,0,0.10))
    draw_circle(h+Vector2(4,50),36.0,Color(0.78,0.86,0.72,0.045))

    # Tail boom and fin behind fuselage.
    draw_colored_polygon(PackedVector2Array([h+Vector2(70,-10),h+Vector2(166,-18),h+Vector2(166,7),h+Vector2(68,10)]),Color("314a42"))
    draw_colored_polygon(PackedVector2Array([h+Vector2(148,-15),h+Vector2(180,-38),h+Vector2(176,8),h+Vector2(151,8)]),Color("47695d"))

    # Fuselage: layered panels give the helicopter volume instead of a flat polygon.
    draw_colored_polygon(PackedVector2Array([h+Vector2(-88,3),h+Vector2(-66,-22),h+Vector2(-28,-37),h+Vector2(46,-35),h+Vector2(88,-20),h+Vector2(102,-4),h+Vector2(94,15),h+Vector2(62,28),h+Vector2(-57,27),h+Vector2(-82,17)]),Color("355248"))
    draw_colored_polygon(PackedVector2Array([h+Vector2(-80,0),h+Vector2(-27,-30),h+Vector2(39,-29),h+Vector2(78,-18),h+Vector2(91,-7),h+Vector2(84,7),h+Vector2(55,18),h+Vector2(-54,18)]),Color("4f7064"))
    draw_line(h+Vector2(-52,19),h+Vector2(58,19),Color("263a34"),3.0)

    # Cockpit glass with frames/highlights.
    draw_colored_polygon(PackedVector2Array([h+Vector2(-73,-15),h+Vector2(-31,-28),h+Vector2(-5,-22),h+Vector2(-3,8),h+Vector2(-59,8),h+Vector2(-76,0)]),Color("79aabb"))
    draw_colored_polygon(PackedVector2Array([h+Vector2(-62,-12),h+Vector2(-47,-20),h+Vector2(-35,-18),h+Vector2(-36,3),h+Vector2(-60,3)]),Color(0.75,0.91,0.96,0.58))
    draw_colored_polygon(PackedVector2Array([h+Vector2(-43,-20),h+Vector2(-26,-24),h+Vector2(-11,-18),h+Vector2(-12,4),h+Vector2(-35,4)]),Color(0.67,0.86,0.92,0.50))
    draw_line(h+Vector2(-36,-25),h+Vector2(-36,8),Color("22332f"),2.0)
    draw_line(h+Vector2(-11,-19),h+Vector2(-11,7),Color("22332f"),2.0)

    # Cabin door, panel seams, army marking.
    draw_rect(Rect2(h+Vector2(7,-14),Vector2(37,25)),Color("22312c"))
    draw_rect(Rect2(h+Vector2(11,-10),Vector2(18,16)),Color("58766a"))
    draw_rect(Rect2(h+Vector2(49,-7),Vector2(17,12)),Color("18221f"))
    draw_line(h+Vector2(45,-16),h+Vector2(45,14),Color(0.12,0.18,0.16,0.70),1.5)
    draw_circle(h+Vector2(58,-1),7.0,Color(0.78,0.78,0.54,0.65))
    draw_string(ThemeDB.fallback_font,h+Vector2(53,3),"★",HORIZONTAL_ALIGNMENT_CENTER,12,9,Color("263a34"))

    # Engine exhaust pulse.
    var puff=0.35+0.18*sin(exhaust_time*7.0)
    draw_circle(h+Vector2(77,-13),7.0,Color(0.16,0.18,0.17,puff))
    draw_circle(h+Vector2(88,-14),4.5,Color(0.28,0.30,0.28,puff*0.55))

    # Landing skids.
    draw_line(h+Vector2(-60,34),h+Vector2(-24,34),Color("202624"),4.0)
    draw_line(h+Vector2(-24,34),h+Vector2(-16,23),Color("202624"),4.0)
    draw_line(h+Vector2(18,34),h+Vector2(60,34),Color("202624"),4.0)
    draw_line(h+Vector2(60,34),h+Vector2(67,22),Color("202624"),4.0)

    # Rotor mast, hub, spinning main and tail rotors.
    draw_line(h+Vector2(8,-34),h+Vector2(8,-49),Color("bfc8c0"),4.0)
    draw_circle(h+Vector2(8,-49),6.0,Color("283a35"))
    draw_line(h+Vector2(-112,-49),h+Vector2(128,-49),Color(0.84,0.88,0.85,0.80),5.0)
    draw_line(h+Vector2(8-rotor_blur,-54),h+Vector2(8+rotor_blur,-44),Color(1,1,0.95,0.38),3.0)
    var tail=h+Vector2(169,-6)
    var ta=rotor_time*28.0
    var td=Vector2(cos(ta),sin(ta))*13.0
    var td2=Vector2(-td.y,td.x)
    draw_line(tail-td,tail+td,Color(0.86,0.90,0.87,0.86),3.0)
    draw_line(tail-td2,tail+td2,Color(0.86,0.90,0.87,0.86),3.0)

    # Searchlight haze makes the extraction craft stand out from the background.
    draw_colored_polygon(PackedVector2Array([h+Vector2(-62,8),h+Vector2(-132,48),h+Vector2(-112,-7)]),Color(1.0,0.92,0.55,0.08))

    # Rope ladder with subtle sway while hovering.
    var top=h+Vector2(0,LADDER_TOP_Y)
    var bottom=h+Vector2(0,ladder_bottom_y)
    var sway=0.0 if flight_started else sin(rotor_time*2.6)*3.0
    draw_line(top+Vector2(-11,0),bottom+Vector2(-11+sway,0),Color("cdbb84"),4.0)
    draw_line(top+Vector2(11,0),bottom+Vector2(11+sway,0),Color("cdbb84"),4.0)
    var y=top.y+12
    while y<bottom.y:
        var t=(y-top.y)/max(1.0,bottom.y-top.y)
        var sx=sway*t
        draw_line(Vector2(top.x-11+sx,y),Vector2(top.x+11+sx,y),Color("847452"),2.0)
        y+=17

    if not flight_started:
        draw_circle(bottom+Vector2(sway,12),13,Color(1.0,.82,.24,.24))
        draw_arc(bottom+Vector2(sway,12),18,0,TAU,24,Color(1.0,.90,.30,.55),2.0)
        draw_string(ThemeDB.fallback_font,bottom+Vector2(-132,41),"JUMP ON THE LONG ROPE LADDER",HORIZONTAL_ALIGNMENT_CENTER,264,13,Color("fff1a0"))
        draw_string(ThemeDB.fallback_font,bottom+Vector2(-82,60),"EXTRACTION",HORIZONTAL_ALIGNMENT_CENTER,164,11,Color("ffe16d"))
