extends RefCounted

static func ensure_actions():
    _ensure_action("move_left", [KEY_A, KEY_LEFT])
    _ensure_action("move_right", [KEY_D, KEY_RIGHT])
    _ensure_action("move_up", [KEY_W, KEY_UP])
    _ensure_action("move_down", [KEY_S, KEY_DOWN])
    _ensure_action("jump", [KEY_SPACE, KEY_Z])
    _ensure_action("fire", [KEY_SHIFT, KEY_X])
    _ensure_action("grenade", [KEY_G, KEY_C])
    _ensure_action("restart", [KEY_R])

    _ensure_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
    _ensure_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
    _ensure_axis("move_up", JOY_AXIS_LEFT_Y, -1.0)
    _ensure_axis("move_down", JOY_AXIS_LEFT_Y, 1.0)
    _ensure_button("move_left", JOY_BUTTON_DPAD_LEFT)
    _ensure_button("move_right", JOY_BUTTON_DPAD_RIGHT)
    _ensure_button("move_up", JOY_BUTTON_DPAD_UP)
    _ensure_button("move_down", JOY_BUTTON_DPAD_DOWN)
    _ensure_button("jump", JOY_BUTTON_A)
    _ensure_button("fire", JOY_BUTTON_X)
    _ensure_button("grenade", JOY_BUTTON_B)
    _ensure_button("grenade", JOY_BUTTON_Y)
    _ensure_button("restart", JOY_BUTTON_START)

static func _ensure_action(action_name, keys):
    if not InputMap.has_action(action_name):
        InputMap.add_action(action_name, 0.22)
    for code in keys:
        var exists = false
        for current in InputMap.action_get_events(action_name):
            if current is InputEventKey and current.keycode == code:
                exists = true
                break
        if not exists:
            var ev = InputEventKey.new()
            ev.keycode = code
            InputMap.action_add_event(action_name, ev)

static func _ensure_button(action_name:String, button:int):
    for current in InputMap.action_get_events(action_name):
        if current is InputEventJoypadButton and current.button_index == button:
            return
    var ev = InputEventJoypadButton.new()
    ev.button_index = button
    InputMap.action_add_event(action_name, ev)

static func _ensure_axis(action_name:String, axis:int, value:float):
    for current in InputMap.action_get_events(action_name):
        if current is InputEventJoypadMotion and current.axis == axis and is_equal_approx(current.axis_value,value):
            return
    var ev = InputEventJoypadMotion.new()
    ev.axis = axis
    ev.axis_value = value
    InputMap.action_add_event(action_name, ev)
