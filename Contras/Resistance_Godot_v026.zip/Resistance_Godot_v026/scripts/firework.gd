extends Node2D

@export var color_index = 0
var life = 1.05
var max_life = 1.05
var sparks = []

func _ready():
    var rng = RandomNumberGenerator.new()
    rng.seed = Time.get_ticks_usec() + int(global_position.x * 17.0)
    var count = 22
    for i in range(count):
        var a = TAU * float(i) / float(count) + rng.randf_range(-0.09,0.09)
        var speed = rng.randf_range(72.0,155.0)
        sparks.append({"p":Vector2.ZERO,"v":Vector2(cos(a),sin(a))*speed,"r":rng.randf_range(1.7,3.3)})
    queue_redraw()

func _process(delta):
    life -= delta
    for spark in sparks:
        var v = spark["v"]
        v.y += 72.0 * delta
        v *= 0.985
        spark["v"] = v
        spark["p"] = spark["p"] + v * delta
    queue_redraw()
    if life <= 0.0:
        queue_free()

func _draw():
    var a = clamp(life/max_life,0.0,1.0)
    var colors = [Color(1.0,0.80,0.18),Color(0.25,0.92,1.0),Color(1.0,0.30,0.16),Color(0.72,0.40,1.0)]
    var c = colors[color_index % colors.size()]
    c.a = a
    for spark in sparks:
        var p = spark["p"]
        var v = spark["v"].normalized()
        draw_line(p-v*7.0,p,c,2.2)
        draw_circle(p,spark["r"],Color(c.r,c.g,c.b,a*0.9))
    draw_circle(Vector2.ZERO,4.0 + (1.0-a)*16.0,Color(1.0,1.0,0.82,a*0.35))
