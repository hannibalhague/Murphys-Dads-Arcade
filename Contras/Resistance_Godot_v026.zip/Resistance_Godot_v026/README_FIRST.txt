MISSION: OFF WITH HIS HEAD! — GODOT v026
V023 INPUT / AUDIO / ENEMY / EFFECTS PASS
- On-screen joystick + FIRE/JUMP/GREN buttons on touch/mobile.
- Gamepad: left stick/D-pad move+aim, A jump, X fire, B/Y grenade, Start restart.
- Restored title and mission-failed/game-over presentation from the HTML source.
- mp3/ numbered soundtrack folder + track switch button.
- sfx/ replacement sound folder + common sound hooks.
- GAME SELECT returns to ../index.html in Web exports.
- 11 additional enemy variants with distinct stats/visual gear.
- Improved attack dogs, animated water, real fire hazards and stronger barrel explosions.

========================================

This project is now driven from the exact HTML game used as the source of truth.
A copy is included at:
  reference/index_source_of_truth.html

OPEN
1. Use Godot 4.x Standard (GDScript).
2. Import project.godot.
3. Press F6/F5.

CORE CONTROLS
- WASD / ARROWS: move + aim
- DOWN: crouch; crouched fire goes straight
- DOWN + LEFT/RIGHT: diagonal-down aim
- SPACE / Z: jump / double jump
- DOWN + LEFT/RIGHT + JUMP: dodge roll
- DOWN + JUMP (no sideways input): drop through ledges
- DOWN while standing above a ladder: snap onto ladder and climb down
- SHIFT / X: fire
- G / C: grenade
- Airborne + press toward wall: wall knife
- Knife -> jump -> press back toward wall: climb a straight wall
- Close enemy: automatic knife melee
- R: restart the whole campaign

CAMPAIGN
10 stages are included using the stage names/layout families/enemy mixes/boss names from the HTML:
1 Jungle Outskirts — Hot Air Balloon
2 Desert Base — Mammoth Tank
3 Naval Harbor — Ironclad Warship
4 Ice Bunker — War Blimp
5 Alien Caves — Titan Bat
6 Robot Factory — AI Colossus
7 Toxic Wastes — Toxic Behemoth
8 Sky Fortress — Siege Drone
9 Lava Fortress — Magma Beast
10 Alien Nexus — Dread Walker

V018 BIG ENVIRONMENT PASS
- Helicopter victory flight is locked to a sky-only altitude band; DOWN cannot fly into terrain.
- Checkpoints are dedicated rising Canadian flags; supply crates are separate rewards.
- Three large theme-specific architecture beats per stage plus a boss fortress and watchtower.
- Detailed bunkers, depots, industrial plants, sky modules and alien structures add doors, windows, pipes, vents, rooflines, hazard markings and lighting details.

GAME SYSTEMS
- 5 HP per life
- 5 lives
- 1 continue
- destructible dirt/rock/brick terrain + permanent supports/bedrock
- underground rooms
- hostages
- treasure chests / precious books / gold bars
- health pickups
- destructible camps, crates, tents and barrels
- digger robots
- automatic knife melee
- wall-knife climbing
- roll / duck under bullets
- bosses
- blue business-suit/orange-skin/yellow-hair boss man after every boss
- player becomes invincible for the post-boss execution
- head trophy + fireworks
- long helicopter rope ladder
- victory flyback with UP/DOWN control, shooting and rotor destruction
- surviving enemies celebrate during flyback

NOTES
The HTML remains in /reference so future changes can be checked against it instead of drifting into a different game.



v018 MAJOR GRAPHICS / VICTORY-FLIGHT OVERHAUL
- Trophy head now stays the exact commander head after decapitation: orange face, yellow hair, same facial details.
- Rebuilt helicopter flyback controls around a smooth altitude target instead of direct Y movement.
- Ground-height sampling is filtered so hills/ledges do not jerk the helicopter up and down.
- Helicopter eases into pitch and altitude changes while preserving low rotor-skimming destruction.
- Rebuilt helicopter art with layered fuselage panels, cockpit glass, cabin door, army marking, skids, mast/hub, tail rotor, exhaust, rotor blur, searchlight haze and rope sway.
- Major world-art pass: layered sky bands, celestial haze, clouds/fog, three silhouette-depth layers and theme-specific foreground shapes.
- Improved terrain micro-detail, hostage art and boss visual effects.
- Preserved the unified 8-way aim, wall knife, roll, 5 HP / 5 lives / 1 continue, reduced med-kit balance, auto knife, 10-stage campaign and post-boss victory sequence.

The HTML source-of-truth remains in /reference for future parity checks.


V018 MAJOR CONTENT PASS
- Theme-specific ambient particles/effects across all 10 stages.
- More authored destructible set-pieces, upper routes and treasure rewards.
- Enemy alert cues + temporary damage health bars.
- Bosses smoke/spark progressively as damaged.
- More detailed metal/concrete prop treatment.
- Stable v018 movement/aim/helicopter/victory behavior preserved.


v018 TERRAIN / ARCHITECTURE PASS
- Seven physical hills/mounds per stage break up the flat ground line.
- Ground props snap to the actual mound/ground surface instead of guessed Y coordinates.
- One-way ledges support reliable drop-through and ladder descent.
- More building families: field houses, desert houses, ice houses, utility buildings, sky houses, alien huts, command bunkers and spawn tents.
- Doors/windows/roofs/frames are more detailed; ground blocks visually blend with irregular top edges.