# v026
- Auto-knife remains active during helicopter fly-back with extended reach and preserved aim.
- Attack dogs leap/lunge at close range.
- Shield troops reduce frontal bullet/melee damage.
- Medics periodically heal nearby non-boss allies.
- Water gains foam and reflections; fire gains smoke/ember detail.
- Added optional knife/shield/medic SFX hooks.

## v026
- Fixed startup crash: restored campaign water-gap arrays and per-stage water colors required by the animated water system.
- Cleaned Godot 4.7 shadowing/unused warnings in terrain rendering and campaign helpers.

# v022 — Parser & Warning Hotfix

- Fixed out-of-scope wall-knife draw variables (`tip` / `s`) by using `wall_tip` / `wall_draw_side`.
- Removed integer-division warnings from player animation timing and digger animation timing.
- Preserved all v020 gameplay/content.


- Full touch joystick/buttons, gamepad support, restored title/game-over UI.
- Numbered mp3 soundtrack system, SFX folder and track/game-select buttons.
- 11 additional enemy variants and improved attack-dog visuals.
- Animated water, flame hazards and stronger explosion presentation.
- Stable v018 terrain, hills, architecture, ladder descent and ledge drop-through retained.

# v018 — Terrain, Ledges & Architecture
- Added physical hills/mounds across every stage.
- Fixed ladder descent from ledges.
- Added DOWN+JUMP ledge drop-through while preserving DOWN+DIR+JUMP roll.
- Ground props now snap to actual terrain height; fixed floating barrels/crates/tents.
- Added house, bunker, utility, alien, sky, command and spawn-tent structure families.
- Rebuilt doors/windows/roofs and softened square terrain visuals.

# v018
- Major stage-identity and game-feel pass.
- Added theme-specific ambient particles and authored set-pieces.
- Added enemy alert/health readability and progressive boss damage FX.
- Preserved stable v017 controls and victory systems.

## v017 — major graphics / helicopter flight overhaul
- Fixed the severed trophy head changing appearance: held head now remains the same orange face / yellow hair commander head.
- Rebuilt helicopter victory-flight controls around a smoothed altitude target with filtered ground-height tracking.
- Removed abrupt direct-Y terrain fighting; helicopter now eases through altitude and pitch changes while retaining low rotor-skimming destruction.
- Rebuilt helicopter drawing with layered fuselage, framed cockpit, cabin details, army marking, skids, rotor mast/hub, animated tail rotor, exhaust, searchlight haze, rotor blur and swaying ladder.
- Added layered sky bands, celestial haze, clouds/fog, three depth layers of distant silhouettes and stronger theme-specific foreground silhouettes across all ten stages.
- Added extra terrain surface variation, improved hostage details and stronger boss tread/muzzle effects.
- Preserved v014 Godot 4.7.2 compatibility fix and all approved gameplay systems.


## v017 — Godot 4.7.2 parse-error hotfix
- Renamed the custom `draw_ellipse` helper in enemy, health pickup, and treasure scripts so it no longer collides with Godot 4.7.2 CanvasItem.draw_ellipse.
- Updated every matching call site project-wide.
- No gameplay balance or control changes in this hotfix.
# v017 — visual/game-feel polish

- Reduced health pickups to four ground med kits plus at most one upper-route med kit per stage.
- Kept two supply/checkpoint crates per stage so long missions remain fair.
- Rebuilt med-kit art as a military field medical case with straps, handle, patch, glow, shadow and sparkles.
- Rebuilt supply-cache and treasure presentation with layered shading, hardware and improved readability.
- Improved barrels, crates, tents and other destructible props with depth, highlights, hardware and better damage cracks.
- Fixed enemy hit-flash tint restoration; themed enemies no longer turn plain white after being hit.
- Added subtle enemy grounding shadows and small role details.
- Added another foreground-detail layer across campaign themes.
- Improved HUD contrast/readability and pickup/explosion feedback.
- Preserved v012 unified 8-way aiming, wall knife, roll, difficulty, helicopter and campaign systems.

# V008 — FAIR COMBAT / ROLL / LIVES / ROPE-LADDER EXTRACTION

- Added evasive roll: DOWN + direction + JUMP.
- Roll has a low collider and a short damage-avoidance window for getting past enemies.
- Added 5 HP per life, 5 lives, and 1 automatic continue.
- Added lives/continue to HUD.
- Added 7 med-kit pickups and a late-game supply checkpoint.
- Reduced normal enemy bullet speed to 390 px/s.
- Increased enemy fire delays and reaction times; shortened engagement ranges.
- Reduced several enemy HP values and removed the worst boss-area pile-up.
- Reworked Mammoth Tank movement so it no longer depends on terrain collision.
- Tank HP reduced to 24, cannon speed to 335 px/s, and cannon fires one round per attack.
- Improved tank track/body details and damage smoke.
- Rebuilt helicopter extraction: visible hover after boss death, rope ladder only when extraction is ready, and player must jump onto the rope ladder.
- Added mobile-input cleanup to prevent synthetic FIRE/JUMP/GRENADE actions from getting stuck after interrupted touches or focus changes.

# Resistance Godot changelog

## v006 — repeatable wall climb + performance pass
- Wall knife can now re-grab the same wall while the player is rising.
- Knife jump is more vertical and has a smaller sideways kick.
- Added a short wall-climb steering assist when pressing back toward the same wall.
- Re-grab delay reduced so stab -> jump -> re-stab can be repeated up a straight wall.
- Preserved the ability to aim/fire while knife-gripping and to carve an upward escape path.
- Replaced per-block terrain collision shapes with merged horizontal collision runs, drastically reducing world physics shapes.
- Split destructible terrain drawing into 512px visual chunks for better off-screen culling.
- Removed far-away enemy/digger line-of-sight and AI work until they are near the player.
- Increased camera smoothing response from 7.5 to 10.5 for less perceived camera lag.
- Kept the approved 460 px/sec enemy projectile speed and real crouch hitbox unchanged.

## v005 — wall knife / upward escape routes
- Added automatic wall-knife grip when airborne and pressing toward a wall.
- Knife holds the player briefly, then transitions to a controlled slow wall slide.
- Player can keep firing and use up/diagonal aim while attached, so trapped underground routes can be carved upward.
- Jumping during a knife grip kicks away from the wall and preserves one air jump.
- Knife releases automatically if the supporting destructible block is shot away.
- Added a visible knife blade plus small stab/scrape feedback.
- Added a wall-knife practice cliff and hidden chest near the late test-range section.
- Kept v004 crouch hitbox behavior and the liked 460 px/sec enemy projectile speed unchanged.

## v004 — real crouch hitbox / bullet ducking
- Crouching now shrinks the Player's actual physics hitbox while keeping the feet planted.
- Standard enemy rifle fire targets standing chest height, allowing well-timed crouches to pass underneath normal rounds.
- Crouch shooting origin is lowered with the player pose.
- Added headroom protection so the player cannot stand up into a low ceiling.
- Kept the v003 combat pacing and 460 px/sec enemy bullet speed unchanged.

## v003 — polish / combat readability
- Preserved player movement, jump, fire cadence and terrain digging feel from v002.
- Preserved enemy projectile speed at 460 px/sec.
- Added enemy line-of-sight checks so enemies cannot shoot through terrain/buildings.
- Added enemy reaction delay, patrol/investigation behavior and muzzle flashes.
- Added soldier/raider/heavy/robot visual variants.
- Improved destructible terrain rendering with exposed tunnel rims, material detail and stronger damage cracks.
- Added destructible watchtowers and surface brick barricades.
- Added explosive barrels with chain reactions.
- Enlarged grenade smoke/debris and added camera shake.
- Improved ladder top entry detection using the player's feet as well as body center.
- Hostages celebrate briefly after rescue.
- Added an extraction objective at the far right; rescue all hostages and reach it for +5000.
- HUD now shows the current extraction objective and mission-clear state.


## v007 — Jungle Outskirts mission pass
- Converts the systems range into a first mission structure.
- Adds Mammoth Tank boss with HUD health bar, fair cannon bursts, and large destruction effects.
- Adds helicopter extraction that only arrives after both hostages are rescued and the boss is destroyed.
- Adds a supply cache (+2 HP, +2 grenades) before the finale.
- Adds a hidden underground cache chamber and additional treasure/enemies.
- Adds more destructible motor-pool/camp pieces and richer lightweight jungle background art.
- Preserves v006 wall-knife climbing, merged terrain collisions, off-screen AI sleeping, crouch hitbox, and 460 px/sec standard enemy bullets.

## v009 — commander execution / victory flyover / auto knife
- Rebuilt the boss ending into a reusable victory sequence: boss destruction -> commander bailout -> invincible pursuit -> automatic knife execution -> head held overhead -> fireworks -> helicopter rope-ladder boarding -> flyback.
- Added BossCommander scene with a physical jump out of the destroyed tank and short escape run.
- Player becomes unkillable immediately after the boss is defeated and remains protected through the victory sequence.
- Added automatic close-range knife melee against regular enemies; bosses/commander are excluded.
- Added visible held commander head that remains raised while jumping onto the helicopter and during the flyback.
- Added 10-second fireworks celebration after the commander execution, plus continuing aerial victory spark effects.
- Rebuilt helicopter rope ladder with a much longer visual and physical grab zone; player must be airborne to board it.
- Helicopter victory flight traverses west over the entire level instead of immediately ending the mission.
- UP/DOWN controls helicopter altitude during the victory flight; player can still aim/fire and throw grenades while riding.
- Helicopter rotor destroys/chops nearby enemies, destructible camp props, barrels, and destructible terrain when flown low enough.
- Surviving enemies and digger robots switch from combat AI to jumping/swaying celebration behavior during the victory flyback.
- The victory ladder is no longer blocked or hidden by missed hostages; hostages remain score/mission objectives but every boss reliably produces the post-boss spectacle.


## v011
- Fixed helicopter spawning underground by moving scene origin to sky/world Y=0.
- Helicopter now raycasts the terrain and chooses a safe hover altitude per stage.
- Rope ladder dynamically extends toward the actual ground and its collision matches its visible length.
- Victory-flight low altitude follows terrain so rotor-skimming is possible without burying the helicopter/rider.
- Added a visible extraction marker and a supply pickup before every boss.


## v012 — unified 8-way aim + large campaign polish pass
- Centralized 8-way aim so movement states no longer override diagonal input.
- Diagonal aim works consistently on ground, airborne, crouched, ladder, wall-knife, roll recovery and helicopter ride.
- Ground DOWN-alone preserves crouch/straight-fire; airborne DOWN-alone fires straight down.
- Added subtle diagonal/vertical muzzle-direction cue.
- Added two supply/checkpoint caches per stage, more med kits, upper-route treasure and health rewards.
- Added limited elevated guards with deliberately slower firing.
- Expanded theme-specific scenery for jungle, desert, harbor, ice, cave/nexus, factory, toxic, sky fortress and lava.
- Added boss-area warning signage plus destructible cover/barrels near boss approaches.
- Expanded enemy art-family differentiation for dogs, raiders, aliens, robots, snow troops, ninjas and specialist enemies.
- Added unique primitive silhouettes for AI COLOSSUS, TOXIC BEHEMOTH, MAGMA BEAST and DREAD WALKER.
- Increased grenade blast/carving slightly and enriched debris/smoke feedback.
- Corrected all version labeling to v012, including internal project folder and Godot project title.

## v020 legacy notes
- Full touch HUD: fixed on-screen joystick plus FIRE/JUMP/GREN buttons on mobile.
- Gamepad support: left stick + D-pad movement/aim, A jump, X fire, B/Y grenade, Start restart.
- Restored HTML-inspired title screen and mission-failed/game-over presentation.
- Added `mp3/` numbered soundtrack folder and TRACK switch button.
- Added `sfx/` drop-in replacement sound folder and hooks for shooting, hits, kills, explosions, checkpoints and hostages.
- Added GAME SELECT button for returning to `../index.html` in Web exports.
- Added scout, officer, commando, rocketeer, shield, medic, diver, ice guard, mutant, cyborg and attack-dog variants.
- Improved attack-dog harness/teeth/readability.
- Animated water surfaces now fill level water gaps.
- Added animated fire hazards to lava/factory/toxic missions.
- Stronger multi-layer barrel explosion fire/smoke.


## v026
- Added a separate visible player rifle sprite that follows 8-way aim in all movement states.
- Rebuilt enemy flamethrowers as short-range multi-puff flame streams instead of ordinary bullets.
- Added enemy run bob, lean, recoil, airborne tilt, variable gait timing, and more visible weapon/arm silhouettes.
- Improved dog movement rhythm and flamer equipment readability.
- Preserved v024 campaign, helicopter knife, mobile/gamepad/audio/title systems, terrain, checkpoints, and architecture.
